/*
 *  MODULE NAME:
 *
 *      wfb_muss.c
 *
 *  DESCRIPTION:
 *		This file contains a set of API to obtain TGT, seal and 
 *      unseal messages(written using CyberSafe's GSS-API security toolkit)
 *
 *  FACILITY:
 *
 *      Wells Fargo Bank
 *
 *  ABSTRACT:
 *
 *  CHANGE HISTORY:
 *
 *	16-Jan-1998	chappas	Final version completion
 *	14-Nov-1997	laraj	Initial file creation.
 */

/****************************************************************************
      					I N C L U D E   F I L E S
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>
#include <gssapi/gssapi.h>
#include <gssapi/gssapi_krb5.h>

#include "wfb_muss.h"

/****************************************************************************
   	 		C O N S T A N T  & T Y P E  D E F I N I T I O N S
*****************************************************************************/

#define	CONF_INTEG 1
#define INTEG_ONLY 0

/* global context for application */
typedef struct _MussGlobalCtx {
  int		errno;
  time_t	tgt_start_time;
  long  	tgt_lifetime_secs;
  char		keytab[MUSS_MAX_PATH];
  char		keytab_env[MUSS_MAX_PATH];
  char		client_prn[MUSS_MAX_FQDN];
  char		ccfile[MUSS_MAX_PATH];
  char		ccfile_env[MUSS_MAX_PATH];
  char		tgt_lifetime[MUSS_LIFE_TIME_LEN];
} MussGlobalCtx;

static char *		err_msg[] = {
  "MUSS: General Failure",
  "MUSS: Invalid Principal name",
  "MUSS: Failed to obtain TGT",
  "MUSS: Authentication error",
  "MUSS: Kerberization error",
  "MUSS: Seal error",
  "MUSS: Unseal error",
  "MUSS: Kerberos setup error",
  "MUSS: GSS import error",
  "MUSS: Context setup failure"
};

/****************************************************************************
   	 		S T A T I C   V A R I A B L E S
*****************************************************************************/
static	int				obtain_tgt = MUSS_TRUE;
static	MussDiagnostic	diagnostic = { 0 };
static 	MussGlobalCtx	global     = { 0 };

/****************************************************************************
   	 		 S T A T I C  F U N C T I O N  P R O T O T Y P E S
*****************************************************************************/
static void muss_gssLogErr(OM_uint32 , 	/* IN  - major		*/
  		                   OM_uint32 ,	    /* IN  - minor		*/
		                   char * );		/* IN  - operation 	*/

static void muss_gssSetDiagnostic(MUSS_U32int major,  /* IN - major */
								  MUSS_U32int minor,  /* IN - minor */
								  char *text);        /* IN - error text */

static void muss_gssLogErr(OM_uint32 agMaj,    /* IN - major */
						   OM_uint32 agMin, 	/* IN - minor */
						   char *operation);   /* IN - failed operation */

static long muss_convertStr2Val(char *in_str); /* IN - lifetime string */

static void muss_localReleaseBuffer(gss_buffer_t aBuffer);  /* IN - Buffer */

static int muss_gssTGT_expired(void);

/****************************************************************************
   	 		 C O D E   S T A R T S  H E R E
*****************************************************************************/
/*
 * muss_setupKerberos
 * Purpose: To setup the environment for kerberos
 * Parameters:
 *     keytab:     Keytab file name of the client principal
 *     principal:  Kerberos client principal name
 *     cache:      Credential cache file to store the tickets
 *     tgt_lifetime: lifetime of the ticket (in #w#d#h#m format) 
 *                   (ex: "24h45m"  for a 24hours+45min ticket)
 *                   (ex: "24h"  for a 24hour ticket)
 *                   (If just a number is passed, it will be taken as hours )
 *                   (ex: "10" for 10 hour ticket  )
 *                        
 * Return: returns 0 if successful, otherwise returns non-zero error code
 */
int 
muss_setupKerberos(char *keytab, char *principal, char *cache, 
												char *tgt_lifetime)
{
  int       i, ret_val;
  long  	total_secs;

  /* clear the MUSS context */
  memset((void *) &global, 0, sizeof(MussGlobalCtx));

  /* Credentials Cache file  */
  strcpy(global.ccfile, cache);
  sprintf (global.ccfile_env,"%s=%s:%s", KRB5CCNAME, KRB_FILE, cache);
  if (putenv(global.ccfile_env))
  {
    muss_gssSetDiagnostic(0, 0,"putenv() failed.");
    return (global.errno = E_muss_kerberos_setup_fail);
  } 

  strcpy(global.keytab, keytab);

  /* Application principal */
  i = strlen(principal) + 1;
  if ( i > MUSS_MAX_FQDN || i == 1 )
  {
    muss_gssSetDiagnostic(0, 0, "Invalid Principal name supplied");
    return (global.errno = E_muss_invalid_principal);
  }
  strcpy (global.client_prn, principal);

  /* Ticket Granting Ticket lifetime - in #w#d#h#m format */
  if ( tgt_lifetime == NULL || strlen(tgt_lifetime) == 0 )
    strcpy (global.tgt_lifetime, MUSS_TGT_LIFETIME);
  else 
    strcpy (global.tgt_lifetime, tgt_lifetime);

  /* convert life time to seconds for ease of use */
  total_secs = muss_convertStr2Val(global.tgt_lifetime);
  global.tgt_lifetime_secs = (total_secs - (total_secs * 0.10));

  return E_muss_OK;
}

/*
 * muss_gssSeal
 * 
 * Returns a sealed message along with the Security Token and
 * the context required to unseal any reply.  The arguments are
 * as follow:
 *
 *	msg			Message to encrypt.
 *
 *	msg_len			Message length
 *
 *	remote_principal	Principal name for remote node.
 *
 *	seal_msg		Resulting sealed message.  The
 *				caller is responsible for allocating
 *				a buffer large enough to hold the
 *				encrypted message.
 *
 *	seal_len		Resulting length for sealed message.
 *
 *	token			Security token.  Caller is required
 *				to allocate a buffer large enough
 *				to hold token.
 *
 *	token_len		Length of token.
 *
 *	muss_ctx		Context used to seal message.  The
 *				caller will pass an address to a
 *				pointer.  NOT A POINTER!!!. This routine
 *				will allocate the correct amount of
 *				memory required for the context.
 * Return: returns 0 if successful, otherwise returns non-zero error code
 */

int
muss_gssSeal(char *inmsg, int inmsg_len, char *remote_principal, 
					MUSS_VoidPtr seal_msg, int *seal_len, MUSS_VoidPtr token,
								int *token_len, MUSS_VoidPtr *muss_ctx)
{
  int32_t				retFlags = 0;
  int				first_pass = 1;
  OM_uint32			theConf  = CONF_INTEG;   /* Confidentiality and Integrity */
  int32_t     			theQop   = 0;
  int32_t     			theConfState;
  OM_uint32			retTime = 0;
  OM_uint32			major_stat;
  OM_uint32			minor_stat;
  OM_uint32			tmp_minor;
  gss_OID			secMech = GSS_C_NULL_OID;
  gss_buffer_t		tToken	= GSS_C_NO_BUFFER;
  gss_ctx_id_t		*gss_context;
  gss_buffer_desc	name_tok, send_tok;
  gss_buffer_desc	inTok, outTok;
  gss_name_t		target_name;
  OM_uint32			reqFlags=0;


	/*************************************************************************
			            O B T A I N    TGT 
     *************************************************************************/
	/* has the TGT expired? */
	if (muss_gssTGT_expired() == MUSS_TRUE)
	{
		/* get TGT now */
    	if (muss_gssObtainTGT() != E_muss_OK)
		{
			obtain_tgt = MUSS_TRUE;		/* go to kinit in the next call */
			return (global.errno = E_muss_fail_obtain_tgt);
	    }
    }

    /*************************************************************************
	        O B T A I N  Service Ticket (Security Token)
     *************************************************************************/

   /* setup memory credential by calling gss_obtain_credential()*/
					
#ifdef __mit
    gss_cred_id_t   cred_handle = GSS_C_NO_CREDENTIAL;
    gss_OID_set actual_mechs = GSS_C_NO_OID_SET;
    OM_uint32 cred_lifetime_requested;
    OM_uint32 cred_lifetime_received = 0;
    gss_buffer_desc  clnt_name_tok;
    gss_name_t client_gss_name;

    cred_lifetime_requested = muss_convertStr2Val((char *) global.tgt_lifetime);
 
    clnt_name_tok.length = (int)strlen(global.client_prn);
    clnt_name_tok.value  = global.client_prn;

    major_stat = gss_import_name(&minor_stat, &clnt_name_tok,
                                 GSS_KRB5_NT_USER_NAME,
                                 &client_gss_name);
#endif
    major_stat = gss_acquire_cred(&minor_stat,
                                 client_gss_name,
                                 cred_lifetime_requested,
                                 GSS_C_NULL_OID_SET,
                                 GSS_C_BOTH,
                                 &cred_handle,
                                 &actual_mechs, &cred_lifetime_received
    );

    major_stat = gss_release_oid_set( &minor_stat, &actual_mechs );
    major_stat = gss_release_name( &minor_stat, & client_gss_name);
 
    /* ready for init security context */
	

    /* import remote principal name */
    name_tok.length = strlen(remote_principal);
    name_tok.value  = strdup(remote_principal);

    major_stat = gss_import_name(&minor_stat, &name_tok, 
#ifdef LINUX
				 GSS_KRB5_NT_USER_NAME,
#else
				 (gss_OID)GSS_KRB5_NT_PRINCIPAL_NAME,
#endif
				 &target_name);
    if (GSS_ERROR(major_stat))
    {
    	muss_gssLogErr (major_stat, minor_stat, "gss_import_name" );
	    obtain_tgt = MUSS_TRUE;	/* go to kinit in the next call */
		muss_localReleaseBuffer(&name_tok);
   		return (global.errno = E_muss_import_name);
  	}
	
	/* clean up the name token */
	muss_localReleaseBuffer(&name_tok);

	/* allocate space for a pointer of type gss_ctx_id_t */
  	*muss_ctx   = (void *) calloc(1, sizeof(gss_ctx_id_t));
  	gss_context = (gss_ctx_id_t *) *muss_ctx;
  	do 
  	{
	  major_stat = gss_init_sec_context(&minor_stat,
					    cred_handle, // GSS_C_NO_CREDENTIAL,
					    gss_context,
					    target_name,
					    GSS_C_NULL_OID,
					    reqFlags,
					    0,
					    NULL,		/* no channel bindings */
					    tToken,		/* received token */
					    &secMech,		/* ignore mech type */
					    &send_tok,      /* get gss token structure */
					    &retFlags,		/* ignore ret_flags */
					    &retTime);		/* ignore time_rec */

	  /* copy the token if present.  This may not be
	   * required since the client may just throw away
	   * this token and not send it to the remote server.
	   */
	  if (send_tok.length)
	    {
	      *token_len = send_tok.length; 
	      memcpy(token, send_tok.value, send_tok.length);
	      gss_release_buffer(&tmp_minor, &send_tok);
	    }
	  else
	    *token_len = 0;

	  /* check for error now */
	  if ((GSS_ERROR(major_stat)) ||
	      ((major_stat & GSS_S_COMPLETE) != GSS_S_COMPLETE)) 
	    {
	      if (first_pass)  /*first time */
		{
		  first_pass = 0;
		  if (muss_gssObtainTGT() != E_muss_OK)
		    {
		      obtain_tgt = MUSS_TRUE;	  /* go to kinit in the next call */
		      /* free the target name */
		      gss_release_name(&tmp_minor, &target_name);
		      return (global.errno = E_muss_fail_obtain_tgt);
		    }
		}
	      else    /* error during second pass  */
		{ 
		  muss_gssLogErr (major_stat, minor_stat, "gss_init_sec_context");
		  obtain_tgt = MUSS_TRUE;	/* go to kinit again in the next call*/
		  free(*muss_ctx);
		  
		  // set muss_ctx to NULL.
		  *muss_ctx = NULL;
		  
		  /* free the target name */
		  gss_release_name(&tmp_minor, &target_name);
		  return (global.errno = E_muss_set_sec_ctx_fail);
		} 
	    }
	  else
	    break;
	} while (1);

	/* don't need the target name */
	gss_release_name(&tmp_minor, &target_name);

  /*************************************************************************
	                   S E A L The Input Message                 
   *************************************************************************/

  /* initialize buffers */
  memset((void *) &inTok,  0, sizeof(gss_buffer_desc));
  memset((void *) &outTok, 0, sizeof(gss_buffer_desc));

  /* Clear text message */
  inTok.value  = inmsg;
  inTok.length = inmsg_len;

  /* Seal the Message now. */
  major_stat = gss_seal (&minor_stat,
			             *gss_context, /* Security context */
			             theConf,      /* Confidentiality(1), Integrity (0) */
			 			 theQop,       /* Quality of Protection */
			 			 &inTok,       /* Message to be sealed */
			 		     &theConfState, /* Confidentiality state */
			 			 &outTok);      /* Sealed message */

  /* check for error now */
  if (GSS_ERROR(major_stat)){
    muss_gssLogErr (major_stat, minor_stat, "gss_seal");
    obtain_tgt = MUSS_TRUE;	/* go to kinit again */
    return (global.errno = E_muss_seal_fail);
  }

  /* copy sealed message */
  memcpy(seal_msg, outTok.value, outTok.length);
  *seal_len = outTok.length;

  /* clean up */
  gss_release_buffer(&tmp_minor, &outTok);
  return E_muss_OK ;
}

/*
 * muss_gssUnseal
 *
 * Unseal a message.
 * The arguments are as follow:
 *
 *	seal_msg	Encrypted message
 *
 *	seal_len	Length of sealed message
 *
 *	msg		destination buffer for unsealed
 *			message.  The caller is responsible
 *			passing a buffer large enough.
 *
 *	msg_len		unsealed message length.
 *
 *	muss_context	context used to unseal message.
 *
 * Return: returns 0 if successful, otherwise returns non-zero error code
 */
int
muss_gssUnseal(MUSS_VoidPtr seal_msg, int seal_len, char *outmsg, 
								int *outmsg_len, MUSS_VoidPtr *muss_ctx)
{
  int32_t     			theConf;
  int32_t    			theQop;
  OM_uint32			major_stat = 0;
  OM_uint32			minor_stat = 0;
  gss_ctx_id_t		*ctx = (gss_ctx_id_t *) *muss_ctx;
  gss_buffer_desc	inTok;
  gss_buffer_desc	outTok;

  
  /*************************************************************************
	                U N S E A L The Input Message                 
   *************************************************************************/

  memset((void *) &outTok, 0, sizeof(gss_buffer_desc));
  memset((void *) &inTok,  0, sizeof(gss_buffer_desc));

  /* the message to unseal */
  inTok.length = seal_len;
  inTok.value  = seal_msg;
  major_stat = gss_unseal(&minor_stat,
			  			  *ctx,
			  			  &inTok,
			  		      &outTok,
			  		      &theConf,
			  			  &theQop);

  if (GSS_ERROR(major_stat))
  {
    muss_gssLogErr (major_stat, minor_stat, "gss_unseal");
    obtain_tgt = MUSS_TRUE;	/* go to kinit again in the next call */
    return (global.errno = E_muss_unseal_fail);
  }

  /*************************************************************************
                C O P Y the unsealed message into supplied buffers
   *************************************************************************/

  memcpy(outmsg, outTok.value, outTok.length);
  *outmsg_len = outTok.length;

  /* clean up */
  gss_release_buffer(&minor_stat, &outTok);

  return E_muss_OK;
}


/*
 * muss_gssObtainTGT
 * Acquire a TGT using extension function csf_gss_acq_user. 
 * Return: returns 0 if successful, otherwise returns non-zero error code
 */

int
muss_gssObtainTGT(void)
{
  //csf_gss_user_t			user = CSF_GSS_C_NULL_USER;
  gss_name_t				gssName = GSS_C_NO_NAME;
  int						ret_val = 0, optCount=0;
  OM_uint32           	major_stat = 0, minor_stat = 0;
  gss_buffer_desc     	inputNameBuf = GSS_C_EMPTY_BUFFER;
  gss_buffer_desc     	outputNameBuf = GSS_C_EMPTY_BUFFER;
  //csf_gss_mech_opt_desc 	opts[MUSS_MAX_NUM_OPTS];
  char					error_text[MUSS_ERROR_TEXT_LEN+1];
  time_t				    pwdExpTime = 0;
  gss_buffer_desc	        user_prompt1 = GSS_C_EMPTY_BUFFER;
  gss_buffer_t			user_prompt = &user_prompt1;
  gss_buffer_desc			user_label1 = GSS_C_EMPTY_BUFFER;
  gss_buffer_t			user_label = &user_label1;
  //gss_buffer_t			response = GSS_C_NULL_BUFFER;
  //int32_t					prompt_state = CSF_GSS_C_USER_STATE_NULL;
  gss_OID					prompting_mech, nameOID;

  fprintf(stderr,"obtaining TGT\n");
  fflush(stderr);
  /* Construct the client's GSS name. */
  inputNameBuf.length = strlen(global.client_prn);
  inputNameBuf.value = strdup(global.client_prn);
  if ( !inputNameBuf.value )
    {
      sprintf (error_text, 
	       "muss_gssObtainTGT: Could not construct client GSS name");
      muss_gssSetDiagnostic(0, 0, error_text);
      return (global.errno = E_muss_gen_failure);
    }
  /* Import the application principal into gss format */
  major_stat = gss_import_name(&minor_stat, &inputNameBuf, 
			       GSS_KRB5_NT_USER_NAME,&gssName);
  if( GSS_ERROR( major_stat ) ) 
    {
      muss_gssLogErr (major_stat, minor_stat, "gss_import_name");
      ret_val = E_muss_gen_failure;
      goto cleanup;
    }
#if 0		
  /* Set the TGT options */

  /* set lifetime option */
  opts[optCount].mechOID = rfc_krb5_c_OID;
  opts[optCount].id = CSF_GSS_C_ACQ_USER_OPT_LIFETIME;
  opts[optCount].val = global.tgt_lifetime;
  ++optCount;

  /*  Set the option to fetch the ticket always */
  opts[optCount].mechOID = rfc_krb5_c_OID;
  opts[optCount].id = CSF_GSS_C_ACQ_USER_OPT_ALWAYS_FETCH;
  ++optCount;

  /*  Set the Keytab file option */
  opts[optCount].mechOID = rfc_krb5_c_OID;
  opts[optCount].id = CSF_GSS_C_ACQ_USER_OPT_KTNAME;
  opts[optCount].val = global.keytab;
  ++optCount;

  /* Set the option to use keytab file instead of prompting for passwd */
  opts[optCount].mechOID = rfc_krb5_c_OID;
  opts[optCount].id = CSF_GSS_C_ACQ_USER_OPT_SVCKEY;
  ++optCount;

  /* Set option to use the specified Credential cache file  */
  opts[optCount].mechOID = rfc_krb5_c_OID;
  opts[optCount].id = CSF_GSS_C_ACQ_USER_OPT_CCNAME;
  opts[optCount].val = global.ccfile;
  ++optCount;

  /* explicitly null-terminate option array */	
  opts[optCount].mechOID = GSS_C_NULL_OID;


  /* Obtain the TGT */

  major_stat = csf_gss_acq_user(&minor_stat,
				gssName,
				rfc_krb5_c_OID_set,/*GSS_C_NULL_OID_SET*/
				opts,
				response,
				&user,
				user_prompt,
				user_label,
				&prompt_state,
				&prompting_mech,
				&pwdExpTime);
	
#endif			
  // BEGIN INSERT
  // this code body shamelessly stolen from MsgSecure.c::MsgSecure_get_tgt()

  struct k5_data
  {
    krb5_context ctx;
    krb5_ccache cc;
    krb5_principal me;
    char* name;
  };

  {
    struct k5_data k5d, * k5;
    krb5_error_code code = 0;
    krb5_get_init_creds_opt options;
    krb5_keytab keytab = 0;
    krb5_creds my_creds;
    krb5_deltat starttime; /* in seconds */
    krb5_deltat tkt_life;
    char * service_name;     /* remote principal name */

    k5=&k5d;
    memset(&k5d, 0, sizeof(k5d));

    //
    // step 1 : setup k5 : k5->ctx, k5->cc, k5->me, and k5->name
    //
    // ms_verbose(2,"kinit : Initialize krb5->ctx.\n");
    code = krb5_init_context(&k5->ctx);    // initialize krb5 library
    if (code != 0 ) {
      // ms_verbose(1, "Error while initializing Kerberos 5 library in krb5_init_context()");
      fprintf(logfile, "Error while initializing Kerberos 5 library in krb5_init_context()\n");
      return(E_muss_fail_obtain_tgt);
    }

    // use gccfile to be the cc name saved in k5->cc

    // ms_verbose(4,"kinit : resolve ccfile: %s.\n", global.ccfile);
    code = krb5_cc_resolve(k5->ctx, global.ccfile, &k5->cc);
    if (code != 0) {
      // ms_verbose(2, "resolving ccache %s in krb_cc_resolve()", global.ccfile);
      fprintf(logfile,"resolving ccache %s in krb_cc_resolve()\n", global.ccfile);
      return(E_muss_fail_obtain_tgt);
    }

    // what is the local principal?  For now, use the global.client_prn.
    // ms_verbose(2,"kinit : parse local principal: %s to get k5->me.\n", global.client_prn);
    code = krb5_parse_name(k5->ctx, global.client_prn, &k5->me);
    if (code != 0) {
      // ms_verbose(1, "Error when parsing: %s in krb5_parse_name().", global.client_prn);
      fprintf(logfile,"Error when parsing: %s in krb5_parse_name().\n", global.client_prn);
      return(E_muss_fail_obtain_tgt);
    }

    // get k5->name from k5->ctx and k5->me
    code = krb5_unparse_name(k5->ctx, k5->me, &k5->name);
    if (code!=0) {
      // ms_verbose(1, "Eroor when unparsing name error code=%i.\n", code);
      fprintf(logfile,"Error when unparsing name error code=%i.\n", code);
      return(E_muss_fail_obtain_tgt);
    }
    // ms_verbose(4,"kinit: local principal name accepted as : %s accepted\n",k5->name );

    //
    // step two : setup options
    //
    // ms_verbose(4,"kinit: inistialize options tgt_life=%s",global.tgt_lifetime);
    krb5_get_init_creds_opt_init(&options);
    memset(&my_creds, 0, sizeof(my_creds));
    // tgt life time
    krb5_string_to_deltat(global.tgt_lifetime, &tkt_life);
    krb5_get_init_creds_opt_set_tkt_life(&options,tkt_life); // set life time of ticket

    // forwardable, not proxible,
    krb5_get_init_creds_opt_set_forwardable(&options, 1);   // ticket is forwardable
    // krb5_get_init_creds_opt_set_proxiable(&options,0);      // non proxiable
    // keytab file

    // ms_verbose(4,"kinit : resolve keytab file %s.", global.keytab);
    code = krb5_kt_resolve(k5->ctx, global.keytab, &keytab);
    if (code != 0) {
      // ms_verbose(1,"Error resolving keytab %s", global.keytab);
      fprintf(logfile,"Error resolving keytab %s\n", global.keytab);    
      ret_val = code;
      goto ms2_cleanup;
    }

    // ms_verbose(2,"kinit : call krb5_get_init_creds_keytab(). - get tgt now...");
    starttime=0;        /* valid right way */
    service_name=NULL;  /* remote principal name */
    code = krb5_get_init_creds_keytab(k5->ctx, &my_creds, k5->me,
                                      keytab, starttime, service_name,
                                      &options);

    if (code!=0) {
      //ms_verbose(1,"Error while getting credetial from KDC, using prn=%s, keytab=%s",k5->name,hardcoded_keytab);
      //// ms_verbose(1,"Error while getting credetial from KDC." );
      fprintf(logfile,
	      "Error while getting credetial from KDC, using prn=%s, keytab=%s\n",
	      k5->name,global.keytab);
      ret_val = code;
      goto ms2_cleanup;
    }

    // ms_verbose(2,"kinit : call krb5_cc_initialize() to initialize cc.\n");
    code = krb5_cc_initialize(k5->ctx, k5->cc, k5->me);
    if (code) {
      // ms_verbose(1, "Error when initializing cache");
      fprintf(logfile, "Error when initializing cache\n");
      goto ms2_cleanup;
    }

    // ms_verbose(2,"kinit : call krb5_cc_store_cred() to save cred into cc.\n");
    code = krb5_cc_store_cred(k5->ctx, k5->cc, &my_creds);
    if (code) {
      // ms_verbose( 1, "Error while storing credentials", global.ccfile );
      fprintf(logfile, "Error while storing credentials=%s\n", global.ccfile );
      ret_val = code;
      goto ms2_cleanup;
    }

    //code = MS_TRUE;
    // ms_verbose(2, "----->getting TGT successfully<-------\n");
  ms2_cleanup:
    if (my_creds.client == k5->me) {
      my_creds.client = 0;
    }
    krb5_free_cred_contents(k5->ctx, &my_creds);
    if (keytab)
      krb5_kt_close(k5->ctx, keytab);
    if (k5->name)
      krb5_free_unparsed_name(k5->ctx, k5->name);
    if (k5->me)
      krb5_free_principal(k5->ctx, k5->me);
    if (k5->cc) {
      krb5_cc_close(k5->ctx, k5->cc);
    }
    if (k5->ctx)
      krb5_free_context(k5->ctx);
    memset(k5, 0, sizeof(*k5));
    ret_val = 0;
    goto cleanup;
    //return code;

  }



  // END INSERT

  if ( GSS_ERROR(major_stat) ) 
    {
#ifdef LINUX
      muss_gssLogErr (major_stat, minor_stat, "gss_get_tgt");
#else
      muss_gssLogErr (major_stat, minor_stat, "csf_gss_acq_user");
#endif
      ret_val = E_muss_fail_obtain_tgt;
      goto cleanup;
    }

 cleanup:
#ifndef LINUX
  /* only used by CSF */
  //TODO causing assertion error in g_initialize.c:97
  muss_localReleaseBuffer( &inputNameBuf );
  gss_release_buffer(&minor_stat, &outputNameBuf);

  //TODO causing assertion error in g_initialize.c:97
  gss_release_name(&minor_stat, &gssName );

  gss_release_buffer(&minor_stat, user_prompt );
  gss_release_buffer(&minor_stat, user_label );
  //csf_gss_release_user( &minor_stat, &user, 0 );
#endif

  if (ret_val == 0)		/* no errors so far */
    {
      global.tgt_start_time = time(NULL);
      obtain_tgt = MUSS_FALSE;
      ret_val = E_muss_OK;
    }

  return ret_val;

} /* obtain TGT */

/*
 * muss_gssNotifyFailure
 * notify MUSS that the client encountered an error.
 * Arguments are :
 * diag   -  pointer to MUSS diagnostic structure
 *          
 * Return: None
 */
void
muss_gssNotifyFailure(MussDiagnostic *diag)
{

  /* For now force TGT expiration */
  obtain_tgt = MUSS_TRUE;

  return;
}

/*
 * muss_gssGetDiagnosticText
 *
 * copies the last error text into the buffer provided by the caller
 * Return: None
 */
void
muss_gssGetDiagnosticText (char *text)
{

  /* check for valid pointer */
  if (text != NULL)
    strcpy(text, diagnostic.error_text);

  return;
}

/*
 * muss_gssCleanUp
 *
 * Free allocated pointer and the memory this
 * pointer reference at.
 * Return: None
 */
void
muss_gssCleanUp(MUSS_VoidPtr *muss_context)
{
  OM_uint32		major_stat = 0;
  OM_uint32		minor_stat = 0;
  gss_ctx_id_t		*ctx = (gss_ctx_id_t *) *muss_context;
  gss_buffer_desc	oToken;

  memset((void *) &oToken, 0, sizeof(gss_buffer_desc));
  
#ifdef LINUX
  major_stat = gss_delete_sec_context(&minor_stat, ctx, NULL);
#else
  major_stat = gss_delete_sec_context(&minor_stat, ctx, &oToken);
#endif
  /* log error if any */
  muss_gssLogErr (major_stat, minor_stat, "gss_delete_sec_context" );

  major_stat = gss_release_buffer(&minor_stat, &oToken);
  /* log error if any */
  muss_gssLogErr (major_stat, minor_stat, "gss_release_buffer");

  free(*muss_context);
  return;
}

/*
 * muss_gssTGT_expired
 *
 * check if TGT life time is expired or the force flag is on.
 *
 * Return: returns MUSS_TRUE if TGT expired, otherwise returns MUSS_FALSE
 */
static int
muss_gssTGT_expired(void)
{
  if ((obtain_tgt) ||
      (difftime(time(NULL), global.tgt_start_time) >= global.tgt_lifetime_secs))
    return MUSS_TRUE;
  return MUSS_FALSE;
}

/*
 * muss_gssSetDiagnostic
 * purpose: to set the global diagnostic structure with current
 *          error values.
 *          Also use this to set the error in the case of non-kerberos errors
 * Return: None
 */

static void
muss_gssSetDiagnostic (MUSS_U32int major, MUSS_U32int minor, char *text)
{

  /* initialize buffer - kind of overkill but you never know */
  memset((void *) &diagnostic, 0, sizeof(MussDiagnostic));
  diagnostic.major = major;
  diagnostic.minor = minor;

  memset(diagnostic.error_text, 0, MUSS_ERROR_TEXT_LEN);
  /* don't copy more chars than we have room for */
  if (strlen(text) > MUSS_ERROR_TEXT_LEN)
	  strncpy(diagnostic.error_text, text, MUSS_ERROR_TEXT_LEN);
  else
	  strcpy(diagnostic.error_text, text);
  
}


/*
 * muss_gssLogErr
 * Purpose: to get the kerberos error based on the supplied major & minor
 *          codes and then to set the global error diagnostic structure
 * Return: None
 */
static void
muss_gssLogErr (OM_uint32 agMaj, OM_uint32 agMin, char *operation)
{
  int32_t     		aDisplayCtx;
  OM_uint32		majErr;
  OM_uint32		minErr;
  char			errorText[MUSS_ERROR_TEXT_LEN];
  gss_buffer_desc	dMsg;
 
  if ( ! GSS_ERROR(agMaj) )
    return;


  /* Follow standard template for error text */
  sprintf (errorText, "OPER:%s MAJ:%#.8x MIN:%#.8x TEXT:",
           operation, agMaj, agMin);

  memset (&dMsg, 0, sizeof (dMsg));

  /* get error text */
  aDisplayCtx = 0;
  do {
    if ( aDisplayCtx )  /* Delimit major codes with a '/' */
      strcat (errorText, "/");

    majErr = gss_display_status (&minErr, 
				 agMaj, 
				 GSS_C_GSS_CODE,
				 GSS_C_NULL_OID, 
				 &aDisplayCtx, 
				 &dMsg);
    if ( ! GSS_ERROR(majErr) ) {
      /* Strip any leading "GSS: " from message */
      if ( strncmp ((char*) dMsg.value, "GSS: ", 5) == 0 ) 
		strcat (errorText, ((char *)dMsg.value) + 5);
      else 
		strcat (errorText, (char*) dMsg.value);
    }

    gss_release_buffer (&minErr, &dMsg);
  } while ( aDisplayCtx && ! GSS_ERROR(majErr) );
 
  /* Delimit major codes from minor codes with a ',' */
  strcat (errorText, ",");

  /* Perform similar loop as the previous except request descriptions
   * of the GSS minor (mechanism) status.
   */
  aDisplayCtx = 0;
  do {
    if ( aDisplayCtx )    /* Delimit major codes with a '/' */
      strcat (errorText, "/");

    majErr = gss_display_status(&minErr,
                                agMin,
                                GSS_C_MECH_CODE,
                                GSS_C_NULL_OID,
                                &aDisplayCtx,
                                &dMsg);
    if ( ! GSS_ERROR(majErr) )
      strcat (errorText, (char*) dMsg.value);

    gss_release_buffer( &minErr, &dMsg );
  } while( aDisplayCtx && ! GSS_ERROR(majErr) );
  muss_gssSetDiagnostic (agMaj, agMin, errorText);
  return;
}


/*
 * muss_convertStr2Val()
 * Purpose: To convert the lifetime string into time in seconds
 *
 * Return: returns <time in seconds>
 */
static long  
muss_convertStr2Val(char *in_str)
{
	char	lt_str[MUSS_LIFE_TIME_LEN], tmp_str[10];
	int	 	i,j=0;
	char 	w_str[5], d_str[5], h_str[5], m_str[5];
	long	total_secs=0;
	

	strcpy(lt_str, in_str);

	/* split the string into weeks, days, hrs and mins  */

	w_str[0] = '\0'; d_str[0] = '\0';
	h_str[0] = '\0'; m_str[0] = '\0';
	for (i=0; i<strlen(lt_str); i++)
	{
		if (lt_str[i] == 'w')
		{
			tmp_str[j] = '\0';
			strcpy(w_str, tmp_str);
			j = 0;
		}
		else if (lt_str[i] == 'd')
		{
			tmp_str[j] = '\0';
			strcpy(d_str, tmp_str);
			j = 0;
		}
		else if (lt_str[i] == 'h')
		{
			tmp_str[j] = '\0';
			strcpy(h_str, tmp_str);
			j = 0;
		}
		else if (lt_str[i] == 'm')
		{
			tmp_str[j] = '\0';
			strcpy(m_str, tmp_str);
			j = 0;
		}
		else
			tmp_str[j++] = lt_str[i];
	}
	/* if string is just a number - take it as hours */
    if (*w_str == '\0' && *d_str == '\0' &&	
    		    *h_str == '\0' && *m_str == '\0' ) 
	{	
		/* change the in_str to KRB format. ex: "24" to "24h" */
		strcat(in_str, "h");
		total_secs = atoi(lt_str) * 3600;
		return total_secs;
	}	
	/* get the total number of secs */
	if (w_str[0] != '\0')
		total_secs = atoi(w_str) * 7 * 24 * 3600;
	if (d_str[0] != '\0')
		total_secs = total_secs + (atoi(d_str) * 24 * 3600);
	if (h_str[0] != '\0')
		total_secs = total_secs + (atoi(h_str) * 3600);
	if (m_str[0] != '\0')
		total_secs = total_secs + (atoi(m_str)  * 60);

	return total_secs;
}


/* muss_localReleaseBuffer()
 * Purpose: To free up the memory allocated by us
 *
 * Return: None
 */
static void
muss_localReleaseBuffer( gss_buffer_t aBuffer ) 
{
    if( aBuffer ) 
    {
        if( aBuffer->value )
            free( aBuffer->value );
        
        aBuffer->length = 0;
        aBuffer->value = NULL;
    }
}

/****************************************************************************
   	 		 C O D E   E N D S  H E R E
*****************************************************************************/
