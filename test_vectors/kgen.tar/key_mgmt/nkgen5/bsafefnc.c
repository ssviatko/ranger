/*******************************************************************************
Copyright (c) 1996 by
Wells Fargo bank, San Francisco, California.
All rights reserved.

This software or any other copies thereof may not be provided or otherwise made 
available to any other person. No title to and ownership of the software is here
by transferred.

The information in this software is subject to change without notice and should
not be construed as a committment by Wells Fargo Bank.
	
Wells assumes no responsibility for the use or reliability of it's software.

Program :		Bsafe Cryptographic Functions
Module  :		bsafefnc.c
Version :		1.0
Author 	:		Sucharitha Chapparam.
Date    :		05/30/96

Changes History :

Description :
		This module has the following funcitons:
		B_GenerateHash : This generates hash value for the given data.
		B_DESDecrypt   : This function decrypts the input message using 
						 a DES key
		B_DESEncrypt   : This function encrypts the input message using 
						 a DES key
		B_GenerateDESKey:This function generates s DES key
		B_RSAEncrypt   : This function encrypts the input message using 
						 a RSA public/private key
		B_RSADecrypt:    This function decrypts the input message using 
						 a RSA public/private key
		B_GenerateRandomNum: This function generates a random number
	                			     
*******************************************************************************/	
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "aglobal.h"
#include "bsafe.h"
#include "demochos.h"

#include "common.h"
#define BLOCK_OUT_BYTES(inputBytes) (((inputBytes) / 8 + 2) * 8)


//
// 061030 (eym)  This source code is also used by ktadmin.  If this program
//   is run as a service, STDERR messages must be suppressed so they are not
//   sent back across the socket.
//

static void PrintBSAFEErr(int);
/* 
   Function    : B_GenerateHash
   Description : This function generates message digest for the given data.
   Parameters  : Input data to be digested, input data length(bytes),
                 output digested data(message digest), 
				 digested data length(bytes)
   Return	   : 0 if successful, otherwise error code.
   Note 	   : The foll function expects that memory is already allocated to 
				 output data.

*/
			
int B_GenerateHash(DataToDigest, DataToDigestLen, DigestedData, DigestedDataLen)
unsigned char *DigestedData, *DataToDigest;
unsigned int  *DigestedDataLen, DataToDigestLen;
{
	B_ALGORITHM_OBJ	digester = (B_ALGORITHM_OBJ)NULL_PTR;
	int				status = 0;
		
	do {
		if ((status = B_CreateAlgorithmObject(&digester)) != 0)
			break;
		if ((status = B_SetAlgorithmInfo(digester, AI_MD5, NULL_PTR)) != 0)
			break;
		if ((status = B_DigestInit(digester, (B_KEY_OBJ)NULL_PTR,
				 DEMO_ALGORITHM_CHOOSER, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;                        
		if ((status = B_DigestUpdate(digester, DataToDigest, DataToDigestLen, 
										(A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;                          
		if ((status = B_DigestFinal(digester, DigestedData, DigestedDataLen, 
					MD5DIGESTSIZE, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
	}while (0);
#ifdef SUPPRESS_STDERR
	if (status)
	{
		fprintf(stderr,"Error generating message digest:\n");
		PrintBSAFEErr(status);
	}		    
#endif
	return (status);
}


/*
	Function   : B_DESDecrypt
	Purpose    : This funciton decrypts the input message using a DES key.
    Parameters : Input data to be decrypted, input data length(bytes),
                 Decrypted data, Decrypted data length(bytes), DES Key buffer
	Return	   : 0 if successful, otherwise error code
*/
int B_DESDecrypt(DataToDecrypt, DataToDecryptLen, DecryptedData, 
											DecryptedDataLen, DESKeyBuf)
unsigned char *DataToDecrypt, *DecryptedData, *DESKeyBuf;
unsigned int  DataToDecryptLen, *DecryptedDataLen;
{
	static unsigned char initVector[8] = {
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}; 

	B_KEY_OBJ desKey = (B_KEY_OBJ) NULL_PTR;
	B_ALGORITHM_OBJ decryptObject = (B_ALGORITHM_OBJ)NULL_PTR;		
	unsigned int outputLenUpdate, outputLenFinal;
	int status;

	do {
		/* Create a Key object */
		if ((status = B_CreateKeyObject(&desKey)) != 0)
			break;
		/* Set the key to be a DES key and set it to the desKeyData 
		   declared above */
		if ((status = B_SetKeyInfo(desKey,KI_DES8, 
							(unsigned char *)DESKeyBuf)) != 0)
			break;
		/* Create an algorithm object */
		if ((status = B_CreateAlgorithmObject(&decryptObject)) != 0)
			break;
		/* Set the agorithm to a type that does DES encryption.
		   AI_DES_CBCPadIV8 will do. This algorithm type needs an 8yte 
		   initialization vector, user initVector declared above */             
		if ((status = B_SetAlgorithmInfo (decryptObject, AI_DES_CBCPadIV8, 
						(unsigned char *)initVector)) != 0)
			break;
		/* Ready to decrypt. Use B_DecryptInit, B_DecryptUpdate and 
		   B_DecryptFinal */
		if ((status = B_DecryptInit(decryptObject, desKey,
						DEMO_ALGORITHM_CHOOSER,
						(A_SURRENDER_CTX *)NULL_PTR)) != 0)
			break;
		if ((status = B_DecryptUpdate(decryptObject, DecryptedData, 
				 &outputLenUpdate, *DecryptedDataLen, 
				(unsigned char *) DataToDecrypt, DataToDecryptLen,
				(B_ALGORITHM_OBJ) NULL_PTR, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break; 
		if ((status=B_DecryptFinal(decryptObject,DecryptedData+outputLenUpdate,
				&outputLenFinal, *DecryptedDataLen - outputLenUpdate,
				(B_ALGORITHM_OBJ)NULL_PTR, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		*DecryptedDataLen = outputLenUpdate + outputLenFinal;
	}while (0);
	
	/* Done with the key and algorithm objects so destroy them */
	
	B_DestroyKeyObject(&desKey);
	B_DestroyAlgorithmObject(&decryptObject);

#ifdef SUPPRESS_STDERR
	if (status)
	{
		fprintf(stderr,"Error decrypting Message!!!\n");
		PrintBSAFEErr(status);
	}
#endif
    return (status);
	
}
	
/*
	Function   : B_DESEncrypt
	Purpose    : This funciton Encrypts the input message using a DES key.
  Parameters : Input data to be encrypted, input data length(bytes),
                 encrypted data, encrypted data length(bytes), DES Key buffer
	Return	   : 0 if successful, otherwise error code
*/
int B_DESEncrypt(DataToEncrypt, DataToEncryptLen, EncryptedData, 
											EncryptedDataLen, DESKeyBuf)
unsigned char *DataToEncrypt, *EncryptedData, *DESKeyBuf;
unsigned int  DataToEncryptLen, *EncryptedDataLen;
{
	static unsigned char initVector[8] = {
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08}; 

	B_KEY_OBJ desKey = (B_KEY_OBJ) NULL_PTR;
	B_ALGORITHM_OBJ encryptObject = (B_ALGORITHM_OBJ)NULL_PTR;		
	unsigned int outputLenUpdate, outputLenFinal;
	int status;

	do {
		/* Create a Key object */
		if ((status = B_CreateKeyObject(&desKey)) != 0)
			break;
		/* Set the key to be a DES key and set it to the desKeyData 
		   declared above */
		if ((status = B_SetKeyInfo(desKey,KI_DES8, 
							(unsigned char *)DESKeyBuf)) != 0)
			break;
		/* Create an algorithm object */
		if ((status = B_CreateAlgorithmObject(&encryptObject)) != 0)
			break;
		/* Set the agorithm to a type that does DES encryption.
		   AI_DES_CBCPadIV8 will do. This algorithm type needs an 8yte 
		   initialization vector, user initVector declared above */             
		if ((status = B_SetAlgorithmInfo (encryptObject, AI_DES_CBCPadIV8, 
						(unsigned char *)initVector)) != 0)
			break;
		/* Ready to encrypt. Use B_EncryptInit, B_EncryptUpdate and 
		   B_EncryptFinal */
		if ((status = B_EncryptInit(encryptObject, desKey,
					DEMO_ALGORITHM_CHOOSER,(A_SURRENDER_CTX *)NULL_PTR)) != 0)
			break;
		if ((status = B_EncryptUpdate(encryptObject, EncryptedData, 
				 &outputLenUpdate, DataToEncryptLen+8, 
				(unsigned char *) DataToEncrypt, DataToEncryptLen,
				(B_ALGORITHM_OBJ) NULL_PTR, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break; 
		if ((status=B_EncryptFinal(encryptObject,EncryptedData+outputLenUpdate,
				&outputLenFinal, (DataToEncryptLen+8) - outputLenUpdate,
				(B_ALGORITHM_OBJ)NULL_PTR, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		*EncryptedDataLen = outputLenUpdate + outputLenFinal;
	}while (0);
	
	/* Done with the key and algorithm objects so destroy them */
	
	B_DestroyKeyObject(&desKey);
	B_DestroyAlgorithmObject(&encryptObject);

#ifdef SUPPRESS_STDERR
	if (status)
	{
		fprintf(stderr,"Error Encrypting Message!!!\n");
		PrintBSAFEErr(status);
	}
#endif
    return (status);
	
}

/*
	Function   : B_GenerateDESKey
	Purpose    : This funciton generates DES key
    Parameters : random number , DES Key buffer
	Return	   : 0 if successful, otherwise error code
*/
int B_GenerateDESKey(RandomBuf, DESKeyBuf)
unsigned char *RandomBuf, *DESKeyBuf;
{
	B_KEY_OBJ DESKeyObj;
	int		  status = 0;
	unsigned char *key_buf;
				
	do {
		/* create DES key object */
		if ((status = B_CreateKeyObject (&DESKeyObj)) != 0)
			break;
		/* set the key object with the DES key and request to have the parity 
		   automatically adjusted */
		if ((status = B_SetKeyInfo (DESKeyObj, KI_DES8, 
													(POINTER)RandomBuf)) != 0)
			break;
		/* request a pointer to the same DES key with parity adjusted
		   See FIPS 46-1 */
		if ((status = B_GetKeyInfo((POINTER *)&key_buf,DESKeyObj,KI_DES8)) != 0)
			break;
	}while (0);        
	memcpy(DESKeyBuf, key_buf, DESKEYLEN);
	B_DestroyKeyObject(&DESKeyObj);	
#ifdef SUPPRESS_STDERR
	if (status)
		PrintBSAFEErr(status);
#endif
	return (status);
}

/*
  Function   : B_GenerateDESKey
  Purpose    : This funciton generates DES key
    Parameters : random number , DES Key buffer
  Return     : 0 if successful, otherwise error code
*/
int B_GenerateDES3Key(RandomBuf, DES3KeyBuf)
unsigned char *RandomBuf, *DES3KeyBuf;
{
  B_KEY_OBJ DES3KeyObj;
  int     status = 0;
  unsigned char *key_buf;

  // if the following line is uncommented, the DES3 key is reduced 
  // to a two-key DES3 key (the first and thoird keys are identical).
  // This reduces the keysize to 112 bits but is more susceptible to 
  // certain attacks.
  // memcpy(RandomBuf+16,RandomBuf,8);

  /* 
     int i;
     for(i=0;i<24;i++) printf("[%2.2x]",RandomBuf[i]);printf("\n"); 
  */

  do {
    /* create Triple DES key object */
    if ((status = B_CreateKeyObject (&DES3KeyObj)) != 0)
      break;
    /* set the key object with the DES3 key and request to have the parity
       automatically adjusted */
    if ((status = B_SetKeyInfo (DES3KeyObj, KI_DES24Strong,
				(POINTER)RandomBuf)) != 0)
      break;
    /* request a pointer to the same triple DES key with parity adjusted
       See FIPS 46-1 */
    if ((status = B_GetKeyInfo((POINTER *)&key_buf,DES3KeyObj,KI_DES24Strong)) != 0)
      break;
  }while (0);
  memcpy(DES3KeyBuf, key_buf, DESKEYLEN*3);
  B_DestroyKeyObject(&DES3KeyObj);
#ifdef SUPPRESS_STDERR
  if (status) {
    PrintBSAFEErr(status);
  }
#endif
  return (status);
}


/*
	Function   : B_RSAEncrypt
	Purpose    : This funciton Encrypts the input message using the givenRSA key
    Parameters : Input data to be encrypted, input data length(bytes),
                 encrypted data, encrypted data length(bytes), RSA Key and
				 RSA key length
	Return	   : 0 if successful, otherwise error code
*/
int B_RSAEncrypt(DataToEncrypt, DataToEncryptLen, EncryptedData, 
											EncryptedDataLen, KeyInfo, KeyLen)
unsigned char *DataToEncrypt, *EncryptedData, *KeyInfo;
unsigned int  DataToEncryptLen, *EncryptedDataLen, KeyLen;
{

	B_ALGORITHM_OBJ RSAPublicKeyAlgorithm, randomAlgorithm;
	B_KEY_OBJ key_obj;
	ITEM key_info, seed;
	unsigned char seed_buf[16];
	unsigned int status=0, partialOutputLength1, partialOutputLength2;

	key_info.data = KeyInfo;
	key_info.len = KeyLen;
	seed.data = seed_buf;
	memcpy(seed.data, "abcdefghijkskdjfs", 16);
	seed.len = 16;
	do {
		/* Create a Key object */
		if ((status = B_CreateKeyObject(&key_obj)) != 0)
			break;
		/* Set the key to be a RSA Public key */
		if((status = B_SetKeyInfo(key_obj, KI_RSAPublicBER, 
												(POINTER )&key_info)) != 0)
			break;	
		/*** Psuedo random number generation using MD2 ***/
		randomAlgorithm = NULL_PTR;
		if ( (status = B_CreateAlgorithmObject (&randomAlgorithm)) != 0)
			break;
		if ( (status = B_SetAlgorithmInfo(randomAlgorithm, AI_MD2Random, 
															NULL_PTR)) != 0)
			break;
		if ((status = B_RandomInit(randomAlgorithm, DEMO_ALGORITHM_CHOOSER,
						(A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;

		if ((status = B_RandomUpdate(randomAlgorithm,(unsigned char *)seed.data,
								seed.len, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;

		if ((status = B_CreateAlgorithmObject(&RSAPublicKeyAlgorithm)) != 0)
			break;
		
		/* robert 02022000
		if ((status=B_SetAlgorithmInfo(RSAPublicKeyAlgorithm,AI_PKCS_RSAPublic,
														NULL_PTR)) != 0)
		*/
		if ((status=B_SetAlgorithmInfo(RSAPublicKeyAlgorithm,AI_PKCS_RSAPublic,
														NULL_PTR)) != 0)
			break;
		if ((status = B_EncryptInit(RSAPublicKeyAlgorithm, key_obj, 
					DEMO_ALGORITHM_CHOOSER,(A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		
		if ((status = B_EncryptUpdate(RSAPublicKeyAlgorithm, EncryptedData, 
		/*
		&partialOutputLength1, RSAMODLEN, DataToEncrypt, DataToEncryptLen,
		*/
		&partialOutputLength1, BLOCK_OUT_BYTES(DataToEncryptLen), DataToEncrypt, DataToEncryptLen,
						randomAlgorithm, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		
		if ((status = B_EncryptFinal(RSAPublicKeyAlgorithm,EncryptedData+
				partialOutputLength1,&partialOutputLength2,RSAMODLEN - 
				partialOutputLength1,randomAlgorithm,
											(A_SURRENDER_CTX *) NULL_PTR))!=0)
			break;

		*EncryptedDataLen = partialOutputLength1 +  partialOutputLength2;	
	} while (0);
	
	B_DestroyAlgorithmObject(&RSAPublicKeyAlgorithm);
	B_DestroyKeyObject(&key_obj);
#ifdef SUPPRESS_STDERR
	if (status != 0)
	{
		fprintf(stderr,"Error encrypting Message!!!\n");
		PrintBSAFEErr(status);
	}
#endif
    return (status);
}

/*
	Function   : B_RSADecrypt
	Purpose    : This funciton Decrypts the input message using the givenRSA key
    Parameters : Input data to be Decrypted, input data length(bytes),
                 Decrypted data, Decrypted data length(bytes), RSA Key and
				 RSA key length
	Return	   : 0 if successful, otherwise error code
*/
int B_RSADecrypt(DataToDecrypt, DataToDecryptLen, DecryptedData, 
											DecryptedDataLen, KeyInfo, KeyLen)
unsigned char *DataToDecrypt, *DecryptedData, *KeyInfo;
unsigned int  DataToDecryptLen, *DecryptedDataLen, KeyLen;
{

	B_ALGORITHM_OBJ RSAPrivateKeyAlgorithm;
	B_KEY_OBJ key_obj;
	ITEM key_info;
	unsigned int status=0, partialOutputLength1, partialOutputLength2;

	key_info.data = KeyInfo;
	key_info.len = KeyLen;
	do {
		/* Create a Key object */
		if ((status = B_CreateKeyObject(&key_obj)) != 0)
			break;
		/* Set the key to be a RSA private key */
		if((status = B_SetKeyInfo(key_obj, KI_PKCS_RSAPrivateBER, 
												(POINTER )&key_info)) != 0)
			break;	

		if ((status = B_CreateAlgorithmObject(&RSAPrivateKeyAlgorithm)) != 0)
			break;
		/* robert 02022000
		if ((status = B_SetAlgorithmInfo(RSAPrivateKeyAlgorithm,
								AI_PKCS_RSAPrivate, NULL_PTR)) != 0)
     */
		if ((status = B_SetAlgorithmInfo(RSAPrivateKeyAlgorithm,
								AI_PKCS_RSAPrivate, NULL_PTR)) != 0)
			break;

		if ((status = B_DecryptInit(RSAPrivateKeyAlgorithm, key_obj, 
					DEMO_ALGORITHM_CHOOSER,(A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		
		if ((status = B_DecryptUpdate(RSAPrivateKeyAlgorithm, DecryptedData, 
		&partialOutputLength1, *DecryptedDataLen,DataToDecrypt,DataToDecryptLen,
							NULL_PTR, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		
		if ((status = B_DecryptFinal(RSAPrivateKeyAlgorithm,DecryptedData+
				partialOutputLength1,&partialOutputLength2,(*DecryptedDataLen)- 
				partialOutputLength1,NULL_PTR,(A_SURRENDER_CTX *)NULL_PTR))!=0)
			break;

		*DecryptedDataLen = partialOutputLength1 +  partialOutputLength2;	
	} while (0);
	
	B_DestroyAlgorithmObject(&RSAPrivateKeyAlgorithm);
	B_DestroyKeyObject(&key_obj);

#ifdef SUPPRESS_STDERR
	if (status != 0)
	{
		fprintf(stderr,"Error Decrypting Message!!!\n");
		PrintBSAFEErr(status);
	}
#endif
    return (status);
}

int B_GenerateRandomNum(unsigned char *RandomBuf, unsigned int RandomBufLen)
{
	B_ALGORITHM_OBJ randomAlgorithm = (B_ALGORITHM_OBJ)NULL_PTR;
	unsigned char *randomByteBuffer = NULL_PTR;
	POINTER randomSeed;
	unsigned int randomSeedLen;
	int		status = 0;
	time_t	cur_time;

	do {
		if ((status = B_CreateAlgorithmObject(&randomAlgorithm)) != 0)
			break;
		if ((status = B_SetAlgorithmInfo(randomAlgorithm, AI_MD5Random, 
														NULL_PTR)) != 0)
			break;
		if ((status = B_RandomInit(randomAlgorithm, DEMO_ALGORITHM_CHOOSER, 
									(A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		randomSeedLen = ((RandomBufLen > 256) ? RandomBufLen : 256);
		randomSeed = T_malloc(randomSeedLen);
		if ((status = (randomSeed == NULL_PTR)) != 0)
			break;
		time(&cur_time);
		memcpy(randomSeed, &cur_time, sizeof(cur_time));
		if ((status = B_RandomUpdate(randomAlgorithm, randomSeed, 
					randomSeedLen, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
		
	    randomByteBuffer = T_malloc(RandomBufLen);
		if ((status = (randomByteBuffer == NULL_PTR)) != 0)
			break;
		if ((status = B_GenerateRandomBytes(randomAlgorithm, randomByteBuffer, 
						RandomBufLen, (A_SURRENDER_CTX *) NULL_PTR)) != 0)
			break;
	}while (0);
	memcpy(RandomBuf, randomByteBuffer, RandomBufLen);
	B_DestroyAlgorithmObject(&randomAlgorithm);
	T_free(randomSeed);
	T_free(randomByteBuffer);
#ifdef SUPPRESS_STDERR
	if (status) {
		PrintBSAFEErr(status);
	}
#endif
	return (status);
}

/*
	Function   : PrintBSAFEErr
	Purpose    : This funciton displays the error message for a given error code
    Parameters : error code
	Return	   : none
*/
static void PrintBSAFEErr(ErrStat) 
int ErrStat;
{
#ifdef SUPPRESS_STDERR
	switch(ErrStat)
	{
		case BE_ALGORITHM_ALREADY_SET:
			fprintf(stderr,
					"%d : Algorithm Object has already been set\n", ErrStat);
			break;
		case BE_ALGORITHM_INFO:
			fprintf(stderr, 
				"%d : Invalid format for the algorithm information\n",ErrStat);
			break;			
		case BE_ALGORITHM_NOT_INITIALIZED:
			fprintf(stderr,
				"%d : Algorithm Object has not been intialized\n", ErrStat);
			break;
		case BE_ALGORITHM_NOT_SET:
			fprintf(stderr,"%d : Algorithm Object has not been set\n", ErrStat);
			break;
		case BE_ALGORITHM_OBJ:
			fprintf(stderr,"%d : Invalid Algorithm Object\n", ErrStat);
			break;
		case BE_ALLOC:
			fprintf(stderr,"%d : Insufficient memory\n", ErrStat);
			break;
		case BE_CANCEL:
			fprintf(stderr,
			"%d : Operation was cancelled by the surrender function\n",ErrStat);
			break;
		case BE_ALG_OPERATION_UNKNOWN:
			fprintf(stderr,"%d : Unknown operation for an algorithm\n",ErrStat);
			break;
		case BE_DATA:
			fprintf(stderr,"%d : Generic data error\n", ErrStat);
			break;
		case BE_EXPONENT_EVEN:
			fprintf(stderr, 
			"%d : Invalid even value for public exp in keypair gen\n", ErrStat);
			break;
		case BE_HARDWARE:
			fprintf(stderr,"%d : cryptographic hardware error\n", ErrStat);
			break;
		case BE_INPUT_DATA:
			fprintf(stderr,
				"%d : Invalid encoding format for input data\n", ErrStat);
			break;
		case BE_KEY_ALREADY_SET:
			fprintf(stderr,
			"%d : The value of the key Object has already been set\n", ErrStat);
			break;
		case BE_INPUT_LEN:
			fprintf(stderr,
				"%d : Invalid total length for input data\n", ErrStat);
			break;
		case BE_OUTPUT_LEN:
			fprintf(stderr,
				"%d : Output buffer too small to hold the data\n", ErrStat);
			break;
		case BE_RANDOM_OBJ:
			fprintf(stderr,
			"%d : Invalid algorithm object for the random algorithm\n",ErrStat);
			break;
		case BE_MEMORY_OBJ:
			fprintf(stderr,"%d : Invalid internal memory object\n", ErrStat);
			break;
		case BE_MODULUS_LEN:
			fprintf(stderr,
			"%d : Unsupported modulus length for a key or for alg\n", ErrStat);
			break;
		case BE_METHOD_NOT_IN_CHOOSER:
			fprintf(stderr,
				"%d : Algorithm method is not supported by chooser\n", ErrStat);
			break;
		case BE_OVER_32K:
			fprintf(stderr,"%d : data block exceeds 32,767 bytes\n", ErrStat);
			break;			
		case BE_INPUT_COUNT:
			fprintf(stderr,
			"%d:Update called an invalid num of times for i/p data\n",ErrStat);
			break;			
		case BE_WRONG_KEY_INFO:
			fprintf(stderr,
			"%d : Invalid format for the key info in the key object\n",ErrStat);
			break;			
		default:
			fprintf(stderr,"%d : Unexpected error!!!\n", ErrStat);
			break;
	}
#endif
}                                


