/* The following lengths are in bytes */
#define PCSLNUMLEN 		64
#define PCPASSPHRASELEN 16
#define RSAMODLEN		128
#define PUBLICEXPLEN	3
#define FQDNLEN			128
#define DESKEYLEN		8
#define MD5DIGESTSIZE	16


#define RECV_OK			  		0
#define RECV_GENERAL_FAILURE	1
#define RECV_MAX_CONNECTIONS	5

#define BAD						1
#define GOOD					2

#define VALID					1
#define INVALID					2

/* the foll macros are used to specify what key to use in cryptographic fns
   like RSADecrypt, RSAVerify etc... */
#define PUBLICSIGN 1
#define CAVERIFY   2
#define KDCSIGN    3
#define KDCPRIV    4
#define PRNSIGN    5
#define PRNPRIV    6
#define PUBLICPRIV 7

typedef struct {
	unsigned char   exponent[PUBLICEXPLEN];
	unsigned char   modulus[RSAMODLEN];
	} KEYINFO, *pKEYINFO;
#define BYTESTOBITS(x) (x*8)
#define BITSTOBYTES(x) (x/8)
