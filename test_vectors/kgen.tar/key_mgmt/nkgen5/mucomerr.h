/*

    Copyright (c) 1995 by
    Wells Fargo Bank, San Francisco, California.
    All rights reserved.

    This software or any  other  copies  thereof  may  not  be  provided  or
    otherwise made available to any other person.  No title to and ownership
    of the software is hereby transferred.

    The information in this software is subject to change without notice and
    should not be construed as a commitment by Wells Fargo Bank.

    Wells assumes no responsibility  for  the  use  or  reliability  of  its
    software.


    Program:		MU communications.
    Module:		mucomerr.h -- interface error definitions.
    Version:		inc/mucomerr.h, mucom, mucom_2.0, D970512a 1.4 05/12/97
    Author:		Keith M. Knowles.
    Date:		95/07/26


    Changes:

    97/05/12 adf	Rename kerberos error codes.
    97/02/03 adf	Add E_mucom_connect_not_found, E_mucom_mismatch.
			Add kerborose errors to ensure consistent numbering
			with mucom_impl_map.h.
    95/08/16 kmk	Add E_mucom_last.
    95/07/26 kmk	Rewrite from WAPI (Jim Esparza, HP).


    Notes:

    . NB: if you add/change errors here, you should update the err_msg table
      in mucom.c to reflect the change.
    . This source file is separate from mucom.h  specifically  in  order  to
      allow Glue to compile these errors codes.


    Description:

    These are the mucom status codes that may be returned by the interface.

*/

#ifndef	_mucomerr_h
#define	_mucomerr_h

#include "wfb_err.h"

#define	WAPI_STATUS_OK		0	/* general status success */

/*  Caution!  If you change this list, you should update the  err_msg  table
    in mucom.c to reflect the modification.
*/
enum {
  E_mucom_OK = 0,			/* success */
  E_mucom_no_host = EB_WAPI,		/* host not found */
  E_mucom_no_service,			/* service not found */
  E_mucom_not_setup,			/* mucom_setup not called yet */
  E_mucom_socket_error,			/* error on socket() or fcntl();
					   see errno */
  E_mucom_connect_timeout,		/* connection timed out */
  E_mucom_send_error,			/* send failed: see errno */
  E_mucom_send_timeout,			/* timed out sending request */
  E_mucom_recv_error,			/* recv failed: see errno */
  E_mucom_recv_timeout,			/* timed out receiving reply */
  E_mucom_recv_overflow,		/* reply larger than expected */
  E_mucom_connect_not_found,		/* no connection found */
  E_mucom_invalid_msg_type,		/* Invalid msg type (other than KRB or CLR) */
  E_mucom_generic_failure,		/* General failure */
  E_mucom_mismatch,			/* reply does not match request */
  E_mucom_invalid_principal,            /* invalid Fully Qualified Domain Name for the method server or CICS region */
  E_mucom_kerberos_failure,      /* Error during kerberos function call */
  E_mucom_server_failure,      /* Error on server side */
  E_mucom_last				/* end of mucom errors */
};

#endif
