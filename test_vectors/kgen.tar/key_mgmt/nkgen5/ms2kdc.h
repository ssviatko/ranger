#ifndef MS2KDC_H
#define MS2KDC_H

#include <stdio.h>
#include <time.h>
#include <k5-int.h>
#include <kv5m_err.h>
#include <krb5.h>
#include <kadm5/admin.h>
#include <kadm5/server_internal.h>

#ifdef __cplusplus
extern "C" {
#endif

#undef major  /* solaris has these defined... */
#undef minor


typedef struct _ms2_sts {
  long           major;
  long           minor;
} ms2_sts;

typedef struct _ms2_principal {
  char           *name;
  char           *realmname;
} ms2_principal;

typedef struct _ms2_context {
  char  def_realm[64];
  void* handle;
  krb5_context context;
} ms2_context;



ms2_sts ms2addPrincipal(ms2_context *ms2context,
			char* prnName);

ms2_sts ms2connectWithPwd(ms2_context *ms2context,
			  const ms2_principal* adminPrn,
			  char* password);

ms2_sts ms2disconnect(ms2_context *);


void ms2freePrincipalContents(
  ms2_principal *
);

ms2_sts ms2getPrincipalKeys(ms2_context *ms2context,
			    char* prnName,
			    krb5_keyblock *pkeyblock,
			    unsigned int *pkvno);

int ms2mayAddPrincipal(
  ms2_context         *,
  const ms2_principal *
);


int ms2mayGetPrincipalKeys(
  ms2_context          *,
  const ms2_principal  *
);


int ms2mayModifyPrincipal(
  ms2_context          *,
  const ms2_principal  *
);

ms2_sts ms2modifyPrincipal(ms2_context *ms2context,  
			   char* prnName,
			   krb5_keyblock *pkeyblock);


char *ms2strError(
  const ms2_sts *
);

ms2_sts ms2stringToPrincipal(
  const char      *,
  const char      *,
  ms2_principal *
);

#ifdef __cplusplus
}
#endif

#endif
