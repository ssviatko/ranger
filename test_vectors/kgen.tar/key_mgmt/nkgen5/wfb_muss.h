/**************************************************************
 *
 *  MODULE NAME:
 *
 *      wfb_muss.h
 *
 *  FACILITY:
 *
 *      Wells Fargo Bank
 *
 *  ABSTRACT:
 *
 *  CHANGE HISTORY:
 *
 *
 *************************************************************/

#ifndef _wfb_muss_h
#define _wfb_muss_h

#include "muss_error.h"

/* Some Muss defines */
#define MUSS_TRUE	1
#define MUSS_FALSE	0

/* Kerberos */
#define 	KRB5CCNAME		"KRB5CCNAME"
#define 	KRB_FILE		"FILE"
#define 	KRB5TKNAME		"KRB5TKNAME"
#define		PRINCIPAL		"PRINCIPAL"
#define		MTHD_SVR_PRINCIPAL	"MthdSvrPRINCIPAL"
#define		CRED_CACHE_DIR		"CredCacheDIR"
#define		KEY_TAB_FILE		"KeyTabFILE"
#define		TGT_PATH		"TGT_PATH"
#define		TGT_LIFETIME		"TGT_LIFETIME"

/* Token Size (wild guess for size) */
#define		BUFF_16K		16384
#define		BUFF_32K		32768
#define		BUFF_64K		65536
#define		TOKEN_BUFF_SIZE		BUFF_16K
#define		SEALED_BUFF_SIZE	BUFF_64K


/* maximum length of a fully qualified domain name for a principal */
#define MUSS_MAX_FQDN          256

/* maximum length of a path name */
#define MUSS_MAX_PATH          512

/* maximum number of options to csf_gss_acq_usr() function */
#define MUSS_MAX_NUM_OPTS      10

/* default 'client acquire' program - to obtain TGT for method server */
#define MUSS_TGT_PATH		"kinit"

/* default requested lifetime of TGT in hours */
#define MUSS_TGT_LIFETIME	"24h"

#define MUSS_LIFE_TIME_LEN	16

#define MUSS_ERROR_TEXT_LEN	256

/* Our type definitions */
typedef	char			FQD_NameT [MUSS_MAX_FQDN];
typedef	void *			MUSS_VoidPtr;
typedef unsigned char	MUSS_Uchar;
typedef unsigned char*	MUSS_UcharPtr;

typedef unsigned long   MUSS_U32int;
typedef long            MUSS_S32int;

/* Muss Context types */
typedef void *			MUSS_Context_t;

/* Diagnostic information goes here */
typedef struct _MussDiagnostic {
  MUSS_U32int	minor;
  MUSS_U32int	major;
  char		error_text[MUSS_ERROR_TEXT_LEN +1];
} MussDiagnostic;


// defined in kgen.c
extern FILE* logfile;

#ifdef __cplusplus
extern "C" {
#endif

int muss_gssSeal(char *,		/* IN  - message buffer		*/ 
		 int   ,		/* IN  - message length		*/
		 char *,		/* IN  - Remove principal name  */
		 MUSS_VoidPtr , 	/* OUT - Sealed message		*/
		 int *, 		/* OUT - Sealed message length	*/
		 MUSS_VoidPtr ,		/* OUT - Token 			*/
		 int *,			/* OUT - Token length		*/
		 MUSS_VoidPtr *);	/* OUT - Muss context		*/

int muss_gssUnseal(MUSS_VoidPtr , 	/* IN  - Sealed message		*/
		   int, 		/* IN  - Sealed message length	*/
		   char *,		/* OUT - Unsealed message	*/
		   int *,		/* OUT - Unsealed message length*/ 
		   MUSS_VoidPtr *);	/* OUT - Muss context		*/

int muss_setupKerberos (char *,	/* IN - Key tab			*/
			 char *,	/* IN - Client Principal		*/
			 char *,	/* IN - Cache			*/
			 char *);   	/* IN - hours			*/


int muss_gssObtainTGT (void);

void muss_gssNotifyFailure(MussDiagnostic *);	/* IN  - Diagnostic info    */

void muss_gssGetDiagnosticText(char *);	/* OUT - Last error message */

void muss_gssCleanUp(MUSS_VoidPtr *);

#ifdef __cplusplus
}
#endif

#endif
