/* definitions */


#define  PRNNAME_SZ	  64
#define  LOGNAME "kgen"
#define  KEYTAB_LEN 1024
#define  MVS_KEYTAB_LEN KEYTAB_LEN * 2
#define  MAX_FILE_PATH	128
#define  MAXPKIKEYLEN   450

/* #define KEYTYPE_NULL     0 */
/* #define KEYTYPE_DES      1 */
/* #define KEYTYPE_DES3     7 */
#define KEYTYPE_DES3     5 
#define KEYTYPE_AES128   17
#define KEYTYPE_AES256   18
#define KEYTYPE_ARCFOUR  23
#define KEYTYPE_ARCFOUR_56 24

/* **************** pwoerbroker changes start 06/20/1999 **************/
struct hosts_node {
	char host_type; /* UNIX(U) or MVS(M) principal */
	char * realm_name; /* kerberos realm name ex: TEST.WELLSFARGO.COM */
	char admin_principal_name[32]; /* principal used by remote host */
	char principal_name[32];	   /* principal being refeshed */
	char host_name[64];			     /* remote host */
	char port_str[16];			     /* port number */
	char * ktfile_path;		       /* key tab file path */
	char * ktfile_name;		       /* keytab file name */
	char * ktfile_owner;         /* keytab file owner RC 12/23/97 */
	char * ktfile_group;         /* keytab file group RC 12/23/97 */
	char last_modified[32];      /* date & time of the last modification */
	char next_modification[32];  /* date & time of the next modification */
	char modify_freq[32];		     /* frequency of keytab refresh */
	char * comment_str;          /* used only if principal_type = '#' */
	struct hosts_node *p2next;
};

/*********************** powerbroker changs end here *******************/
struct llist_node {
	char principal_type; /* UNIX(U) or MVS(M) principal */
	char realm_name[32]; /* kerberos realm name ex: TEST.WELLSFARGO.COM */
	char admin_principal_name[32]; /* principal used by remote host */
	char principal_name[64];	   /* principal being refeshed */
	char host_name[32];			   /* remote host */
	char port_str[16];			   /* port number */
	char ktfile_path[32];		   /* key tab file path */
	char ktfile_name[32];		   /* keytab file name */
	char ktfile_owner[32];         /* keytab file owner RC 12/23/97 */
	char ktfile_group[32];         /* keytab file group RC 12/23/97 */
	char last_modified[32]; /* date & time of the last modification */
	char next_modification[32]; /* date & time of the next modification */
	char modify_freq[32];		/* frequency of keytab refresh */
	char * comment_str; /* used only if principal_type = '#' */
	struct llist_node *p2next;
	struct hosts_node *p3next;  /* powerbroker change 06/20/1999 */
	char principal_type2;
	char  action[10];      /* new or old */
};


typedef struct llist_node llPRINCIPAL;
typedef struct llist_node *pllPRINCIPAL;
typedef struct hosts_node HOSTNAMES;

struct admin {
		char name[128];
		char realm[128];
		char password[128];
};


#define ENVVARLEN 128
struct env {
	char principal_db[ENVVARLEN]; /*principal for session establishment*/
	char krb5_principal_name[ENVVARLEN]; /*principal to obtain TGT */
	char kt_filename[ENVVARLEN];        /* keytab file of the principal */
	char krb5_ccname[ENVVARLEN];        /* credential cache name */
	char kinit_pgm[ENVVARLEN];          /* kinit program with full path */
	char exe_path[ENVVARLEN];          /* KGEN executable path  */
};

