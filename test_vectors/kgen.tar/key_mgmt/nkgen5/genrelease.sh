cp pbkgen rc.pbkgen schedule.dat release/.
cd release 
tar cvf pbkgen.tar pbkgen rc.pbkgen schedule.dat pbdb.dat host_upd.pl pbrcphost.sh pbhosts pbkgen.install
