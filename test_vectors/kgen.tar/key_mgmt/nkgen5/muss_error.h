/**************************************************************
 *
 *  MODULE NAME:
 *
 *      muss_error.h
 *
 *  FACILITY:
 *
 *      Wells Fargo Bank
 *
 *  ABSTRACT:
 *
 *  CHANGE HISTORY:
 *
 *    Date        Who    Change Description
 *  ----------   ------  -----------------------------------------
 *  11-19-97	 laraj	 Create file.
 *
 *************************************************************/

#ifndef _muss_error_h
#define _muss_error_h

#ifdef __cplusplus
extern "C" {
#endif

#define EB_MUSS    520000

  enum {
    E_muss_OK    = 0,       	  
    E_muss_gen_failure=EB_MUSS,   /* 520000    */
    E_muss_invalid_principal,     /* 520001    */
    E_muss_fail_obtain_tgt,       /* 520002    */
    E_muss_gss_auth_error,        /* 520003    */
    E_muss_kerberize_buffer_err,  /* 520004    */
    E_muss_seal_fail,		  /* 520005    */
    E_muss_unseal_fail,		  /* 520006    */
    E_muss_kerberos_setup_fail,	  /* 520007    */
    E_muss_import_name,		  /* 520008    */
    E_muss_set_sec_ctx_fail,	  /* 520009    */
    E_muss_last                   /* 5200??    */
  };


#ifdef __cplusplus
}
#endif

#endif
