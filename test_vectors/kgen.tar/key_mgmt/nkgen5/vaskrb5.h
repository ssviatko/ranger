/** 
 * Copyright 2004 Vintela, Inc.  -  All Rights Reserved
 * 
 * This header file is distributed as part of the Vintela Authentication 
 * Services (VAS) distribution governed by the Vintela Authentication 
 * Services (VAS) Software End User License Agreement (the "EULA"). 
 * This header file is part of the "Licensed Software" licensed to a 
 * Licensee under the EULA.  The Licensee may use information learned 
 * from this file to develop software applications that use the libvas 
 * library of VAS as permitted by the EULA, and for no other purpose.  
 * If you are not the Licensee under the EULA, then you do not have any 
 * license to use this file or any information in it. 
 * 
 **/
 
/** @file
 * Header file for the VAS Kerberos implementation. This header file is
 * source compatible with the Heimdal Kerberos project.  The libvas Kerberos
 * implementation is not binary compatible with the Heimdal Kerberos library.
 * Applications that use the Heimdal API must be recompiled in order to 
 * work with libvas.so.
 * 
 * The VAS Kerberos implementation is in libvas.so. DO NOT link in a separate
 * Kerberos library. 
 * 
 * The Kerberos API is very complex. For a simplified method of authenticating
 * users against Active Directory with Kerberos ticket requests, and for
 * changing and setting user passwords, use the VAS API. Due to the size
 * of the Heimdal API, the documentation for the Kerberos functions is
 * incomplete.
 * 
 **/


#ifndef KRB5_H_INCLUDED
#define KRB5_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include <time.h>       /* for the time_t type */
#include <stdarg.h>     /* for va_* types */
#include <krb5_types.h> /* for platform specific types */

/* Error Table headers */
#include <asn1_err.h>
#include <krb5_err.h>
#include <heim_err.h>
#include <k524_err.h>

/* Kerberos asn1 definitions */
#include <krb5_asn1.h>

/* MIT Kerberos Compatibility for this error code name */
#ifndef KRB5KDC_ERR_KEY_EXP
#define KRB5KDC_ERR_KEY_EXP KRB5KDC_ERR_KEY_EXPIRED
#endif

/* Ensure that these simple constants are defined */
#ifndef TRUE
# define TRUE  1
#endif
#ifndef FALSE
# define FALSE 0
#endif


/** The Kerberos boolean type. */
typedef int krb5_boolean;

/** The Kerberos error code type. */
typedef int32_t krb5_error_code;

/** The Kerberos Key version number type. */
typedef int krb5_kvno;

/** The Kerberos flags type. */
typedef u_int32_t krb5_flags;

/** A Kerberos pointer. */
typedef void* krb5_pointer;

/** A Kerberos const pointer. */
typedef const void* krb5_const_pointer;

/** A Kerberos data pointer defined from an ASN1 type. */
typedef octet_string krb5_data;

struct krb5_crypto_data;
typedef struct krb5_crypto_data* krb5_crypto;

/** Kerberos type for check sum type from the ASN1 type. */
typedef CKSUMTYPE krb5_cksumtype;

/** Kerberos type for check sum from the ASN1 type. */
typedef Checksum krb5_checksum;

/** Kerberos type for encoding type from the ASN1 type. */
typedef ENCTYPE krb5_enctype;

/** Alternative names for encoding types. */
enum 
{
    ENCTYPE_NULL                = ETYPE_NULL,
    ENCTYPE_DES_CBC_CRC         = ETYPE_DES_CBC_CRC,
    ENCTYPE_DES_CBC_MD4         = ETYPE_DES_CBC_MD4,
    ENCTYPE_DES_CBC_MD5         = ETYPE_DES_CBC_MD5,
    ENCTYPE_DES3_CBC_MD5        = ETYPE_DES3_CBC_MD5,
    ENCTYPE_OLD_DES3_CBC_SHA1   = ETYPE_OLD_DES3_CBC_SHA1,
    ENCTYPE_SIGN_DSA_GENERATE   = ETYPE_SIGN_DSA_GENERATE,
    ENCTYPE_ENCRYPT_RSA_PRIV    = ETYPE_ENCRYPT_RSA_PRIV,
    ENCTYPE_ENCRYPT_RSA_PUB     = ETYPE_ENCRYPT_RSA_PUB,
    ENCTYPE_DES3_CBC_SHA1       = ETYPE_DES3_CBC_SHA1,
    ENCTYPE_ARCFOUR_HMAC_MD5    = ETYPE_ARCFOUR_HMAC_MD5,
    ENCTYPE_ARCFOUR_HMAC_MD5_56 = ETYPE_ARCFOUR_HMAC_MD5_56,
    ENCTYPE_ENCTYPE_PK_CROSS    = ETYPE_ENCTYPE_PK_CROSS,
    ENCTYPE_DES_CBC_NONE        = ETYPE_DES_CBC_NONE,
    ENCTYPE_DES3_CBC_NONE       = ETYPE_DES3_CBC_NONE,
    ENCTYPE_DES_CFB64_NONE      = ETYPE_DES_CFB64_NONE,
    ENCTYPE_DES_PCBC_NONE       = ETYPE_DES_PCBC_NONE
};

/** Kerberos type for preauth data from the ASN1 type. */
typedef PADATA_TYPE krb5_preauthtype;


/** Enum defining different types of key usage. 
 * Section numbers refer to the sections of RFC 1510.
 **/
typedef enum krb5_key_usage 
{
    KRB5_KU_PA_ENC_TIMESTAMP = 1, /**< AS-REQ PA-ENC-TIMESTAMP padata 
                                   * timestamp, encrypted with the
                                   * client key (see section 5.4.1) */
    
    KRB5_KU_TICKET = 2, /**< AS-REP Ticket and TGS-REP Ticket (includes 
                         * tgs session key or application session key), 
                         * encrypted with the service key (see section 
                         * 5.4.2) */
    
    KRB5_KU_AS_REP_ENC_PART = 3, /**< AS-REP encrypted part (includes 
                                  * tgs session key or application
                                  * session key), encrypted with the 
                                  * client key (see section 5.4.2) */
    
    KRB5_KU_TGS_REQ_AUTH_DAT_SESSION = 4, /**< TGS-REQ KDC-REQ-BODY 
                                           * AuthorizationData, encrypted 
                                           * with the tgs session key (see 
                                           * section 5.4.1) */
    
    KRB5_KU_TGS_REQ_AUTH_DAT_SUBKEY = 5, /**< TGS-REQ KDC-REQ-BODY 
                                          * AuthorizationData, encrypted 
                                          * with the tgs authenticator 
                                          * subkey (see section 5.4.1) */
    
    KRB5_KU_TGS_REQ_AUTH_CKSUM = 6, /**< TGS-REQ PA-TGS-REQ padata AP-REQ 
                                     * Authenticator cksum, keyed with the 
                                     * tgs session key (see sections 5.3.2, 
                                     * 5.4.1) */

    KRB5_KU_TGS_REQ_AUTH = 7, /**< TGS-REQ PA-TGS-REQ padata AP-REQ 
                               * Authenticator (includes tgs authenticator 
                               * subkey), encrypted with the tgs session key
                               * (see section 5.3.2) */
    
    KRB5_KU_TGS_REP_ENC_PART_SESSION = 8, /**< TGS-REP encrypted part 
                                           * (includes application session key),
                                           * encrypted with the tgs session 
                                           * key (see section 5.4.2) */

    KRB5_KU_TGS_REP_ENC_PART_SUB_KEY = 9, /**< TGS-REP encrypted part 
                                           * (includes application session 
                                           * key), encrypted with the tgs
                                           * authenticator subkey (see section
                                           * 5.4.2) */

    KRB5_KU_AP_REQ_AUTH_CKSUM = 10, /**< AP-REQ Authenticator cksum, keyed 
                                     * with the application session key 
                                     * (see section 5.3.2) */

    KRB5_KU_AP_REQ_AUTH = 11, /**< AP-REQ Authenticator (includes application
                               * authenticator subkey), encrypted with the 
                               * application session key (see section 
                               * 5.3.2) */

    KRB5_KU_AP_REQ_ENC_PART = 12, /**< AP-REP encrypted part (includes 
                                   * application session subkey), encrypted 
                                   * with the application session key 
                                   * (see section 5.5.2) */

    KRB5_KU_KRB_PRIV = 13, /**< KRB-PRIV encrypted part, encrypted with a 
                            * key chosen by the application (see section 
                            * 5.7.1) */

    KRB5_KU_KRB_CRED = 14, /**< KRB-CRED encrypted part, encrypted with a 
                            * key chosen by the application (see section 
                            * 5.8.1) */

    KRB5_KU_KRB_SAFE_CKSUM = 15, /**< KRB-SAFE cksum, keyed with a key 
                                  * chosen by the application (see 
                                  * section 5.6.1) */

    KRB5_KU_OTHER_ENCRYPTED = 16, /**< Data which is defined in some 
                                   * specification outside of Kerberos 
                                   * to be encrypted using an 
                                   * RFC1510 encryption type. */

    KRB5_KU_OTHER_CKSUM = 17, /**< Data which is defined in some 
                               * specification outside of Kerberos to
                               * be checksummed using an RFC1510 
                               * checksum type. */

    KRB5_KU_KRB_ERROR = 18, /**< Krb-error checksum. */

    KRB5_KU_AD_KDC_ISSUED = 19, /**< AD-KDCIssued checksum. */

    KRB5_KU_MANDATORY_TICKET_EXTENSION = 20, /**< Checksum for Mandatory 
                                              * Ticket Extensions. */

    KRB5_KU_AUTH_DATA_TICKET_EXTENSION = 21, /**< Checksum in Authorization 
                                              * Data in Ticket Extensions */
    
    KRB5_KU_USAGE_SEAL = 22, /* Seal in GSSAPI krb5 mechanism */

    KRB5_KU_USAGE_SIGN = 23, /* Sign in GSSAPI krb5 mechanism */

    KRB5_KU_USAGE_SEQ = 24 /* SEQ in GSSAPI krb5 mechanism */

} krb5_key_usage;


/** Type definition for MIT compatibility. */
typedef krb5_key_usage krb5_keyusage;


/** Different types of salts used. */
typedef enum krb5_salttype 
{
    KRB5_PW_SALT     = KRB5_PADATA_PW_SALT,
    KRB5_AFS3_SALT   = KRB5_PADATA_AFS3_SALT
} krb5_salttype;


/** Struct that represents a salt. */
typedef struct krb5_salt 
{
    krb5_salttype   salttype; /**< The type of salt. */
    krb5_data       saltvalue; /**< The actual salt data. */
} krb5_salt;


/** The Kerberos preauthinfo type from the ASN1 type. */
typedef ETYPE_INFO krb5_preauthinfo;


/** Struct that represents a preauth data entry. */
typedef struct 
{
    krb5_preauthtype type; /**< The type of preauth data. */
    krb5_preauthinfo info; /**< The actual preauthinfo data. */
} krb5_preauthdata_entry;


/** Struct that represents the preauth data. */
typedef struct krb5_preauthdata 
{
    unsigned len; /**< The size of the preauth data. */
    krb5_preauthdata_entry* val; /**< The actual preauthdat values. */
} krb5_preauthdata;


/** The different types of addresses recognized. */
typedef enum krb5_address_type 
{
    KRB5_ADDRESS_INET     =   2,
    KRB5_ADDRESS_INET6    =  24,
    KRB5_ADDRESS_ADDRPORT = 256,
    KRB5_ADDRESS_IPPORT   = 257
} krb5_address_type;


/** The different options for key usage. */
enum
{
  AP_OPTS_USE_SESSION_KEY = 1,
  AP_OPTS_MUTUAL_REQUIRED = 2,
  AP_OPTS_USE_SUBKEY      = 4
};


/** The Kerberos host address type from the ASN1 type. */
typedef HostAddress krb5_address;


/** The Kerberos host addresses type from the ASN1 type. */
typedef HostAddresses krb5_addresses;


/** The different supported key types. */
typedef enum krb5_keytype { 
    KEYTYPE_NULL    = 0,
    KEYTYPE_DES     = 1,
    KEYTYPE_DES3    = 7,
    KEYTYPE_AES128  = 17,
    KEYTYPE_AES256  = 18,
    KEYTYPE_ARCFOUR = 23,
    KEYTYPE_ARCFOUR_56 = 24
} krb5_keytype;

/** The Kerberos Encryption Key type from the ASN1 type. */
typedef EncryptionKey krb5_keyblock;

/** The Kerberos ap_req type from the ASN1 type. */
typedef AP_REQ krb5_ap_req;

/** Struct declaration for the credential cache operations. Declared
 * here for struct declaration reasons. */ 
struct krb5_cc_ops;

/** The default location for file credential caches. By default,
 * VAS will attempt to store ticket caches in user's home directories.
 **/
#define KRB5_DEFAULT_CCFILE_ROOT "/tmp/krb5cc_"

/** The default ticket location prefixed with the credential cache type. */
#define KRB5_DEFAULT_CCROOT "FILE:"KRB5_DEFAULT_CCFILE_ROOT

/** Define to determine if we should use NULL addresses. */
#define KRB5_ACCEPT_NULL_ADDRESSES(C)                      \
    krb5_config_get_bool_default( (C), NULL, TRUE,         \
                                  "libdefaults",           \
                                  "accept_null_addresses", \
                                  NULL )

/** Type for a cursor to iterate through a credenential cache. */
typedef void* krb5_cc_cursor;

/** Type for the struct that represents a credential cache. */
typedef struct krb5_ccache_data 
{
    const struct krb5_cc_ops* ops;
    krb5_data                 data;
} krb5_ccache_data;

/** The credential cache type, which is a pointer 
 * to a krb5_ccache_data struct. */
typedef struct krb5_ccache_data* krb5_ccache;

/** The Kerberos context type. This is declared here in this order for the
 * construction of other types. */
typedef struct krb5_context_data* krb5_context;

/** Kerberos type for a realm name from the ASN1 data type. */
typedef Realm krb5_realm;

/** Const realm type. */
typedef const char* krb5_const_realm;

/** Kerberos type for a principal from the ASN1 data type. */
typedef Principal krb5_principal_data;

/** The Kerberos Principal type that is actually used. */
typedef struct Principal* krb5_principal;

/** A const Principal pointer. */
typedef const struct Principal* krb5_const_principal;

/** Type for a Kerberos time difference. */
typedef time_t krb5_deltat;

/** Type for a Kerberos timestamp. */
typedef time_t krb5_timestamp;

/** The times that are important for each Kerberos ticket. */
typedef struct krb5_times 
{
  krb5_timestamp authtime;
  krb5_timestamp starttime;
  krb5_timestamp endtime;
  krb5_timestamp renew_till;
} krb5_times;

/** Typedefs added for compatability with the MIT krb5.h file */

#ifndef krb5_octet
typedef unsigned char   krb5_octet;
#endif
#ifndef krb6_ticket_times
typedef krb5_times      krb5_ticket_times;
#endif

typedef union 
{
    TicketFlags b;
    krb5_flags  i;
} krb5_ticket_flags;

/** Options that can be passed to krb5_get_in_tkt(). */
#define KDC_OPT_FORWARDABLE             (1 << 1)
#define KDC_OPT_FORWARDED               (1 << 2)
#define KDC_OPT_PROXIABLE               (1 << 3)
#define KDC_OPT_PROXY                   (1 << 4)
#define KDC_OPT_ALLOW_POSTDATE          (1 << 5)
#define KDC_OPT_POSTDATED               (1 << 6)
#define KDC_OPT_RENEWABLE               (1 << 8)
#define KDC_OPT_REQUEST_ANONYMOUS       (1 << 14)
#define KDC_OPT_DISABLE_TRANSITED_CHECK (1 << 26)
#define KDC_OPT_RENEWABLE_OK            (1 << 27)
#define KDC_OPT_ENC_TKT_IN_SKEY         (1 << 28)
#define KDC_OPT_RENEW                   (1 << 30)
#define KDC_OPT_VALIDATE                (1 << 31)

typedef union 
{
    KDCOptions b;
    krb5_flags i;
} krb5_kdc_flags;

/* Flags that can be passed to krb5_verify_ap_req. */
#define KRB5_VERIFY_AP_REQ_IGNORE_INVALID   (1 << 0)

#define KRB5_GC_CACHED          (1U << 0)
#define KRB5_GC_USER_USER       (1U << 1)

/* constants for compare_creds (and cc_retrieve_cred) */
#define KRB5_TC_DONT_MATCH_REALM    (1U << 31)
#define KRB5_TC_MATCH_KEYTYPE       (1U << 30)


/** The Kerberos type for authorization data from the ASN1 type. */
typedef AuthorizationData krb5_authdata;

/** The Kerberos type for Error data from the ASN1 type. */
typedef KRB_ERROR krb5_error;

/** Struct that represents Kerberos credentials. */
typedef struct krb5_creds 
{
    krb5_principal      client;
    krb5_principal      server;
    krb5_keyblock       session;
    krb5_times          times;
    krb5_data           ticket;
    krb5_data           second_ticket;
    krb5_authdata       authdata;
    krb5_addresses      addresses;
    krb5_ticket_flags   flags;
} krb5_creds;

/** Structure that holds the necessary functions for a credential cache. */
typedef struct krb5_cc_ops 
{
    const char*     prefix;
    
    const char*     (*get_name)( krb5_context, 
                                 krb5_ccache );
    
    krb5_error_code (*resolve)( krb5_context, 
                                krb5_ccache*, 
                                const char* );

    krb5_error_code (*gen_new)( krb5_context, krb5_ccache* );
    
    krb5_error_code (*init)( krb5_context, krb5_ccache, krb5_principal );
    
    krb5_error_code (*destroy)( krb5_context, krb5_ccache );
    
    krb5_error_code (*close)( krb5_context, krb5_ccache );
    
    krb5_error_code (*store)( krb5_context, krb5_ccache, krb5_creds* );
    
    krb5_error_code (*retrieve)( krb5_context, 
                                 krb5_ccache, 
                                 krb5_flags, 
                                 krb5_creds*, 
                                 krb5_creds );
    
    krb5_error_code (*get_princ)( krb5_context, 
                                  krb5_ccache, 
                                  krb5_principal* );
    
    krb5_error_code (*get_first)( krb5_context, 
                                  krb5_ccache, 
                                  krb5_cc_cursor* );
    
    krb5_error_code (*get_next)( krb5_context, 
                                 krb5_ccache, 
                                 krb5_cc_cursor*, 
                                 krb5_creds* );
    
    krb5_error_code (*end_get)( krb5_context, 
                                krb5_ccache, 
                                krb5_cc_cursor* );
    
    krb5_error_code (*remove_cred)( krb5_context, 
                                    krb5_ccache, 
                                    krb5_flags, 
                                    krb5_creds* );
    
    krb5_error_code (*set_flags)( krb5_context, 
                                  krb5_ccache, 
                                  krb5_flags );
    
    int (*get_version)( krb5_context, krb5_ccache );

} krb5_cc_ops;


struct krb5_log_facility;

struct krb5_config_binding 
{
    enum { krb5_config_string, krb5_config_list }   type;
    char*                                           name;
    struct krb5_config_binding*                     next;
    union 
    {
        char*                                       string;
        struct krb5_config_binding*                 list;
        void*                                       generic;
    } u;
};

typedef struct krb5_config_binding krb5_config_binding;

typedef krb5_config_binding krb5_config_section;

/** Structure that holds the Kerberos context data. */
typedef struct krb5_context_data 
{
    krb5_enctype*               etypes;
    krb5_enctype*               etypes_des;
    char**                      default_realms;
    time_t                      max_skew;
    time_t                      kdc_timeout;
    unsigned                    max_retries;
    int32_t                     kdc_sec_offset;
    int32_t                     kdc_usec_offset;
    krb5_config_section*        cf;
    struct et_list*             et_list;
    struct krb5_log_facility*   warn_dest;
    krb5_cc_ops*                cc_ops;
    int                         num_cc_ops;
    const char*                 http_proxy;
    const char*                 time_fmt;
    krb5_boolean                log_utc;
    const char*                 default_keytab;
    const char*                 default_keytab_modify;
    krb5_boolean                use_admin_kdc;
    krb5_addresses*             extra_addresses;
    krb5_boolean                scan_interfaces;
    krb5_boolean                srv_lookup; /**< Flag that specifies whether
                                             * or not DNS SRV lookups should
                                             * be used to detect Kerberos 
                                             * servers. */
    krb5_boolean                srv_try_txt; /**< Flag that specifies whether
                                              * or not DNS TXT lookups should
                                              * be used to detect Kerberos
                                              * servers. */
    int32_t                     fcache_vno; /**< The version of ticket cache
                                             * files to create. */
    int                         num_kt_types; /**< The number of registered
                                               * keytab types. */
    struct krb5_keytab_data*    kt_types;  /**< The registered types of 
                                            * keytabs. */
    const char*                 date_fmt;
    char*                       error_string;
    char                        error_buf[256];
    krb5_addresses*             ignore_addresses;

    char*                       default_cc_name;
    
    struct krb5_krbhst_data*    krbhst_kdc; /**< The list of KDC's to 
                                             * contact. */
    struct krb5_krbhst_data*    krbhst_admin; /**< The list of admin servers
                                               * to contact. */
    struct krb5_krbhst_data*    krbhst_changepw; /**< The list of password 
                                                  * change servers. */
    struct krb5_krbhst_data*    krbhst_krb524;  /**< The list of servers to 
                                                 * use for KerberosIV 
                                                 * compatibility. */
    
} krb5_context_data;


/** Structure that represents a Kerberos ticket. */
typedef struct krb5_ticket 
{
    EncTicketPart   ticket;
    krb5_principal  client;
    krb5_principal  server;
} krb5_ticket;

typedef Authenticator krb5_authenticator_data;

typedef krb5_authenticator_data* krb5_authenticator;

struct krb5_rcache_data;
typedef struct krb5_rcache_data* krb5_rcache;
typedef Authenticator krb5_donot_replay;

#define KRB5_STORAGE_HOST_BYTEORDER                 0x01 /* old */
#define KRB5_STORAGE_PRINCIPAL_WRONG_NUM_COMPONENTS 0x02
#define KRB5_STORAGE_PRINCIPAL_NO_NAME_TYPE         0x04
#define KRB5_STORAGE_KEYBLOCK_KEYTYPE_TWICE         0x08
#define KRB5_STORAGE_BYTEORDER_MASK                 0x60
#define KRB5_STORAGE_BYTEORDER_BE                   0x00 /* default */
#define KRB5_STORAGE_BYTEORDER_LE                   0x20
#define KRB5_STORAGE_BYTEORDER_HOST                 0x40

struct krb5_storage_data;
typedef struct krb5_storage_data krb5_storage;

typedef struct krb5_keytab_entry 
{
    krb5_principal  principal;
    krb5_kvno       vno;
    krb5_keyblock   keyblock;
    u_int32_t       timestamp;
} krb5_keytab_entry;

typedef struct krb5_kt_cursor 
{
    int             fd;
    krb5_storage*   sp;
    void*           data;
} krb5_kt_cursor;

struct krb5_keytab_data;

typedef struct krb5_keytab_data*    krb5_keytab;

#define KRB5_KT_PREFIX_MAX_LEN  30


struct krb5_keytab_data 
{
    const char* prefix;

    krb5_error_code (*resolve)( krb5_context, const char*, krb5_keytab );
    
    krb5_error_code (*get_name)( krb5_context, krb5_keytab, char*, size_t );
    
    krb5_error_code (*close)( krb5_context, krb5_keytab );
    
    krb5_error_code (*get)( krb5_context, 
                            krb5_keytab, 
                            krb5_const_principal, 
                            krb5_kvno, 
                            krb5_enctype, 
                            krb5_keytab_entry* );

    krb5_error_code (*start_seq_get)( krb5_context, 
                                      krb5_keytab, 
                                      krb5_kt_cursor* );
    
    krb5_error_code (*next_entry)( krb5_context, 
                                   krb5_keytab, 
                                   krb5_keytab_entry*, 
                                   krb5_kt_cursor* );
    
    krb5_error_code (*end_seq_get)( krb5_context, 
                                    krb5_keytab, 
                                    krb5_kt_cursor* );
    
    krb5_error_code (*add)( krb5_context, 
                            krb5_keytab, 
                            krb5_keytab_entry* );
    
    krb5_error_code (*remove)( krb5_context, 
                               krb5_keytab, 
                               krb5_keytab_entry* );
    
    void* data;
    
    int32_t version;

};


typedef struct krb5_keytab_data krb5_kt_ops;

struct krb5_keytab_key_proc_args 
{
    krb5_keytab     keytab;
    krb5_principal  principal;
};

typedef struct krb5_keytab_key_proc_args krb5_keytab_key_proc_args;

typedef struct krb5_replay_data 
{
    krb5_timestamp  timestamp;
    u_int32_t       usec;
    u_int32_t       seq;
} krb5_replay_data;


/* flags for krb5_auth_con_setflags */
enum {
    KRB5_AUTH_CONTEXT_DO_TIME      = 1,
    KRB5_AUTH_CONTEXT_RET_TIME     = 2,
    KRB5_AUTH_CONTEXT_DO_SEQUENCE  = 4,
    KRB5_AUTH_CONTEXT_RET_SEQUENCE = 8,
    KRB5_AUTH_CONTEXT_PERMIT_ALL   = 16
};

/* flags for krb5_auth_con_genaddrs */
enum {
    KRB5_AUTH_CONTEXT_GENERATE_LOCAL_ADDR       = 1,
    KRB5_AUTH_CONTEXT_GENERATE_LOCAL_FULL_ADDR  = 3,
    KRB5_AUTH_CONTEXT_GENERATE_REMOTE_ADDR      = 4,
    KRB5_AUTH_CONTEXT_GENERATE_REMOTE_FULL_ADDR = 12
};


typedef struct krb5_auth_context_data 
{
    unsigned int        flags;

    krb5_address*       local_address;
    krb5_address*       remote_address;
    int16_t             local_port;
    int16_t             remote_port;
    krb5_keyblock*      keyblock;
    krb5_keyblock*      local_subkey;
    krb5_keyblock*      remote_subkey;

    u_int32_t           local_seqnumber;
    u_int32_t           remote_seqnumber;

    krb5_authenticator  authenticator;
  
    krb5_pointer        i_vector;
  
    krb5_rcache         rcache;

    krb5_keytype        keytype;   /* requested key type ? */
    krb5_cksumtype      cksumtype;   /* requested checksum type! */
  
} krb5_auth_context_data, *krb5_auth_context;


typedef struct 
{
    KDC_REP         kdc_rep;
    EncKDCRepPart   enc_part;
    KRB_ERROR       error;
} krb5_kdc_rep;

extern const char* heimdal_version;
extern const char* heimdal_long_version;

typedef void (*krb5_log_log_func_t)( const char*, const char*, void* );
typedef void (*krb5_log_close_func_t)( void* );

typedef struct krb5_log_facility 
{
    const char*         program;
    int                 len;
    struct facility*    val;
} krb5_log_facility;

typedef EncAPRepPart krb5_ap_rep_enc_part;

#define KRB5_RECVAUTH_IGNORE_VERSION 1

#define KRB5_SENDAUTH_VERSION "KRB5_SENDAUTH_V1.0"

#define KRB5_TGS_NAME_SIZE  (6)
#define KRB5_TGS_NAME       ("krbtgt")

/* variables */

extern const char* krb5_config_file;
extern const char* krb5_defkeyname;

typedef enum 
{
    KRB5_PROMPT_TYPE_PASSWORD           = 0x1,
    KRB5_PROMPT_TYPE_NEW_PASSWORD       = 0x2,
    KRB5_PROMPT_TYPE_NEW_PASSWORD_AGAIN = 0x3,
    KRB5_PROMPT_TYPE_PREAUTH            = 0x4
} krb5_prompt_type;

typedef struct _krb5_prompt 
{
    const char*         prompt;
    int                 hidden; 
    krb5_data*          reply;
    krb5_prompt_type    type;
} krb5_prompt;

typedef int (*krb5_prompter_fct)( krb5_context context,
                                  void* data,
                                  const char* name,
                                  const char* banner,
                                  int num_prompts,
                                  krb5_prompt prompts[] );

typedef krb5_error_code (*krb5_key_proc)( krb5_context context,
                                          krb5_enctype type,
                                          krb5_salt salt,
                                          krb5_const_pointer keyseed,
                                          krb5_keyblock** key );

typedef krb5_error_code (*krb5_decrypt_proc)( krb5_context context,
                                              krb5_keyblock* key,
                                              krb5_key_usage usage,
                                              krb5_const_pointer decrypt_arg,
                                              krb5_kdc_rep* dec_rep );


typedef struct _krb5_get_init_creds_opt 
{
    krb5_flags          flags;
    krb5_deltat         tkt_life;
    krb5_deltat         renew_life;
    int                 forwardable;
    int                 proxiable;
    int                 anonymous;
    krb5_enctype*       etype_list;
    int                 etype_list_length;
    krb5_addresses*     address_list;
    krb5_preauthtype*   preauth_list; /**< Deprecated. do not use. */
    int                 preauth_list_length; /**< Deprecated. do not use. */
    krb5_data*          salt; /**< Deprecated. do not use. */
} krb5_get_init_creds_opt;

#define KRB5_GET_INIT_CREDS_OPT_TKT_LIFE        0x0001
#define KRB5_GET_INIT_CREDS_OPT_RENEW_LIFE      0x0002
#define KRB5_GET_INIT_CREDS_OPT_FORWARDABLE     0x0004
#define KRB5_GET_INIT_CREDS_OPT_PROXIABLE       0x0008
#define KRB5_GET_INIT_CREDS_OPT_ETYPE_LIST      0x0010
#define KRB5_GET_INIT_CREDS_OPT_ADDRESS_LIST    0x0020
#define KRB5_GET_INIT_CREDS_OPT_PREAUTH_LIST    0x0040
#define KRB5_GET_INIT_CREDS_OPT_SALT            0x0080
#define KRB5_GET_INIT_CREDS_OPT_ANONYMOUS       0x0100

typedef struct _krb5_verify_init_creds_opt 
{
    krb5_flags  flags;
    int         ap_req_nofail;
} krb5_verify_init_creds_opt;

#define KRB5_VERIFY_INIT_CREDS_OPT_AP_REQ_NOFAIL    0x0001

typedef struct krb5_verify_opt 
{
    unsigned int    flags;
    krb5_ccache     ccache;
    krb5_keytab     keytab;
    krb5_boolean    secure;
    const char*     service;
} krb5_verify_opt;

#define KRB5_VERIFY_LREALMS         1
#define KRB5_VERIFY_NO_ADDRESSES    2

extern const krb5_cc_ops krb5_fcc_ops;
extern const krb5_cc_ops krb5_mcc_ops;

extern const krb5_kt_ops krb5_fkt_ops;
extern const krb5_kt_ops krb5_mkt_ops;
extern const krb5_kt_ops krb5_akf_ops;
extern const krb5_kt_ops krb4_fkt_ops;
extern const krb5_kt_ops krb5_srvtab_fkt_ops;
extern const krb5_kt_ops krb5_any_ops;

#define KRB5_KPASSWD_VERS_CHANGEPW      1 
#define KRB5_KPASSWD_VERS_SETPW         0xff80

#define KRB5_KPASSWD_SUCCESS             0
#define KRB5_KPASSWD_MALFORMED           1
#define KRB5_KPASSWD_HARDERROR           2
#define KRB5_KPASSWD_AUTHERROR           3
#define KRB5_KPASSWD_SOFTERROR           4
#define KRB5_KPASSWD_ACCESSDENIED        5 
#define KRB5_KPASSWD_BAD_VERSION         6 
#define KRB5_KPASSWD_INITIAL_FLAG_NEEDED 7


/** The standard KPASSWD server port. */
#define KPASSWD_PORT 464

/** The standard KDC port. This is a Vintela addition. */
#define KRB5_KDC_PORT 88


/* types for the new krbhst interface */
struct krb5_krbhst_data;
typedef struct krb5_krbhst_data* krb5_krbhst_handle;

/** The KDC Kerberos host type number. */
#define KRB5_KRBHST_KDC       1

/** The Admin Kerberos host type number. */
#define KRB5_KRBHST_ADMIN     2

/** The Password change Kerbeors host type number. */
#define KRB5_KRBHST_CHANGEPW  3

/** The KerberosIV compatibility host type number. */
#define KRB5_KRBHST_KRB524    4


/** Structure to represent a list of kerberos servers. */
typedef struct krb5_krbhst_info 
{
    enum { KRB5_KRBHST_UDP, KRB5_KRBHST_TCP, KRB5_KRBHST_HTTP } 
                             proto; /**< The protocol that should be used
                                     * when communicating with the server. */
    
    unsigned short           port;  /**< The port to use when communicating
                                     * the server. */
    
    unsigned short           def_port; /**< The default port to use if port
                                        * is not set. */
    
    time_t                   unreachable; /**< Vintela addition - allows us 
                                           * to skip servers which are 
                                           * down. */
    
    struct addrinfo*         ai; /**< The address information for the 
                                  * server. */
    
    struct krb5_krbhst_info* next; /**< The next server in the list. */
    
    char                     hostname[1]; /**< The hostname of the server.
                                           * Must come last in the struct
                                           * definition. */
} krb5_krbhst_info;


/** Struct declaration to prevent compiler errors. */
struct credentials;

/** Struct declaration to prevent compiler errors. */
struct getargs;

/** Struct declaration to prevent compiler errors. */
struct sockaddr;




/***************************************************************************
 *****                      Function Prototypes                        *****     
 ***************************************************************************/



void initialize_heim_error_table( void );


void initialize_heim_error_table_r( struct et_list** list );


void initialize_k524_error_table( void );


void initialize_k524_error_table_r( struct et_list** list );


void initialize_krb5_error_table( void );


void initialize_krb5_error_table_r( struct et_list** list );


krb5_error_code krb524_convert_creds_kdc( krb5_context context,
                                          krb5_creds* in_cred,
                                          struct credentials* v4creds );


krb5_error_code krb524_convert_creds_kdc_ccache( krb5_context context,
                                                 krb5_ccache ccache,
                                                 krb5_creds* in_cred,
                                                 struct credentials* v4creds );


krb5_error_code krb5_425_conv_principal( krb5_context context,
                                         const char* name,
                                         const char* instance,
                                         const char* realm,
                                         krb5_principal* princ );


krb5_error_code krb5_425_conv_principal_ext( krb5_context context,
                                             const char* name,
                                             const char* instance,
                                             const char* realm,
                                             krb5_boolean (*func)( krb5_context, 
                                                                   krb5_principal ),
                                             krb5_boolean resolve,
                                             krb5_principal* princ );


krb5_error_code krb5_524_conv_principal( krb5_context context,
                                         const krb5_principal principal,
                                         char* name,
                                         char* instance,
                                         char* realm );


krb5_error_code krb5_abort( krb5_context context,
                            krb5_error_code code,
                            const char* fmt,
                            ... )
#if defined(__GNUC__)
__attribute__ ((noreturn, format( printf, 3, 4 )));
#else
;
#endif



krb5_error_code krb5_abortx( krb5_context context,
                             const char* fmt,
                             ... )
#if defined(__GNUC__)
__attribute__ ((noreturn, format( printf, 2, 3 )));
#else
;
#endif


krb5_error_code krb5_acl_match_file( krb5_context context,
                                     const char *file,
                                     const char *format,
                                     ... );

krb5_error_code krb5_acl_match_string( krb5_context context,
                                       const char* string,
                                       const char* format,
                                       ... );

krb5_error_code krb5_add_et_list( krb5_context context,
                                  void (*func)( struct et_list** ) );

krb5_error_code krb5_add_extra_addresses( krb5_context context,
                                          krb5_addresses* addresses );

krb5_error_code krb5_add_ignore_addresses( krb5_context context,
                                           krb5_addresses* addresses );

krb5_error_code krb5_addlog_dest( krb5_context context,
                                  krb5_log_facility* f,
                                  const char* orig );

krb5_error_code krb5_addlog_func( krb5_context context,
                                  krb5_log_facility* fac,
                                  int min,
                                  int max,
                                  krb5_log_log_func_t log,
                                  krb5_log_close_func_t close,
                                  void* data );

krb5_error_code krb5_addr2sockaddr( krb5_context context,
                                    const krb5_address* addr,
                                    struct sockaddr* sa,
                                    krb5_socklen_t* sa_size,
                                    int port );

krb5_boolean krb5_address_compare( krb5_context context, 
                                   const krb5_address* addr1, 
                                   const krb5_address* addr2 );

int krb5_address_order( krb5_context context,
                        const krb5_address* addr1,
                        const krb5_address* addr2 );

krb5_boolean krb5_address_search( krb5_context context,
                                  const krb5_address* addr,
                                  const krb5_addresses* addrlist );

krb5_error_code krb5_aname_to_localname( krb5_context context,
                                         krb5_const_principal aname,
                                         size_t lnsize,
                                         char* lname );

krb5_error_code krb5_anyaddr( krb5_context context,
                              int af,
                              struct sockaddr* sa,
                              krb5_socklen_t* sa_size,
                              int port );

void krb5_appdefault_boolean( krb5_context context,
                              const char* appname,
                              krb5_const_realm realm,
                              const char* option,
                              krb5_boolean def_val,
                              krb5_boolean* ret_val );

void krb5_appdefault_string( krb5_context context,
                             const char* appname,
                             krb5_const_realm realm,
                             const char* option,
                             const char* def_val,
                             char** ret_val );

void krb5_appdefault_time( krb5_context context,
                           const char* appname,
                           krb5_const_realm realm,
                           const char* option,
                           time_t def_val,
                           time_t* ret_val );

krb5_error_code krb5_append_addresses( krb5_context context,
                                       krb5_addresses* dest,
                                       const krb5_addresses* source );

krb5_error_code krb5_auth_con_free( krb5_context context,
                                    krb5_auth_context auth_context );

krb5_error_code krb5_auth_con_genaddrs( krb5_context context,
                                        krb5_auth_context auth_context,
                                        int fd,
                                        int flags );

krb5_error_code krb5_auth_con_generatelocalsubkey( krb5_context context,
                                                   krb5_auth_context auth_context,
                                                   krb5_keyblock* key );

krb5_error_code krb5_auth_con_getaddrs( krb5_context context,
                                        krb5_auth_context auth_context,
                                        krb5_address** local_addr,
                                        krb5_address** remote_addr );

krb5_error_code
krb5_auth_con_getauthenticator( krb5_context context,
                                krb5_auth_context auth_context,
                                krb5_authenticator* authenticator );

krb5_error_code krb5_auth_con_getcksumtype( krb5_context context,
                                            krb5_auth_context auth_context,
                                            krb5_cksumtype* cksumtype );

krb5_error_code krb5_auth_con_getflags( krb5_context context,
                                        krb5_auth_context auth_context,
                                        int32_t* flags );

krb5_error_code krb5_auth_con_getkey( krb5_context context,
                                      krb5_auth_context auth_context,
                                      krb5_keyblock** keyblock );

krb5_error_code krb5_auth_con_getkeytype( krb5_context context,
                                          krb5_auth_context auth_context,
                                          krb5_keytype* keytype);

krb5_error_code krb5_auth_con_getlocalseqnumber( krb5_context context,
                                                 krb5_auth_context auth_context,
                                                 int32_t* seqnumber );

krb5_error_code krb5_auth_con_getlocalsubkey( krb5_context context,
                                              krb5_auth_context auth_context,
                                              krb5_keyblock** keyblock );

krb5_error_code krb5_auth_con_getrcache( krb5_context context,
                                         krb5_auth_context auth_context,
                                         krb5_rcache* rcache );

krb5_error_code krb5_auth_con_getremotesubkey( krb5_context context,
                                               krb5_auth_context auth_context,
                                               krb5_keyblock** keyblock);

krb5_error_code krb5_auth_con_init( krb5_context context,
                                    krb5_auth_context* auth_context );

krb5_error_code krb5_auth_con_setaddrs( krb5_context context,
                                        krb5_auth_context auth_context,
                                        krb5_address* local_addr,
                                        krb5_address* remote_addr );

krb5_error_code krb5_auth_con_setaddrs_from_fd( krb5_context context,
                                                krb5_auth_context auth_context,
                                                void* p_fd);

krb5_error_code krb5_auth_con_setcksumtype( krb5_context context,
                                            krb5_auth_context auth_context,
                                            krb5_cksumtype cksumtype );

krb5_error_code krb5_auth_con_setflags( krb5_context context,
                                        krb5_auth_context auth_context,
                                        int32_t flags );

krb5_error_code krb5_auth_con_setkey( krb5_context context,
                                      krb5_auth_context auth_context,
                                      krb5_keyblock* keyblock );

krb5_error_code krb5_auth_con_setkeytype( krb5_context context,
                                          krb5_auth_context auth_context,
                                          krb5_keytype keytype );

krb5_error_code krb5_auth_con_setlocalseqnumber( krb5_context context,
                                                 krb5_auth_context auth_context,
                                                 int32_t seqnumber );

krb5_error_code krb5_auth_con_setlocalsubkey( krb5_context context,
                                              krb5_auth_context auth_context,
                                              krb5_keyblock* keyblock );

krb5_error_code krb5_auth_con_setrcache( krb5_context context,
                                         krb5_auth_context auth_context,
                                         krb5_rcache rcache );

krb5_error_code krb5_auth_con_setremoteseqnumber( krb5_context context,
                                                  krb5_auth_context auth_context,
                                                  int32_t seqnumber );

krb5_error_code krb5_auth_con_setremotesubkey( krb5_context context,
                                               krb5_auth_context auth_context,
                                               krb5_keyblock* keyblock );

krb5_error_code krb5_auth_con_setuserkey( krb5_context context,
                                          krb5_auth_context auth_context,
                                          krb5_keyblock* keyblock );

krb5_error_code krb5_auth_getremoteseqnumber( krb5_context context,
                                              krb5_auth_context auth_context,
                                              int32_t* seqnumber );

krb5_error_code krb5_build_ap_req( krb5_context context,
                                   krb5_enctype enctype,
                                   krb5_creds* cred,
                                   krb5_flags ap_options,
                                   krb5_data authenticator,
                                   krb5_data* retdata );

krb5_error_code krb5_build_authenticator( krb5_context context,
                                          krb5_auth_context auth_context,
                                          krb5_enctype enctype,
                                          krb5_creds* cred,
                                          Checksum* cksum,
                                          Authenticator** auth_result,
                                          krb5_data* result,
                                          krb5_key_usage usage );

krb5_error_code krb5_build_principal( krb5_context context,
                                      krb5_principal* principal,
                                      int rlen,
                                      krb5_const_realm realm,
                                      ... );

krb5_error_code krb5_build_principal_ext( krb5_context context,
                                          krb5_principal* principal,
                                          int rlen,
                                          krb5_const_realm realm,
                                          ... );

krb5_error_code krb5_build_principal_va( krb5_context context,
                                         krb5_principal* principal,
                                         int rlen,
                                         krb5_const_realm realm,
                                         va_list ap );

krb5_error_code krb5_build_principal_va_ext( krb5_context context,
                                             krb5_principal* principal,
                                             int rlen,
                                             krb5_const_realm realm,
                                             va_list ap );

krb5_error_code krb5_cc_close( krb5_context context,
                               krb5_ccache id );

krb5_error_code krb5_cc_copy_cache( krb5_context context,
                                    const krb5_ccache from,
                                    krb5_ccache to );

krb5_error_code krb5_cc_default( krb5_context context,
                                 krb5_ccache* id );

const krb5_cc_ops* krb5_cc_get_ops(krb5_context context, krb5_ccache id);

krb5_error_code krb5_cc_set_default_name(krb5_context context, const char *name);

const char* krb5_cc_default_name( krb5_context context );

krb5_error_code krb5_cc_destroy( krb5_context context,
                                 krb5_ccache id );

krb5_error_code krb5_cc_end_seq_get( krb5_context context,
                                     const krb5_ccache id,
                                     krb5_cc_cursor* cursor );

krb5_error_code krb5_cc_gen_new( krb5_context context,
                                 const krb5_cc_ops* ops,
                                 krb5_ccache* id );

const char* krb5_cc_get_name( krb5_context context, krb5_ccache id );

krb5_error_code krb5_cc_get_principal( krb5_context context,
                                       krb5_ccache id,
                                       krb5_principal* principal );

const char* krb5_cc_get_type( krb5_context context, krb5_ccache id );

krb5_error_code krb5_cc_get_version( krb5_context context, 
                                     const krb5_ccache id );

krb5_error_code krb5_cc_initialize( krb5_context context,
                                    krb5_ccache id,
                                    krb5_principal primary_principal );

krb5_error_code krb5_cc_next_cred( krb5_context context,
                                   const krb5_ccache id,
                                   krb5_cc_cursor* cursor,
                                   krb5_creds* creds );

krb5_error_code krb5_cc_register( krb5_context context,
                                  const krb5_cc_ops* ops,
                                  krb5_boolean override );

krb5_error_code krb5_cc_remove_cred( krb5_context context,
                                     krb5_ccache id,
                                     krb5_flags which,
                                     krb5_creds* cred );

krb5_error_code krb5_cc_resolve( krb5_context context,
                                 const char* name,
                                 krb5_ccache* id );

krb5_error_code krb5_cc_retrieve_cred( krb5_context context,
                                       krb5_ccache id,
                                       krb5_flags whichfields,
                                       const krb5_creds* mcreds,
                                       krb5_creds* creds );

krb5_error_code krb5_cc_set_flags( krb5_context context,
                                   krb5_ccache id,
                                   krb5_flags flags );

krb5_error_code krb5_cc_start_seq_get( krb5_context context,
                                       const krb5_ccache id,
                                       krb5_cc_cursor* cursor );

krb5_error_code krb5_cc_store_cred( krb5_context context,
                                    krb5_ccache id,
                                    krb5_creds* creds );

krb5_error_code krb5_change_password( krb5_context context,
                                      krb5_creds* creds,
                                      char* newpw,
                                      int* result_code,
                                      krb5_data* result_code_string,
                                      krb5_data* result_string );

krb5_error_code krb5_check_transited_realms( krb5_context context,
                                             const char* const *realms,
                                             int num_realms,
                                             int* bad_realm);

krb5_boolean krb5_checksum_is_collision_proof( krb5_context context,
                                               krb5_cksumtype type );

krb5_boolean krb5_checksum_is_keyed( krb5_context context,
                                     krb5_cksumtype type );

krb5_error_code krb5_checksumsize( krb5_context context,
                                   krb5_cksumtype type,
                                   size_t* size );

void krb5_clear_error_string( krb5_context context );

krb5_error_code krb5_closelog( krb5_context context, 
                               krb5_log_facility* fac );

krb5_boolean krb5_compare_creds( krb5_context context,
                                 krb5_flags whichfields,
                                 const krb5_creds* mcreds,
                                 const krb5_creds* creds );

krb5_error_code krb5_config_file_free( krb5_context context,
                                       krb5_config_section* s );

void krb5_config_free_strings( char** strings );

const void* krb5_config_get( krb5_context context,
                             const krb5_config_section* c,
                             int type,
                             ... );

krb5_boolean krb5_config_get_bool( krb5_context context,
                                   const krb5_config_section* c,
                                   ... );

krb5_boolean krb5_config_get_bool_default( krb5_context context,
                                           const krb5_config_section* c,
                                           krb5_boolean def_value,
                                           ... );

int krb5_config_get_int( krb5_context context,
                         const krb5_config_section* c,
                         ... );

int krb5_config_get_int_default( krb5_context context,
                                 const krb5_config_section* c,
                                 int def_value,
                                 ... );

const krb5_config_binding*
krb5_config_get_list( krb5_context context,
                      const krb5_config_section* c,
                      ... );

const void* 
krb5_config_get_next( krb5_context context,
                      const krb5_config_section* c,
                      const krb5_config_binding** pointer,
                      int type,
                      ... );

const char* krb5_config_get_string( krb5_context context,
                                    const krb5_config_section* c,
                                    ... );

const char* krb5_config_get_string_default( krb5_context context,
                                            const krb5_config_section* c,
                                            const char* def_value,
                                            ...);

char** krb5_config_get_strings( krb5_context context,
                                const krb5_config_section* c,
                                ... );

int krb5_config_get_time( krb5_context context,
                          const krb5_config_section* c,
                          ... );

int krb5_config_get_time_default( krb5_context context,
                                  const krb5_config_section* c,
                                  int def_value,
                                  ... );

krb5_error_code krb5_config_parse_file( krb5_context context,
                                        const char* fname,
                                        krb5_config_section** res );

krb5_error_code krb5_config_parse_file_multi( krb5_context context,
                                              const char* fname,
                                              krb5_config_section** res );

const void* krb5_config_vget( krb5_context context,
                              const krb5_config_section* c,
                              int type,
                              va_list args );

krb5_boolean krb5_config_vget_bool( krb5_context context,
                                    const krb5_config_section* c,
                                    va_list args );

krb5_boolean krb5_config_vget_bool_default( krb5_context context,
                                            const krb5_config_section* c,
                                            krb5_boolean def_value,
                                            va_list args );

int krb5_config_vget_int( krb5_context context,
                          const krb5_config_section* c,
                          va_list args );

int krb5_config_vget_int_default( krb5_context context,
                                  const krb5_config_section* c,
                                  int def_value,
                                  va_list args );

const krb5_config_binding* krb5_config_vget_list( krb5_context context,
                                                  const krb5_config_section* c,
                                                  va_list args );

const void* krb5_config_vget_next( krb5_context context,
                                   const krb5_config_section* c,
                                   const krb5_config_binding** pointer,
                                   int type,
                                   va_list args );

const char* krb5_config_vget_string( krb5_context context,
                                     const krb5_config_section* c,
                                     va_list args );

const char* krb5_config_vget_string_default( krb5_context context,
                                             const krb5_config_section* c,
                                             const char* def_value,
                                             va_list args );

char** krb5_config_vget_strings( krb5_context context,
                                 const krb5_config_section* c,
                                 va_list args );

int krb5_config_vget_time( krb5_context context,
                           const krb5_config_section* c,
                           va_list args );

int krb5_config_vget_time_default( krb5_context context,
                                   const krb5_config_section* c,
                                   int def_value,
                                   va_list args );

krb5_error_code krb5_copy_address( krb5_context context,
                                   const krb5_address* inaddr,
                                   krb5_address* outaddr );

krb5_error_code krb5_copy_addresses( krb5_context context,
                                     const krb5_addresses* inaddr,
                                     krb5_addresses* outaddr );

krb5_error_code krb5_copy_creds( krb5_context context,
                                 const krb5_creds* incred,
                                 krb5_creds** outcred );

krb5_error_code krb5_copy_creds_contents( krb5_context context,
                                          const krb5_creds* incred,
                                          krb5_creds* c );

krb5_error_code krb5_copy_data( krb5_context context,
                                const krb5_data* indata,
                                krb5_data** outdata );

krb5_error_code krb5_copy_host_realm( krb5_context context,
                                      const krb5_realm* from,
                                      krb5_realm** to );

krb5_error_code krb5_copy_keyblock( krb5_context context,
                                    const krb5_keyblock* inblock,
                                    krb5_keyblock** to );

krb5_error_code krb5_copy_keyblock_contents( krb5_context context,
                                             const krb5_keyblock* inblock,
                                             krb5_keyblock* to );

krb5_error_code krb5_copy_principal( krb5_context context,
                                     krb5_const_principal inprinc,
                                     krb5_principal* outprinc );

krb5_error_code krb5_copy_ticket( krb5_context context,
                                  const krb5_ticket* from,
                                  krb5_ticket** to );

krb5_error_code krb5_create_checksum( krb5_context context,
                                      krb5_crypto crypto,
                                      krb5_key_usage usage,
                                      int type,
                                      void* data,
                                      size_t len,
                                      Checksum* result );

krb5_error_code krb5_crypto_destroy( krb5_context context,
                                     krb5_crypto crypto );

krb5_error_code krb5_crypto_getblocksize( krb5_context context,
                                          krb5_crypto crypto,
                                          size_t* blocksize );

krb5_error_code krb5_crypto_init( krb5_context context,
                                  const krb5_keyblock* key,
                                  krb5_enctype etype,
                                  krb5_crypto* crypto );

krb5_error_code krb5_data_alloc( krb5_data* p, int len );

krb5_error_code krb5_data_copy( krb5_data* p, 
                                const void* data, 
                                size_t len );

void krb5_data_free( krb5_data* p );

krb5_error_code krb5_data_realloc( krb5_data* p, int len );

void krb5_data_zero( krb5_data* p );

krb5_error_code krb5_decode_Authenticator( krb5_context context,
                                           const void* data,
                                           size_t length,
                                           Authenticator* t,
                                           size_t* len );

krb5_error_code krb5_decode_ETYPE_INFO( krb5_context context,
                                        const void* data,
                                        size_t length,
                                        ETYPE_INFO* t,
                                        size_t* len );

krb5_error_code krb5_decode_EncAPRepPart( krb5_context context,
                                          const void* data,
                                          size_t length,
                                          EncAPRepPart* t,
                                          size_t* len );

krb5_error_code krb5_decode_EncASRepPart( krb5_context context,
                                          const void* data,
                                          size_t length,
                                          EncASRepPart* t,
                                          size_t* len );

krb5_error_code krb5_decode_EncKrbCredPart( krb5_context context,
                                            const void* data,
                                            size_t length,
                                            EncKrbCredPart* t,
                                            size_t* len );

krb5_error_code krb5_decode_EncTGSRepPart( krb5_context context,
                                           const void* data,
                                           size_t length,
                                           EncTGSRepPart* t,
                                           size_t* len );

krb5_error_code krb5_decode_EncTicketPart( krb5_context context,
                                           const void* data,
                                           size_t length,
                                           EncTicketPart* t,
                                           size_t* len );

krb5_error_code krb5_decode_ap_req( krb5_context context,
                                    const krb5_data* inbuf,
                                    krb5_ap_req* ap_req);

krb5_error_code krb5_decrypt( krb5_context context,
                              krb5_crypto crypto,
                              unsigned usage,
                              void* data,
                              size_t len,
                              krb5_data* result );

krb5_error_code krb5_decrypt_EncryptedData( krb5_context context,
                                            krb5_crypto crypto,
                                            unsigned usage,
                                            const EncryptedData* e,
                                            krb5_data* result );

krb5_error_code krb5_decrypt_ivec( krb5_context context,
                                   krb5_crypto crypto,
                                   unsigned usage,
                                   void* data,
                                   size_t len,
                                   krb5_data* result,
                                   void* ivec );

krb5_error_code krb5_decrypt_ticket( krb5_context context,
                                     Ticket* ticket,
                                     krb5_keyblock* key,
                                     EncTicketPart* out,
                                     krb5_flags flags);

krb5_error_code krb5_derive_key( krb5_context context,
                                 const krb5_keyblock* key,
                                 krb5_enctype etype,
                                 const void* constant,
                                 size_t constant_len,
                                 krb5_keyblock** derived_key );

krb5_error_code krb5_domain_x500_decode( krb5_context context,
                                         krb5_data tr,
                                         char*** realms,
                                         int* num_realms,
                                         const char* client_realm,
                                         const char* server_realm );

krb5_error_code krb5_domain_x500_encode( char** realms,
                                         int num_realms,
                                         krb5_data* encoding );

krb5_error_code krb5_eai_to_heim_errno( int eai_errno, int system_error );

krb5_error_code krb5_encode_Authenticator( krb5_context context,
                                           void* data,
                                           size_t length,
                                           Authenticator* t,
                                           size_t* len );

krb5_error_code krb5_encode_ETYPE_INFO( krb5_context context,
                                        void* data,
                                        size_t length,
                                        ETYPE_INFO* t,
                                        size_t* len );

krb5_error_code krb5_encode_EncAPRepPart( krb5_context context,
                                          void* data,
                                          size_t length,
                                          EncAPRepPart* t,
                                          size_t* len );

krb5_error_code krb5_encode_EncASRepPart( krb5_context context,
                                          void* data,
                                          size_t length,
                                          EncASRepPart* t,
                                          size_t* len );

krb5_error_code krb5_encode_EncKrbCredPart( krb5_context context,
                                            void* data,
                                            size_t length,
                                            EncKrbCredPart* t,
                                            size_t* len );

krb5_error_code krb5_encode_EncTGSRepPart( krb5_context context,
                                           void* data,
                                           size_t length,
                                           EncTGSRepPart* t,
                                           size_t* len );

krb5_error_code krb5_encode_EncTicketPart( krb5_context context,
                                           void* data,
                                           size_t length,
                                           EncTicketPart* t,
                                           size_t* len );

krb5_error_code krb5_encrypt( krb5_context context,
                              krb5_crypto crypto,
                              unsigned usage,
                              void* data,
                              size_t len,
                              krb5_data* result );

krb5_error_code krb5_encrypt_EncryptedData( krb5_context context,
                                            krb5_crypto crypto,
                                            unsigned usage,
                                            void* data,
                                            size_t len,
                                            int kvno,
                                            EncryptedData* result );

krb5_error_code krb5_encrypt_ivec( krb5_context context,
                                   krb5_crypto crypto,
                                   unsigned usage,
                                   void* data,
                                   size_t len,
                                   krb5_data* result,
                                   void* ivec );  

krb5_error_code krb5_enctype_to_keytype( krb5_context context,
                                         krb5_enctype etype,
                                         krb5_keytype* keytype );

krb5_error_code krb5_enctype_to_string( krb5_context context,
                                        krb5_enctype etype,
                                        char** string );

krb5_error_code krb5_enctype_valid( krb5_context context,
                                    krb5_enctype etype );

krb5_boolean krb5_enctypes_compatible_keys( krb5_context context,
                                            krb5_enctype etype1,
                                            krb5_enctype etype2 );

krb5_error_code krb5_err( krb5_context context,
                          int eval,
                          krb5_error_code code,
                          const char *fmt,
                          ... )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 4, 5)));
#else
;
#endif

krb5_error_code krb5_error_from_rd_error( krb5_context context,
                                          const krb5_error* error,
                                          const krb5_creds* creds );

krb5_error_code krb5_errx( krb5_context context,
                           int eval,
                           const char* fmt,
                           ... )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 3, 4)));
#else
;
#endif

krb5_error_code krb5_expand_hostname( krb5_context context,
                                      const char* orig_hostname,
                                      char** new_hostname );

krb5_error_code krb5_expand_hostname_realms( krb5_context context,
                                             const char* orig_hostname,
                                             char** new_hostname,
                                             char*** realms );

PA_DATA* krb5_find_padata( PA_DATA* val,
                           unsigned len,
                           int type,
                           int* index );

krb5_error_code krb5_format_time( krb5_context context,
                                  time_t t,
                                  char* s,
                                  size_t len,
                                  krb5_boolean include_time );

krb5_error_code krb5_free_address( krb5_context context,
                                   krb5_address* address );

krb5_error_code krb5_free_addresses( krb5_context context,
                                     krb5_addresses* addresses );

void krb5_free_ap_rep_enc_part( krb5_context context,
                                krb5_ap_rep_enc_part* val );

void krb5_free_authenticator( krb5_context context,
                              krb5_authenticator* authenticator );

void krb5_free_config_files( char** filenames );

void krb5_free_context( krb5_context context );

krb5_error_code krb5_free_cred_contents( krb5_context context,
                                         krb5_creds* c );

krb5_error_code krb5_free_creds( krb5_context context,
                                 krb5_creds* c );

krb5_error_code krb5_free_creds_contents( krb5_context context,
                                          krb5_creds* c );

void krb5_free_data( krb5_context context, krb5_data* p );

void krb5_free_error( krb5_context context, krb5_error* error );

void krb5_free_error_contents( krb5_context context,
                               krb5_error* error );

void krb5_free_error_string( krb5_context context, char* str );

krb5_error_code krb5_free_host_realm( krb5_context context,
                                      krb5_realm* realmlist );

krb5_error_code krb5_free_kdc_rep( krb5_context context,
                                   krb5_kdc_rep* rep );

void krb5_free_keyblock( krb5_context context, krb5_keyblock* keyblock );

void krb5_free_keyblock_contents( krb5_context context,
                                  krb5_keyblock* keyblock );

krb5_error_code krb5_free_krbhst( krb5_context context, char** hostlist );

void krb5_free_principal( krb5_context context, krb5_principal p );

krb5_error_code krb5_free_salt( krb5_context context, krb5_salt salt );

krb5_error_code krb5_free_ticket( krb5_context context, 
                                  krb5_ticket* ticket );

krb5_error_code krb5_fwd_tgt_creds( krb5_context context,
                                    krb5_auth_context auth_context,
                                    const char* hostname,
                                    krb5_principal client,
                                    krb5_principal server,
                                    krb5_ccache ccache,
                                    int forwardable,
                                    krb5_data* out_data );

void krb5_generate_random_block( void* buf, size_t len);

krb5_error_code krb5_generate_random_keyblock( krb5_context context,
                                               krb5_enctype type,
                                               krb5_keyblock* key );

krb5_error_code krb5_generate_seq_number( krb5_context context,
                                          const krb5_keyblock* key,
                                          u_int32_t* seqno );

krb5_error_code krb5_generate_subkey( krb5_context context,
                                      const krb5_keyblock* key,
                                      krb5_keyblock** subkey );

krb5_error_code krb5_get_all_client_addrs( krb5_context context,
                                           krb5_addresses* res );

krb5_error_code krb5_get_all_server_addrs( krb5_context context,
                                           krb5_addresses* res );

krb5_error_code krb5_get_cred_from_kdc( krb5_context context,
                                        krb5_ccache ccache,
                                        krb5_creds* in_creds,
                                        krb5_creds** out_creds,
                                        krb5_creds*** ret_tgts );

krb5_error_code krb5_get_cred_from_kdc_opt( krb5_context context,
                                            krb5_ccache ccache,
                                            krb5_creds* in_creds,
                                            krb5_creds** out_creds,
                                            krb5_creds*** ret_tgts,
                                            krb5_flags flags);

krb5_error_code krb5_get_credentials( krb5_context context,
                                      krb5_flags options,
                                      krb5_ccache ccache,
                                      krb5_creds* in_creds,
                                      krb5_creds** out_creds);

krb5_error_code krb5_get_credentials_with_flags( krb5_context context,
                                                 krb5_flags options,
                                                 krb5_kdc_flags flags,
                                                 krb5_ccache ccache,
                                                 krb5_creds* in_creds,
                                                 krb5_creds** out_creds );

krb5_error_code krb5_get_default_config_files( char*** pfilenames );

krb5_error_code krb5_get_default_in_tkt_etypes( krb5_context context,
                                                krb5_enctype** etypes );

krb5_error_code krb5_get_default_principal( krb5_context context,
                                            krb5_principal* princ );

krb5_error_code krb5_get_default_realm( krb5_context context,
                                        krb5_realm* realm );

krb5_error_code krb5_get_default_realms( krb5_context context,
                                         krb5_realm** realms );

const char* krb5_get_err_text( krb5_context context,
                               krb5_error_code code );

char* krb5_get_error_string( krb5_context context );

krb5_error_code krb5_get_extra_addresses( krb5_context context,
                                          krb5_addresses* addresses );

krb5_error_code krb5_get_fcache_version( krb5_context context,
                                         int* version );

krb5_error_code krb5_get_forwarded_creds( krb5_context context,
                                          krb5_auth_context auth_context,
                                          krb5_ccache ccache,
                                          krb5_flags flags,
                                          const char* hostname,
                                          krb5_creds* in_creds,
                                          krb5_data* out_data);

krb5_error_code krb5_get_host_realm( krb5_context context,
                                     const char* host,
                                     krb5_realm** realms );

krb5_error_code krb5_get_host_realm_int( krb5_context context,
                                         const char* host,
                                         krb5_boolean use_dns,
                                         krb5_realm** realms );

krb5_error_code krb5_get_ignore_addresses( krb5_context context,
                                           krb5_addresses* addresses);

krb5_error_code krb5_get_in_cred( krb5_context context,
                                  krb5_flags options,
                                  const krb5_addresses* addrs,
                                  const krb5_enctype* etypes,
                                  const krb5_preauthtype* ptypes,
                                  const krb5_preauthdata* preauth,
                                  krb5_key_proc key_proc,
                                  krb5_const_pointer keyseed,
                                  krb5_decrypt_proc decrypt_proc,
                                  krb5_const_pointer decryptarg,
                                  krb5_creds* creds,
                                  krb5_kdc_rep* ret_as_reply);

krb5_error_code krb5_get_in_tkt( krb5_context context,
                                 krb5_flags options,
                                 const krb5_addresses* addrs,
                                 const krb5_enctype* etypes,
                                 const krb5_preauthtype* ptypes,
                                 krb5_key_proc key_proc,
                                 krb5_const_pointer keyseed,
                                 krb5_decrypt_proc decrypt_proc,
                                 krb5_const_pointer decryptarg,
                                 krb5_creds* creds,
                                 krb5_ccache ccache,
                                 krb5_kdc_rep* ret_as_reply);

krb5_error_code krb5_get_in_tkt_with_keytab( krb5_context context,
                                             krb5_flags options,
                                             krb5_addresses* addrs,
                                             const krb5_enctype* etypes,
                                             const krb5_preauthtype* pre_auth_types,
                                             krb5_keytab keytab,
                                             krb5_ccache ccache,
                                             krb5_creds* creds,
                                             krb5_kdc_rep* ret_as_reply );

krb5_error_code krb5_get_in_tkt_with_password( krb5_context context,
                                               krb5_flags options,
                                               krb5_addresses* addrs,
                                               const krb5_enctype* etypes,
                                               const krb5_preauthtype* pre_auth_types,
                                               const char* password,
                                               krb5_ccache ccache,
                                               krb5_creds* creds,
                                               krb5_kdc_rep* ret_as_reply );

krb5_error_code krb5_get_in_tkt_with_skey( krb5_context context,
                                           krb5_flags options,
                                           krb5_addresses* addrs,
                                           const krb5_enctype* etypes,
                                           const krb5_preauthtype* pre_auth_types,
                                           const krb5_keyblock* key,
                                           krb5_ccache ccache,
                                           krb5_creds* creds,
                                           krb5_kdc_rep* ret_as_reply );

krb5_error_code krb5_get_init_creds_keytab( krb5_context context,
                                            krb5_creds* creds,
                                            krb5_principal client,
                                            krb5_keytab keytab,
                                            krb5_deltat start_time,
                                            const char* in_tkt_service,
                                            krb5_get_init_creds_opt* options );

krb5_error_code krb5_get_init_creds_keytab_suggest_pw_salt( krb5_context context,
                                                            krb5_creds* creds,
                                                            krb5_principal client,
                                                            krb5_keytab keytab,
                                                            krb5_deltat start_time,
                                                            const char* in_tkt_service,
                                                            krb5_get_init_creds_opt* options,
                                                            char** pwsalt );

void krb5_get_init_creds_opt_init( krb5_get_init_creds_opt* opt );

void krb5_get_init_creds_opt_set_address_list( krb5_get_init_creds_opt* opt,
                                               krb5_addresses* addresses );

void krb5_get_init_creds_opt_set_anonymous( krb5_get_init_creds_opt* opt,
                                            int anonymous );

void krb5_get_init_creds_opt_set_default_flags( krb5_context context,
                                                const char* appname,
                                                krb5_const_realm realm,
                                                krb5_get_init_creds_opt* opt);

void krb5_get_init_creds_opt_set_etype_list( krb5_get_init_creds_opt* opt,
                                             krb5_enctype* etype_list,
                                             int etype_list_length);

void krb5_get_init_creds_opt_set_forwardable( krb5_get_init_creds_opt* opt,
                                              int forwardable );

void krb5_get_init_creds_opt_set_preauth_list( krb5_get_init_creds_opt* opt,
                                               krb5_preauthtype* preauth_list,
                                               int preauth_list_length );

void krb5_get_init_creds_opt_set_proxiable( krb5_get_init_creds_opt* opt,
                                            int proxiable );

void krb5_get_init_creds_opt_set_renew_life( krb5_get_init_creds_opt* opt,
                                             krb5_deltat renew_life );

void krb5_get_init_creds_opt_set_salt( krb5_get_init_creds_opt* opt,
                                       krb5_data* salt );

void krb5_get_init_creds_opt_set_tkt_life( krb5_get_init_creds_opt* opt,
                                           krb5_deltat tkt_life );

krb5_error_code krb5_get_init_creds_password( krb5_context context,
                                              krb5_creds *creds,
                                              krb5_principal client,
                                              const char *password,
                                              krb5_prompter_fct prompter,
                                              void* data,
                                              krb5_deltat start_time,
                                              const char* in_tkt_service,
                                              krb5_get_init_creds_opt* options );

krb5_error_code krb5_get_kdc_cred( krb5_context context,
                                   krb5_ccache id,
                                   krb5_kdc_flags flags,
                                   krb5_addresses* addresses,
                                   Ticket* second_ticket,
                                   krb5_creds* in_creds,
                                   krb5_creds** out_creds );

krb5_error_code krb5_get_krb524hst( krb5_context context,
                                    const krb5_realm* realm,
                                    char*** hostlist );

krb5_error_code krb5_get_krb_admin_hst( krb5_context context,
                                        const krb5_realm* realm,
                                        char*** hostlist );

krb5_error_code krb5_get_krb_changepw_hst( krb5_context context,
                                           const krb5_realm* realm,
                                           char*** hostlist );

krb5_error_code krb5_get_krbhst( krb5_context context,
                                 const krb5_realm* realm,
                                 char*** hostlist );

krb5_error_code krb5_get_pw_salt( krb5_context context,
                                  krb5_const_principal principal,
                                  krb5_salt* salt );

krb5_error_code krb5_get_server_rcache( krb5_context context,
                                        const krb5_data* piece,
                                        krb5_rcache* id );

krb5_boolean krb5_get_use_admin_kdc( krb5_context context );

size_t krb5_get_wrapped_length( krb5_context context,
                                krb5_crypto crypto,
                                size_t data_len );

int krb5_getportbyname( krb5_context context,
                        const char* service,
                        const char* proto,
                        int default_port );

krb5_error_code krb5_h_addr2addr( krb5_context context,
                                  int af,
                                  const char* haddr,
                                  krb5_address* addr );

krb5_error_code krb5_h_addr2sockaddr( krb5_context context,
                                      int af,
                                      const char* addr,
                                      struct sockaddr* sa,
                                      krb5_socklen_t* sa_size,
                                      int port );

krb5_error_code krb5_h_errno_to_heim_errno( int eai_errno );

krb5_boolean krb5_have_error_string( krb5_context context );

krb5_error_code krb5_init_context( krb5_context* context );

void krb5_init_ets( krb5_context context );

krb5_error_code krb5_init_etype( krb5_context context,
                                 unsigned* len,
                                 krb5_enctype** val,
                                 const krb5_enctype* etypes );

krb5_error_code krb5_initlog( krb5_context context,
                              const char* program,
                              krb5_log_facility** fac );

krb5_error_code krb5_keyblock_key_proc( krb5_context context,
                                        krb5_keytype type,
                                        krb5_data* salt,
                                        krb5_const_pointer keyseed,
                                        krb5_keyblock** key );

krb5_error_code krb5_keytab_key_proc( krb5_context context,
                                      krb5_enctype enctype,
                                      krb5_salt salt,
                                      krb5_const_pointer keyseed,
                                      krb5_keyblock** key );

krb5_error_code krb5_keytype_to_enctypes( krb5_context context,
                                          krb5_keytype keytype,
                                          unsigned* len,
                                          krb5_enctype** val );

krb5_error_code krb5_keytype_to_enctypes_default( krb5_context context,
                                                  krb5_keytype keytype,
                                                  unsigned* len,
                                                  krb5_enctype** val );

krb5_error_code krb5_keytype_to_string( krb5_context context,
                                        krb5_keytype keytype,
                                        char** string );

krb5_error_code krb5_krbhst_add( krb5_context context,
                                 unsigned int type,
                                 const char* realm,
                                 const char* hostname,
                                 const char* proto,
                                 unsigned short port );

krb5_error_code krb5_krbhst_format_string( krb5_context context,
                                           const krb5_krbhst_info* host,
                                           char* hostname,
                                           size_t hostlen );

void krb5_krbhst_free( krb5_context context,
                       krb5_krbhst_handle handle );

void krb5_krbhst_free_list( krb5_context context,
                            krb5_krbhst_handle handle );

krb5_error_code krb5_krbhst_get_addrinfo( krb5_context context,
                                          krb5_krbhst_info* host,
                                          struct addrinfo** ai );

krb5_error_code krb5_krbhst_init( krb5_context context,
                                  const char* realm,
                                  unsigned int type,
                                  krb5_krbhst_handle* handle );

krb5_error_code krb5_krbhst_init_from_context( krb5_context context,
                                               const char* realm,
                                               unsigned int type,
                                               krb5_krbhst_handle* handle );

krb5_error_code krb5_krbhst_next( krb5_context context,
                                  krb5_krbhst_handle handle,
                                  krb5_krbhst_info** host );

krb5_error_code krb5_krbhst_next_as_string( krb5_context context,
                                            krb5_krbhst_handle handle,
                                            char* hostname,
                                            size_t hostlen );

void krb5_krbhst_reset( krb5_context context,
                        krb5_krbhst_handle handle );

krb5_error_code krb5_kt_add_entry( krb5_context context,
                                   krb5_keytab id,
                                   krb5_keytab_entry* entry );

krb5_error_code krb5_kt_close( krb5_context context,
                               krb5_keytab id );

krb5_boolean krb5_kt_compare( krb5_context context,
                              krb5_keytab_entry* entry,
                              krb5_const_principal principal,
                              krb5_kvno vno,
                              krb5_enctype enctype );

krb5_error_code krb5_kt_copy_entry_contents( krb5_context context,
                                             const krb5_keytab_entry* in,
                                             krb5_keytab_entry* out );

krb5_error_code krb5_kt_default( krb5_context context,
                                 krb5_keytab* id );

krb5_error_code krb5_kt_default_modify_name( krb5_context context,
                                             char* name,
                                             size_t namesize );

krb5_error_code krb5_kt_default_name( krb5_context context,
                                      char* name,
                                      size_t namesize );

krb5_error_code krb5_kt_end_seq_get( krb5_context context,
                                     krb5_keytab id,
                                     krb5_kt_cursor* cursor );

krb5_error_code krb5_kt_free_entry( krb5_context context,
                                    krb5_keytab_entry* entry );

krb5_error_code krb5_kt_get_entry( krb5_context context,
                                   krb5_keytab id,
                                   krb5_const_principal principal,
                                   krb5_kvno kvno,
                                   krb5_enctype enctype,
                                   krb5_keytab_entry* entry );

krb5_error_code krb5_kt_get_name( krb5_context context,
                                  krb5_keytab keytab,
                                  char* name,
                                  size_t namesize );

krb5_error_code krb5_kt_get_type( krb5_context context,
                                  krb5_keytab keytab,
                                  char* prefix,
                                  size_t prefixsize );

krb5_error_code krb5_kt_next_entry( krb5_context context,
                                    krb5_keytab id,
                                    krb5_keytab_entry* entry,
                                    krb5_kt_cursor* cursor );

krb5_error_code krb5_kt_read_service_key( krb5_context context,
                                          krb5_pointer keyprocarg,
                                          krb5_principal principal,
                                          krb5_kvno vno,
                                          krb5_enctype enctype,
                                          krb5_keyblock** key );

krb5_error_code krb5_kt_register( krb5_context context,
                                  const krb5_kt_ops* ops );

krb5_error_code krb5_kt_remove_entry( krb5_context context,
                                      krb5_keytab id,
                                      krb5_keytab_entry* entry );

krb5_error_code krb5_kt_resolve( krb5_context context,
                                 const char* name,
                                 krb5_keytab* id );

krb5_error_code krb5_kt_start_seq_get( krb5_context context,
                                       krb5_keytab id,
                                       krb5_kt_cursor* cursor );

krb5_boolean krb5_kuserok( krb5_context context,
                           krb5_principal principal,
                           const char* luser );

krb5_error_code krb5_log( krb5_context context,
                          krb5_log_facility* fac,
                          int level,
                          const char* fmt,
                          ... )
#if defined(__GNUC__)
    __attribute__((format (printf, 4, 5)));
#else
;
#endif

krb5_error_code krb5_log_msg( krb5_context context,
                              krb5_log_facility *fac,
                              int level,
                              char** reply,
                              const char* fmt,
                              ... )
#if defined(__GNUC__)
    __attribute__((format (printf, 5, 6)));
#else
;
#endif

krb5_error_code krb5_make_addrport( krb5_context context,
                                    krb5_address** res,
                                    const krb5_address* addr,
                                    int16_t port );

krb5_error_code krb5_make_principal( krb5_context context,
                                     krb5_principal* principal,
                                     krb5_const_realm realm,
                                     ... );

size_t krb5_max_sockaddr_size( void );

krb5_error_code krb5_mk_error( krb5_context context,
                               krb5_error_code error_code,
                               const char* e_text,
                               const krb5_data* e_data,
                               const krb5_principal client,
                               const krb5_principal server,
                               time_t* client_time,
                               int* client_usec,
                               krb5_data* reply );

krb5_error_code krb5_mk_priv( krb5_context context,
                              krb5_auth_context auth_context,
                              const krb5_data* userdata,
                              krb5_data* outbuf,
                              void* outdata );

krb5_error_code krb5_mk_rep( krb5_context context,
                             krb5_auth_context auth_context,
                             krb5_data* outbuf );

krb5_error_code krb5_mk_req( krb5_context context,
                             krb5_auth_context* auth_context,
                             const krb5_flags ap_req_options,
                             const char* service,
                             const char* hostname,
                             krb5_data* in_data,
                             krb5_ccache ccache,
                             krb5_data* outbuf );

krb5_error_code krb5_mk_req_exact( krb5_context context,
                                   krb5_auth_context* auth_context,
                                   const krb5_flags ap_req_options,
                                   const krb5_principal server,
                                   krb5_data* in_data,
                                   krb5_ccache ccache,
                                   krb5_data* outbuf );

krb5_error_code krb5_mk_req_extended( krb5_context context,
                                      krb5_auth_context* auth_context,
                                      const krb5_flags ap_req_options,
                                      krb5_data* in_data,
                                      krb5_creds* in_creds,
                                      krb5_data* outbuf );

krb5_error_code krb5_mk_req_internal( krb5_context context,
                                      krb5_auth_context* auth_context,
                                      const krb5_flags ap_req_options,
                                      krb5_data* in_data,
                                      krb5_creds* in_creds,
                                      krb5_data* outbuf,
                                      krb5_key_usage checksum_usage,
                                      krb5_key_usage encrypt_usage );

krb5_error_code krb5_mk_safe( krb5_context context,
                              krb5_auth_context auth_context,
                              const krb5_data* userdata,
                              krb5_data* outbuf,
                              void* outdata );

krb5_ssize_t krb5_net_read( krb5_context context,
                            void* p_fd,
                            void* buf,
                            size_t len );

krb5_ssize_t krb5_net_write( krb5_context context,
                             void* p_fd,
                             const void* buf,
                             size_t len );

krb5_error_code krb5_openlog( krb5_context context,
                              const char* program,
                              krb5_log_facility** fac );

krb5_error_code krb5_parse_address( krb5_context context,
                                    const char* string,
                                    krb5_addresses* addresses );

krb5_error_code krb5_parse_name( krb5_context context,
                                 const char* name,
                                 krb5_principal* principal );

const char* krb5_passwd_result_to_string( krb5_context context,
                                          int result );

krb5_error_code krb5_password_key_proc( krb5_context context,
                                        krb5_enctype type,
                                        krb5_salt salt,
                                        krb5_const_pointer keyseed,
                                        krb5_keyblock** key );

krb5_realm* krb5_princ_realm( krb5_context context,
                              krb5_principal principal );

void krb5_princ_set_realm( krb5_context context,
                           krb5_principal principal,
                           krb5_realm* realm );

krb5_error_code krb5_principal2principalname( PrincipalName* p,
                                              const krb5_principal from );

krb5_boolean krb5_principal_compare( krb5_context context,
                                     krb5_const_principal princ1,
                                     krb5_const_principal princ2 );

krb5_boolean krb5_principal_compare_any_realm( krb5_context context,
                                               krb5_const_principal princ1,
                                               krb5_const_principal princ2 );

const char* krb5_principal_get_comp_string( krb5_context context,
                                            krb5_principal principal,
                                            unsigned int component );

const char* krb5_principal_get_realm( krb5_context context,
                                      krb5_principal principal );

int krb5_principal_get_type( krb5_context context,
                             krb5_principal principal );

krb5_boolean krb5_principal_match( krb5_context context,
                                   krb5_const_principal princ,
                                   krb5_const_principal pattern );

krb5_error_code krb5_print_address( const krb5_address* addr,
                                    char* str,
                                    size_t len,
                                    size_t* ret_len );

int krb5_program_setup( krb5_context* context,
                        int argc,
                        char** argv,
                        struct getargs* args,
                        int num_args,
                        void (*usage)( int, struct getargs*, int ) );

int krb5_prompter_posix( krb5_context context,
                         void* data,
                         const char* name,
                         const char* banner,
                         int num_prompts,
                         krb5_prompt prompts[] );

krb5_error_code krb5_rc_close( krb5_context context,
                               krb5_rcache id );

krb5_error_code krb5_rc_default( krb5_context context,
                                 krb5_rcache* id );

const char* krb5_rc_default_name( krb5_context context );

const char* krb5_rc_default_type( krb5_context context );

krb5_error_code krb5_rc_destroy( krb5_context context,
                                 krb5_rcache id );

krb5_error_code krb5_rc_expunge( krb5_context context,
                                 krb5_rcache id );

krb5_error_code krb5_rc_get_lifespan( krb5_context context,
                                      krb5_rcache id,
                                      krb5_deltat* auth_lifespan );

const char* krb5_rc_get_name( krb5_context context,
                              krb5_rcache id );

const char* krb5_rc_get_type( krb5_context context,
                              krb5_rcache id );

krb5_error_code krb5_rc_initialize( krb5_context context,
                                    krb5_rcache id,
                                    krb5_deltat auth_lifespan );

krb5_error_code krb5_rc_recover( krb5_context context,
                                 krb5_rcache id );

krb5_error_code krb5_rc_resolve( krb5_context context,
                                 krb5_rcache id,
                                 const char* name );

krb5_error_code krb5_rc_resolve_full( krb5_context context,
                                      krb5_rcache* id,
                                      const char* string_name );

krb5_error_code krb5_rc_resolve_type( krb5_context context,
                                      krb5_rcache* id,
                                      const char* type );

krb5_error_code krb5_rc_store( krb5_context context,
                               krb5_rcache id,
                               krb5_donot_replay* rep );

krb5_error_code krb5_rd_cred( krb5_context context,
                              krb5_auth_context auth_context,
                              krb5_data* in_data,
                              krb5_creds*** ret_creds,
                              krb5_replay_data* out_data );

krb5_error_code krb5_rd_cred2( krb5_context context,
                               krb5_auth_context auth_context,
                               krb5_ccache ccache,
                               krb5_data* in_data );

krb5_error_code krb5_rd_error( krb5_context context,
                               krb5_data* msg,
                               KRB_ERROR* result );

krb5_error_code krb5_rd_priv( krb5_context context,
                              krb5_auth_context auth_context,
                              const krb5_data* inbuf,
                              krb5_data* outbuf,
                              void* outdata );

krb5_error_code krb5_rd_rep( krb5_context context,
                             krb5_auth_context auth_context,
                             const krb5_data* inbuf,
                             krb5_ap_rep_enc_part** repl );

krb5_error_code krb5_rd_req( krb5_context context,
                             krb5_auth_context* auth_context,
                             const krb5_data* inbuf,
                             krb5_const_principal server,
                             krb5_keytab keytab,
                             krb5_flags* ap_req_options,
                             krb5_ticket** ticket );

krb5_error_code krb5_rd_req_with_keyblock( krb5_context context,
                                           krb5_auth_context* auth_context,
                                           const krb5_data* inbuf,
                                           krb5_const_principal server,
                                           krb5_keyblock* keyblock,
                                           krb5_flags* ap_req_options,
                                           krb5_ticket** ticket );

krb5_error_code krb5_rd_safe( krb5_context context,
                              krb5_auth_context auth_context,
                              const krb5_data* inbuf,
                              krb5_data* outbuf,
                              void* outdata );

krb5_error_code krb5_read_message( krb5_context context,
                                   krb5_pointer p_fd,
                                   krb5_data* data );

krb5_error_code krb5_read_priv_message( krb5_context context,
                                        krb5_auth_context ac,
                                        krb5_pointer p_fd,
                                        krb5_data* data );

krb5_error_code krb5_read_safe_message( krb5_context context,
                                        krb5_auth_context ac,
                                        krb5_pointer p_fd,
                                        krb5_data* data );

krb5_boolean krb5_realm_compare( krb5_context context,
                                 krb5_const_principal princ1,
                                 krb5_const_principal princ2 );

krb5_error_code krb5_recvauth( krb5_context context,
                               krb5_auth_context* auth_context,
                               krb5_pointer p_fd,
                               const char* appl_version,
                               krb5_principal server,
                               int32_t flags,
                               krb5_keytab keytab,
                               krb5_ticket** ticket );

krb5_error_code krb5_recvauth_match_version( krb5_context context,
                                             krb5_auth_context* auth_context,
                                             krb5_pointer p_fd,
                                             krb5_boolean 
                                                (*match_appl_version)( const void*, 
                                                                       const char* ),
                                             const void* match_data,
                                             krb5_principal server,
                                             int32_t flags,
                                             krb5_keytab keytab,
                                             krb5_ticket** ticket );

krb5_error_code krb5_ret_address( krb5_storage* sp,
                                  krb5_address* adr );

krb5_error_code krb5_ret_addrs( krb5_storage* sp,
                                krb5_addresses* adr );

krb5_error_code krb5_ret_authdata( krb5_storage* sp,
                                   krb5_authdata* auth );

krb5_error_code krb5_ret_creds( krb5_storage* sp,
                                krb5_creds* creds );

krb5_error_code krb5_ret_data( krb5_storage* sp,
                               krb5_data* data );

krb5_error_code krb5_ret_int16( krb5_storage* sp,
                                int16_t* value );

krb5_error_code krb5_ret_int32( krb5_storage* sp,
                                int32_t* value );

krb5_error_code krb5_ret_int8( krb5_storage* sp,
                               int8_t* value );

krb5_error_code krb5_ret_keyblock( krb5_storage* sp,
                                   krb5_keyblock* p );

krb5_error_code krb5_ret_principal( krb5_storage* sp,
                                    krb5_principal* princ );

krb5_error_code krb5_ret_string( krb5_storage* sp,
                                 char** string );

krb5_error_code krb5_ret_stringz( krb5_storage* sp,
                                  char** string );

krb5_error_code krb5_ret_times( krb5_storage* sp,
                                krb5_times* times );

krb5_error_code krb5_salttype_to_string( krb5_context context,
                                         krb5_enctype etype,
                                         krb5_salttype stype,
                                         char** string );

krb5_error_code krb5_sendauth( krb5_context context,
                               krb5_auth_context* auth_context,
                               krb5_pointer p_fd,
                               const char* appl_version,
                               krb5_principal client,
                               krb5_principal server,
                               krb5_flags ap_req_options,
                               krb5_data* in_data,
                               krb5_creds* in_creds,
                               krb5_ccache ccache,
                               krb5_error** ret_error,
                               krb5_ap_rep_enc_part** rep_result,
                               krb5_creds** out_creds );


krb5_error_code krb5_sendto( krb5_context context,
                             const krb5_data* send_data,
                             krb5_krbhst_handle handle,
                             krb5_data* receive );

krb5_error_code krb5_sendto_kdc( krb5_context context,
                                 const krb5_data* send_data,
                                 const krb5_realm* realm,
                                 krb5_data* receive );

krb5_error_code krb5_sendto_kdc2( krb5_context context,
                                  const krb5_data* send_data,
                                  const krb5_realm* realm,
                                  krb5_data* receive,
                                  krb5_boolean master );

krb5_error_code krb5_set_config_files( krb5_context context,
                                       char** filenames );

krb5_error_code krb5_set_default_in_tkt_etypes( krb5_context context,
                                                const krb5_enctype* etypes );

krb5_error_code krb5_set_default_realm( krb5_context context,
                                        const char* realm );

krb5_error_code krb5_set_error_string( krb5_context context,
                                       const char* fmt,
                                       ... )
#if defined(__GNUC__)
    __attribute__((format (printf, 2, 3)));
#else
;
#endif

krb5_error_code krb5_set_extra_addresses( krb5_context context,
                                          const krb5_addresses* addresses );

krb5_error_code krb5_set_fcache_version( krb5_context context,
                                         int version );

krb5_error_code krb5_set_ignore_addresses( krb5_context context,
                                           const krb5_addresses* addresses );

/** This implementation has been added by Vintela. */
krb5_error_code krb5_set_password( krb5_context context,
                                   krb5_ccache ccache,
                                   char* newpw,
                                   krb5_principal targprinc,
                                   int* result_code,
                                   krb5_data* result_code_string,
                                   krb5_data* result_string );

void krb5_set_use_admin_kdc( krb5_context context,
                             krb5_boolean flag );

krb5_error_code krb5_set_warn_dest( krb5_context context,
                                    krb5_log_facility* fac );

krb5_error_code krb5_sname_to_principal( krb5_context context,
                                         const char* hostname,
                                         const char* sname,
                                         int32_t type,
                                         krb5_principal* ret_princ );

krb5_error_code krb5_sock_to_principal( krb5_context context,
                                        int sock,
                                        const char* sname,
                                        int32_t type,
                                        krb5_principal* ret_princ );

krb5_error_code krb5_sockaddr2address( krb5_context context,
                                       const struct sockaddr* sa,
                                       krb5_address* addr );

krb5_error_code krb5_sockaddr2port( krb5_context context,
                                    const struct sockaddr* sa,
                                    int16_t* port );

krb5_boolean krb5_sockaddr_uninteresting( const struct sockaddr* sa );

void krb5_std_usage( int code,
                     struct getargs* args,
                     int num_args );

void krb5_storage_clear_flags( krb5_storage* sp,
                               krb5_flags flags );

krb5_storage* krb5_storage_emem( void );

krb5_error_code krb5_storage_free( krb5_storage* sp );

krb5_storage* krb5_storage_from_data( krb5_data* data );

krb5_storage* krb5_storage_from_fd( int fd );

krb5_storage* krb5_storage_from_mem( void* buf, size_t len );

krb5_flags krb5_storage_get_byteorder( krb5_storage* sp,
                                       krb5_flags byteorder );

krb5_boolean krb5_storage_is_flags( krb5_storage* sp,
                                    krb5_flags flags );

krb5_ssize_t krb5_storage_read( krb5_storage* sp,
                                void *buf,
                                size_t len );

off_t krb5_storage_seek( krb5_storage* sp, off_t offset, int whence );

void krb5_storage_set_byteorder( krb5_storage* sp, krb5_flags byteorder );

void krb5_storage_set_eof_code( krb5_storage* sp, int code );

void krb5_storage_set_flags( krb5_storage* sp, krb5_flags flags );

krb5_error_code krb5_storage_to_data( krb5_storage* sp, krb5_data* data );

krb5_ssize_t krb5_storage_write( krb5_storage* sp,
                                 const void* buf,
                                 size_t len );

krb5_error_code krb5_store_address( krb5_storage* sp,
                                    krb5_address p );

krb5_error_code krb5_store_addrs( krb5_storage* sp,
                                  krb5_addresses p );

krb5_error_code krb5_store_authdata( krb5_storage* sp,
                                     krb5_authdata auth );

krb5_error_code krb5_store_creds( krb5_storage* sp,
                                  krb5_creds* creds );

krb5_error_code krb5_store_data( krb5_storage* sp,
                                 krb5_data data );

krb5_error_code krb5_store_int16( krb5_storage* sp,
                                  int16_t value );

krb5_error_code krb5_store_int32( krb5_storage* sp,
                                  int32_t value );

krb5_error_code krb5_store_int8( krb5_storage* sp,
                                 int8_t value );

krb5_error_code krb5_store_keyblock( krb5_storage* sp,
                                     krb5_keyblock p );

krb5_error_code krb5_store_principal( krb5_storage* sp,
                                      krb5_principal p );

krb5_error_code krb5_store_string( krb5_storage* sp,
                                   const char* s );

krb5_error_code krb5_store_stringz( krb5_storage* sp,
                                    const char* s );

krb5_error_code krb5_store_times( krb5_storage* sp,
                                  krb5_times times );

krb5_error_code krb5_string_to_deltat( const char* string,
                                       krb5_deltat* deltat );

krb5_error_code krb5_string_to_enctype( krb5_context context,
                                        const char* string,
                                        krb5_enctype* etype );

krb5_error_code krb5_string_to_key( krb5_context context,
                                    krb5_enctype enctype,
                                    const char* password,
                                    krb5_principal principal,
                                    krb5_keyblock* key );

krb5_error_code krb5_string_to_key_data( krb5_context context,
                                         krb5_enctype enctype,
                                         krb5_data password,
                                         krb5_principal principal,
                                         krb5_keyblock* key );

krb5_error_code krb5_string_to_key_data_salt( krb5_context context,
                                              krb5_enctype enctype,
                                              krb5_data password,
                                              krb5_salt salt,
                                              krb5_keyblock* key );

krb5_error_code krb5_string_to_key_data_use_pwsalt( krb5_context context,
                                                    krb5_enctype enctype,
                                                    krb5_data pw,
                                                    const char* pwsalt,
                                                    krb5_keyblock* key );

krb5_error_code krb5_string_to_key_derived( krb5_context context,
                                            const void* str,
                                            size_t len,
                                            krb5_enctype etype,
                                            krb5_keyblock* key );

krb5_error_code krb5_string_to_key_salt( krb5_context context,
                                         krb5_enctype enctype,
                                         const char* password,
                                         krb5_salt salt,
                                         krb5_keyblock* key );

krb5_error_code krb5_string_to_key_use_pwsalt( krb5_context context,
                                               krb5_enctype enctype,
                                               const char* password,
                                               const char* pwsalt,
                                               krb5_keyblock* key );

krb5_error_code krb5_string_to_keytype( krb5_context context,
                                        const char* string,
                                        krb5_keytype* keytype );

krb5_error_code krb5_string_to_salttype( krb5_context context,
                                         krb5_enctype etype,
                                         const char* string,
                                         krb5_salttype* salttype );

krb5_error_code krb5_timeofday( krb5_context context,
                                krb5_timestamp* timeret );

krb5_error_code krb5_unparse_name( krb5_context context,
                                   krb5_const_principal principal,
                                   char** name );

krb5_error_code krb5_unparse_name_fixed( krb5_context context,
                                         krb5_const_principal principal,
                                         char* name,
                                         size_t len );

krb5_error_code krb5_unparse_name_fixed_short( krb5_context context,
                                               krb5_const_principal principal,
                                               char* name,
                                               size_t len );

krb5_error_code krb5_unparse_name_short( krb5_context context,
                                         krb5_const_principal principal,
                                         char** name );

krb5_error_code krb5_us_timeofday( krb5_context context,
                                   int32_t* sec,
                                   int32_t* usec );

krb5_error_code krb5_vabort( krb5_context context,
                             krb5_error_code code,
                             const char *fmt,
                             va_list ap )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 3, 0)));
#else
;
#endif

krb5_error_code krb5_vabortx( krb5_context context,
                              const char *fmt,
                              va_list ap )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 2, 0)));
#else
;
#endif

krb5_error_code krb5_verify_ap_req( krb5_context context,
                                    krb5_auth_context* auth_context,
                                    krb5_ap_req* ap_req,
                                    krb5_const_principal server,
                                    krb5_keyblock* keyblock,
                                    krb5_flags flags,
                                    krb5_flags* ap_req_options,
                                    krb5_ticket** ticket );

krb5_error_code krb5_verify_ap_req2( krb5_context context,
                                     krb5_auth_context* auth_context,
                                     krb5_ap_req* ap_req,
                                     krb5_const_principal server,
                                     krb5_keyblock* keyblock,
                                     krb5_flags flags,
                                     krb5_flags* ap_req_options,
                                     krb5_ticket** ticket,
                                     krb5_key_usage usage);

krb5_error_code krb5_verify_authenticator_checksum( krb5_context context,
                                                    krb5_auth_context ac,
                                                    void* data,
                                                    size_t len );

krb5_error_code krb5_verify_checksum( krb5_context context,
                                      krb5_crypto crypto,
                                      krb5_key_usage usage,
                                      void* data,
                                      size_t len,
                                      Checksum* cksum );

krb5_error_code krb5_verify_init_creds( krb5_context context,
                                        krb5_creds* creds,
                                        krb5_principal ap_req_server,
                                        krb5_keytab ap_req_keytab,
                                        krb5_ccache* ccache,
                                        krb5_verify_init_creds_opt* options );

void krb5_verify_init_creds_opt_init( krb5_verify_init_creds_opt* options );

void krb5_verify_init_creds_opt_set_ap_req_nofail( krb5_verify_init_creds_opt* options,
                                                   int ap_req_nofail );

void krb5_verify_opt_init( krb5_verify_opt* opt );

void krb5_verify_opt_set_ccache( krb5_verify_opt* opt, krb5_ccache ccache );

void krb5_verify_opt_set_flags( krb5_verify_opt* opt,
                                unsigned int flags );

void krb5_verify_opt_set_keytab( krb5_verify_opt* opt, krb5_keytab keytab );

void krb5_verify_opt_set_secure( krb5_verify_opt* opt, krb5_boolean secure );

void krb5_verify_opt_set_service( krb5_verify_opt* opt, 
                                  const char* service );

krb5_error_code krb5_verify_user( krb5_context context,
                                  krb5_principal principal,
                                  krb5_ccache ccache,
                                  const char* password,
                                  krb5_boolean secure,
                                  const char* service );

krb5_error_code krb5_verify_user_lrealm( krb5_context context,
                                         krb5_principal principal,
                                         krb5_ccache ccache,
                                         const char* password,
                                         krb5_boolean secure,
                                         const char* service );

krb5_error_code krb5_verify_user_opt( krb5_context context,
                                      krb5_principal principal,
                                      const char* password,
                                      krb5_verify_opt* opt );

krb5_error_code krb5_verr( krb5_context context,
                           int eval,
                           krb5_error_code code,
                           const char* fmt,
                           va_list ap )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 4, 0)));
#else
;
#endif

krb5_error_code krb5_verrx( krb5_context context,
                            int eval,
                            const char* fmt,
                            va_list ap )
#if defined(__GNUC__)
    __attribute__ ((noreturn, format (printf, 3, 0)));
#else
;
#endif

krb5_error_code krb5_vlog( krb5_context context,
                           krb5_log_facility* fac,
                           int level,
                           const char* fmt,
                           va_list ap )
#if defined(__GNUC__)
    __attribute__((format (printf, 4, 0)));
#else
;
#endif

krb5_error_code krb5_vlog_msg( krb5_context context,
                               krb5_log_facility* fac,
                               char** reply,
                               int level,
                               const char* fmt,
                               va_list ap )
#if defined(__GNUC__)
    __attribute__((format (printf, 5, 0)));
#else
;
#endif

krb5_error_code krb5_vset_error_string( krb5_context context,
                                        const char* fmt,
                                        va_list args )
#if defined(__GNUC__)
    __attribute__ ((format (printf, 2, 0)));
#else
;
#endif

krb5_error_code krb5_vwarn( krb5_context context,
                            krb5_error_code code,
                            const char* fmt,
                            va_list ap )
#if defined(__GNUC__)
    __attribute__ ((format (printf, 3, 0)));
#else
;
#endif

krb5_error_code krb5_vwarnx( krb5_context context,
                             const char* fmt,
                             va_list ap )
#if defined(__GNUC__)
    __attribute__ ((format (printf, 2, 0)));
#else
;
#endif

krb5_error_code krb5_warn( krb5_context context,
                           krb5_error_code code,
                           const char* fmt,
                           ... )
#if defined(__GNUC__)
    __attribute__ ((format (printf, 3, 4)));
#else
;
#endif

krb5_error_code krb5_warnx( krb5_context context,
                            const char* fmt,
                            ... )
#if defined(__GNUC__)
    __attribute__ ((format (printf, 2, 3)));
#else
;
#endif

krb5_error_code krb5_write_message( krb5_context context,
                                    krb5_pointer p_fd,
                                    krb5_data* data );

krb5_error_code krb5_write_priv_message( krb5_context context,
                                         krb5_auth_context ac,
                                         krb5_pointer p_fd,
                                         krb5_data* data );

krb5_error_code krb5_write_safe_message( krb5_context context,
                                         krb5_auth_context ac,
                                         krb5_pointer p_fd,
                                         krb5_data* data );

krb5_error_code krb5_xfree( void* ptr );


krb5_error_code principalname2krb5_principal( krb5_principal* principal,
                                              const PrincipalName from,
                                              const Realm realm );

krb5_error_code krb5_hmac( krb5_context context,
                           krb5_cksumtype cktype,
                           const void *data,
                           size_t len,
                           unsigned usage,
                           krb5_keyblock *key,
                           Checksum *result );



#ifdef __cplusplus
}
#endif

#endif /* KRB5_H_INCLUDED */

