#include <stdio.h>

#define DESKEYLEN 64

#ifdef TESTCODE

unsigned char pbkey[95] = {
0x30, 0x5c, 0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d,
0x01, 0x01, 0x01, 0x05, 0x00, 0x03, 0x4b, 0x00, 0x30, 0x48, 0x02, 0x41,
0x00, 0xc0, 0x76, 0x47, 0x97, 0xb8, 0xbe, 0xc8, 0x97, 0x2a, 0x0e, 0xd8,
0xc9, 0x0a, 0x8c, 0x33, 0x4d, 0xd0, 0x49, 0xad, 0xd0, 0x22, 0x2c, 0x09,
0xd2, 0x0b, 0xe0, 0xa7, 0x9e, 0x33, 0x89, 0x10, 0xbc, 0xae, 0x42, 0x20,
0x60, 0x90, 0x6a, 0xe0, 0x22, 0x1d, 0xe3, 0xf3, 0xfc, 0x74, 0x7c, 0xcf,
0x98, 0xae, 0xcc, 0x85, 0xd6, 0xed, 0xc5, 0x2d, 0x93, 0xd5, 0xb7, 0x39,
0x67, 0x76, 0x16, 0x05, 0x25, 0x02, 0x03, 0x01, 0x00, 0x01
};

unsigned char pvkey[350] = {
0x30, 0x82, 0x01, 0x53, 0x02, 0x01, 0x00, 0x30, 0x0d, 0x06, 0x09, 0x2a,
0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00, 0x04, 0x82,
0x01, 0x3d, 0x30, 0x82, 0x01, 0x39, 0x02, 0x01, 0x00, 0x02, 0x41, 0x00,
0xc0, 0x76, 0x47, 0x97, 0xb8, 0xbe, 0xc8, 0x97, 0x2a, 0x0e, 0xd8, 0xc9,
0x0a, 0x8c, 0x33, 0x4d, 0xd0, 0x49, 0xad, 0xd0, 0x22, 0x2c, 0x09, 0xd2,
0x0b, 0xe0, 0xa7, 0x9e, 0x33, 0x89, 0x10, 0xbc, 0xae, 0x42, 0x20, 0x60,
0x90, 0x6a, 0xe0, 0x22, 0x1d, 0xe3, 0xf3, 0xfc, 0x74, 0x7c, 0xcf, 0x98,
0xae, 0xcc, 0x85, 0xd6, 0xed, 0xc5, 0x2d, 0x93, 0xd5, 0xb7, 0x39, 0x67,
0x76, 0x16, 0x05, 0x25, 0x02, 0x03, 0x01, 0x00, 0x01, 0x02, 0x40, 0x1a,
0xe3, 0x6b, 0x75, 0x22, 0xf6, 0x64, 0x87, 0xd9, 0xf4, 0x61, 0x0d, 0x15,
0x50, 0x29, 0x0a, 0xc2, 0x02, 0xc9, 0x29, 0xbe, 0xdc, 0x70, 0x32, 0xcc,
0x3e, 0x02, 0xac, 0xf3, 0x7e, 0x3e, 0xbc, 0x1f, 0x86, 0x6e, 0xe7, 0xef,
0x7a, 0x08, 0x68, 0xd2, 0x3a, 0xe2, 0xb1, 0x84, 0xc1, 0xab, 0xd6, 0xd4,
0xdb, 0x8e, 0xa9, 0xbe, 0xc0, 0x46, 0xbd, 0x82, 0x80, 0x37, 0x27, 0xf2,
0x88, 0x87, 0x01, 0x02, 0x21, 0x00, 0xdf, 0x02, 0xb6, 0x15, 0xfe, 0x15,
0x92, 0x8f, 0x41, 0xb0, 0x2b, 0x58, 0x6b, 0x51, 0xc2, 0xc0, 0x22, 0x60,
0xca, 0x39, 0x68, 0x18, 0xca, 0x4c, 0xba, 0x60, 0xbb, 0x89, 0x24, 0x65,
0xbe, 0x35, 0x02, 0x21, 0x00, 0xdc, 0xee, 0xb6, 0x0d, 0x54, 0x35, 0x18,
0xb4, 0xac, 0x74, 0x83, 0x4a, 0x05, 0x46, 0xc5, 0x07, 0xf2, 0xe9, 0x1e,
0x38, 0x9a, 0x87, 0xe2, 0xf2, 0xbe, 0xcc, 0x6f, 0x8c, 0x67, 0xd1, 0xc9,
0x31, 0x02, 0x20, 0x59, 0x48, 0x7e, 0x99, 0xe3, 0x75, 0xc3, 0x8d, 0x73,
0x21, 0x12, 0xd9, 0x7d, 0x6d, 0xe8, 0x68, 0x7f, 0xda, 0xfc, 0x5b, 0x6b,
0x5f, 0xb1, 0x6e, 0x72, 0x97, 0xd3, 0xbd, 0x1e, 0x43, 0x55, 0x99, 0x02,
0x20, 0x61, 0xb5, 0x50, 0xde, 0x64, 0x37, 0x77, 0x4d, 0xb0, 0x57, 0x77,
0x18, 0xed, 0x6c, 0x77, 0x07, 0x24, 0xee, 0xe4, 0x66, 0xb4, 0x31, 0x14,
0xb5, 0xb6, 0x9c, 0x43, 0x59, 0x1d, 0x31, 0x32, 0x81, 0x02, 0x20, 0x74,
0x4c, 0x79, 0xc4, 0xb9, 0xbe, 0xa9, 0x7c, 0x25, 0xe5, 0x63, 0xc9, 0x40,
0x7a, 0x2d, 0x09, 0xb5, 0x73, 0x58, 0xaf, 0xe0, 0x9a, 0xf6, 0x7d, 0x71,
0xf8, 0x19, 0x8c, 0xb7, 0xc9, 0x56, 0xb8
};

int pbkey_len=sizeof(pbkey);
int pvkey_len=sizeof(pvkey);

#endif 

#define  BREAK(x) {printf(x);break;}

#ifndef TESTCODE
extern FILE * logfile;
#endif

/* the following part defines the main() for testing this program */

#ifdef TESTCODE

FILE * logfile = stdout;

main( ) {
int status;

unsigned char inbuf[900], encbuf[2000], outbuf[900]; 
int encbuf_len, outbuf_len,offset,xx,total_enc_len;
unsigned char DESKey[100];

/* ReadFile("PublicKey",pbkey,pbkey_len);
 *
 *   ReadFile("PrivateKey",pvkey,pvkey_len);
 */

WriteFile("PublicKey",pbkey,sizeof(pbkey));
WriteFile("PrivateKey",pvkey,sizeof(pvkey));
ReadFile("../bsafe30/test/PublicKey",pbkey,&pbkey_len, 350);
ReadFile("../bsafe30/test/PrivateKey",pvkey,&pvkey_len, 350);

printf("public key length=%d, private key length=%d\n",pbkey_len, pvkey_len);

strcpy(inbuf,"1111111111222222222233333333334444444444555555555566666666667777777777888888888899999999990000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" );

printf("%s\n",inbuf);
encbuf_len=900;
PublicKeyEncrypt(inbuf,strlen(inbuf), encbuf,&encbuf_len,pbkey,sizeof(pbkey));
outbuf_len = 800;
PrivateKeyDecrypt(encbuf,encbuf_len,outbuf, &outbuf_len, pvkey, sizeof(pvkey));
outbuf[outbuf_len]='\0';
printf("%s\n",outbuf);

gen_new_DES_key ( DESKey );

encbuf_len=sizeof(encbuf_len);
B_DESEncrypt(inbuf, 100, encbuf,&encbuf_len, DESKey);
outbuf_len=700;
B_DESDecrypt(encbuf, encbuf_len, outbuf,&outbuf_len, DESKey);
printf("%s\n",outbuf);

}

#endif


int ReadFile (filename, output, outputLen, maxOutputLen)
char *filename;
unsigned char *output;
unsigned int *outputLen;
unsigned int maxOutputLen;
{
  FILE *file = (FILE *) NULL;
  unsigned char dummy;

  if ((file = fopen (filename, "rb")) == NULL)
      /* could not open file */
    return (1);

  /* fread () returns the number of items read in.  Expect an end of file
       after the read.
   */
  *outputLen = fread (output, 1, maxOutputLen, file);
  if (*outputLen == maxOutputLen)
    /* Read exactly maxOutputLen bytes, so reading one more will set
         end of file if there were exactly maxOutputLen bytes in the file.
     */
    fread (&dummy, 1, 1, file);

  if (!feof (file)) {
    fclose (file);
    return (1);
  }

  fclose (file);
  return (0);
}

int WriteFile (filename, input, inputLen)
char *filename;
char *input;
int inputLen;
{
  FILE *file = (FILE *) NULL;

  if (filename[0] == '-' && filename[1] == '\0')
    return(1);
  else {
    if ((file = fopen (filename, "wb")) == NULL)
 			return (1);
  }

  if (fwrite (input, 1, inputLen, file) < inputLen) {
    fclose (file);
    return (1);
  }

  fclose (file);

  return (0);
}

int PublicKeyEncrypt(unsigned char * inbuf,int inlen,
                     unsigned char * outbuf,int * out_len,
                     unsigned char * pbkey,int pbkeylen) {
  unsigned char * clbuf, * encbuf;
  int encbuf_len,chunk,leftover,Max_out;
  
  Max_out = * out_len;
  encbuf_len = Max_out;  
  
  leftover=inlen;
  
  clbuf = inbuf;
  encbuf = outbuf;
  fprintf(logfile, "Maxout = %d %d\n",Max_out,*out_len);
  * out_len = 0;
  
  while ( leftover > 0 ) {
    chunk = (leftover > 50 ? 50 : leftover );
    fprintf(logfile,"encrypt chunk = %d,encbuf_len=%d,leftover=%d\n",chunk,encbuf_len,leftover);
    if ( B_RSAEncrypt( clbuf,chunk,encbuf,&encbuf_len,pbkey,pbkeylen) ){
       printf( "Error encrypt\n");
       fflush(stdout);
       return( 1 ); 
    }
    leftover -= chunk;
    clbuf += chunk;
    encbuf += encbuf_len;
    * out_len += encbuf_len;
    printf("after encryption chunk=%d,enclen=%d leftover=%d\n",chunk,encbuf_len,leftover);
    encbuf_len = Max_out - encbuf_len;  
    fprintf(logfile,"after encryption chunk=%d,out_len=%d leftover=%d\n",chunk,encbuf_len,leftover);
    if ( encbuf_len < 0 ) break;
  }
  return (0);
}

int PrivateKeyDecrypt(unsigned char * inbuf, int inbuf_len,
											unsigned char * outbuf,int * out_len, 
											unsigned char * pvkey, int pvkey_len) {
  unsigned char * clbuf, * encbuf;
  int clbuf_len,chunk,leftover,Max_out;

  Max_out = * out_len;
  clbuf_len = Max_out;
  printf( "Maxout = %d %d\n",Max_out,*out_len); 
  
  leftover=inbuf_len;
  
  clbuf = outbuf;
  encbuf =inbuf;
  * out_len = 0;
  while ( leftover > 0 ) {
    chunk = (leftover > 64 ? 64 : leftover );
    clbuf_len = 800;
    if (B_RSADecrypt( encbuf,64, clbuf, &clbuf_len, pvkey, pvkey_len)){
       return( 1 ); 
    }
    leftover -= chunk;
    encbuf += chunk;
    clbuf += clbuf_len;
    * out_len += clbuf_len;
    clbuf_len = Max_out - clbuf_len;  
    if ( clbuf_len < 0 ) break;
  }
  return(0);
}
/* generates a new DES key using RSA's BSafe toolkit */
int gen_new_DES_key(unsigned char *key_info)
{
  unsigned char a_key[DESKEYLEN], des_key[DESKEYLEN];

  if (gen_random_num(a_key, DESKEYLEN) != 0) /* should use SPYRUS -- TBD */
  {
    fprintf(logfile, "ERROR: error generating random number\n");
    return 1;
  }
  printf("a_key=%x%x%x\n",a_key[0],a_key[1],a_key[2]);
  /* Generate a DES key from random number */
  if (B_GenerateDESKey(a_key, des_key) != 0)
  {
    fprintf(logfile, "ERROR: could not generate a parity-adjusted DES key");
    return 2;
  }
  printf("key info =%x%x%x\n",key_info[0],key_info[1],key_info[2]);
  memcpy(key_info, des_key, DESKEYLEN/8 );
  return 0;
}


int gen_new_DES3_key( unsigned char * key_info ) {
	int i;
  unsigned char a_key[DESKEYLEN*3], des3_key[DESKEYLEN*3];

	if (gen_random_num(a_key, DESKEYLEN*3) != 0) /* should use SPYRUS -- TBD */ 
	{
		fprintf(logfile, "ERROR: error generating random number\n");
		return 1;
	}
  /* for(i=0;i<DESKEYLEN*3;i++) printf("[%2.2x]",a_key[i]);printf("\n"); */
  /* Generate a DES key from random number */
	if (B_GenerateDES3Key(a_key, des3_key) != 0)
	{
			fprintf(logfile, "ERROR: could not generate a parity-adjusted DES3 key");
			return 2;
	}
	memcpy(key_info, des3_key, 24); 
  /* for(i=0;i<DESKEYLEN*3;i++) printf("[%2.2x]",key_info[i]);printf("\n"); */
	return 0;

}

/* generates random number using RSA's BSafe toolkit */
int gen_random_num(unsigned char *buf, unsigned int buf_len)
{
  if (B_GenerateRandomNum(buf, buf_len) != 0)
  {
    fprintf(logfile, "ERROR: error generating random number\n");
    return 1;
  }
  return 0;
}



