/**************************************************************
 *
 *  MODULE NAME:
 *
 *      inc/wfb_err.h, common, common_1.0, D960209 1.3 11/22/95
 *  MODULE REVISION:
 *
 *      Version: 1.5
 *      Date: 06/14/95
 *
 *  FACILITY:
 *
 *      Wells Fargo Bank
 *
 *
 *  ABSTRACT:
 *
 *  Wells Fargo application error code bases.
 *
 *  Every application should register an error base here.   All  application
 *  error codes should then be enumerated beginning with  the  application's
 *  base.
 *
 *  16-Nov-95   adf     Add Method Event error range.
 *  24-Jul-95   kmk     Add WAPI error range.
 *  05-Jul-95   adf     Move file to 'common' CMVC component.
 *  14-Jun-95   adf     Add some generic exception codes common
 *                      to all interfaces.
 *  03-May-95   nlh     Updated ranges to match middle tier
 *                      status/error code spec published by
 *                      Gideon Mann on 4/28.
*
 *************************************************************/

#ifndef _WFB_err_h
#define _WFB_err_h

/* Interface Code for an Implementation Exception.
 */
#define WFB_INTF_EXC_IMPL                     1

/* Generic Interface Codes.
 */
#define WFB_INTF_EXC_NOT_IMPLEMENTED          100
#define WFB_INTF_EXC_METHOD_UNSUPPORTED               101
#define WFB_INTF_EXC_TYPE_UNSUPPORTED         102

#define EB_Cust            1000            /* Cust error-code base */
#define EB_Acct               20000           /* Acct error-code base */
#define EB_Rel                60000           /* Rel error-code base */
#define EB_OSM_mev    68000           /* OSM "Method Event" interface */
#define EB_WAPI               310000          /* "WAPI" interface */

#endif


