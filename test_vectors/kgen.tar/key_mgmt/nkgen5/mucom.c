/*

    Copyright (c) 1994, 1995 by
    Wells Fargo Bank, San Francisco, California.
    All rights reserved.

    This software or any  other  copies  thereof  may  not  be  provided  or
    otherwise made available to any other person.  No title to and ownership
    of the software is hereby transferred.

    The information in this software is subject to change without notice and
    should not be construed as a commitment by Wells Fargo Bank.

    Wells assumes no responsibility  for  the  use  or  reliability  of  its
    software.


    Program:		MU communications.
    Module:		mucom.c -- implementation.
    Version:		mucom/mucom.c, mucom, mucom_2.0 1.1 12/12/95
    Author:		Jim Esparza, Hewlett-Packard.
    Date:


    Changes:

    97/05/12 adf	Add kerberos support.
    97/03/25 adf	New version mucom_audit_info_v2().
    97/02/05 adf	Support multiple connections.
    97/02/02 adf        Fake errors in reply buffer.
                        Fix bug where timeouts were returned as success.
    97/01/06 adf	Retry send() for streaming socket.
    96/12/16 adf	Support streaming MUs.
    96/03/08 jvg	Printing the MU reply buffer could show extraneous data
			from previous requests.  Append null character.
			Also changed IDENT string for CMVC.
    95/12/11 adf	CREATE MUCOM_2.0 RELEASE.
			Use select() to detect completion of connect().
    95/11/21 adf	Copy hostent and servent into malloc'd memory.
    95/11/06 kmk	In some error cases, audit_info reports the request-
			ing host rather than the target host.  Fix.
    95/09/15 kmk	Mucom_setup should record errors in the  context  so
			that a subsequent audit_info can  correctly  provide
			the error text.
    95/09/06 kmk	Audit_info would  not  return  text  for  the  error
			E_mucom_no_host.
    95/08/18 kmk	Prefixed error msg text with "MUCOM: ".
    95/08/16 kmk	Change audit_info to return error text.
    95/08/07 kmk	Prevent sign-extension of IP address components.
    95/08/03 kmk	Implement the mucom_xmit jacket.
    95/08/03 kmk	IP address is unsigned.
    95/08/02 kmk	Audit_info should return the IP address formatted.
    95/07/26 kmk	WAPI V2: now called mucom.  Started a rewrite.
    95/07/25 kmk	Add TV_audit_info to support auditing.
    95/03/01 laraj	Sockets are left open.
    95/01/19 jkl	Fix IDENT.  It should not be a ptr.
    95/01/01 jkl	Fix receive timeout value.
    94/12/28 jkl	Remove select() logic and add connect() retry logic.
    94/12/19 jkl	Add fixes from TV.


    Notes:



    Description:

    Mucom takes a request message, makes a TCP connection to a remote  port,
    sends the request and receives a reply.

*/
/****************************************************************************
			 S Y S T E M  I N C L U D E   F I L E S
****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <time.h>
#include <sys/time.h>
#include <sys/file.h>
#include <errno.h>
#include <assert.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/signal.h>

/****************************************************************************
			 M U S S  I N C L U D E   F I L E S
****************************************************************************/
#include "wfb_muss.h"

/****************************************************************************
			 U S E R  D E F I N E D  I N C L U D E   F I L E S
****************************************************************************/

#include "mucom.h"

extern FILE * logfile;
extern int PKIFlag;
extern int DESFlag;
extern unsigned char pbkey[];
extern unsigned char pvkey[];
extern int pbkey_len;
extern int pvkey_len;

static unsigned char DESKey[100];
static char IDENT[] = "@(#)mucom/mucom.c, mucom, mucom_2.0, D970512a V1.9 05/12/97";

/*  Define the structure for data which is common to all connections.
*/
typedef struct _GlobalCtx {
  int			timer;	/* timeout for reply message */
} GlobalCtx;

/*  Define the structure for a context/connection.
*/
typedef struct _Context {
  char			name[32];	/* connection name */

  /* fully qualified domain name for MU host (CICS region) principal */
  char                  mu_host_fqdn[MUCOM_MAX_FQDN];

  Boolean		used;		/* context used */
  Boolean		ready;		/* => setup complete */
  Boolean		streaming;	/* => use streaming MUs */
  Boolean       kerberized;     /* => supports kerberos security */

  char *		host_name;
  char *		service_name;
  int			sock;
  int			port;
  struct hostent  	host;
  struct servent  	service;
  struct sockaddr_in	server_addr;

  int			status;		      /* last MUCOM error */
  //int			errno;		      /* last Unix error */
  int			context_errno;	      /* last Unix error */
  char			errortext[MU_ERRLEN]; /* text of last error */
} Context;

int MucomDebug = 0;

#define Max_contexts		4

#define MUCOM_FREE(a)	if (a != NULL) { free(a); a=NULL; }
#define DPRINTF(a)      if (MucomDebug) { printf(a); fflush(stdout); }

/****************************************************************************
     S T A T I C  V A R I A B L E  D E F I N I T I O N S
****************************************************************************/
/* Global context (connection independent data)
 */
static GlobalCtx	global = { 0 };
/* kerberos info */
static KerbInfo	kerb_info = { 0 };

/*  Maximum number of configured contexts/connections.
*/
static Context		contexts[Max_contexts] = { 0 };

/* Context that is never used - but can be set to be the current context.
*/
static Context		null_context = { 0 };

/* The current context. 
*/
static Context *	context = &null_context;

/* A 'transaction tag' for every message sent.
*/
static unsigned long	tran_tag_id = 0;

static char *		err_msg[] = {
  "MUCOM: Host not found",
  "MUCOM: Service not found",
  "MUCOM: Mucom setup not called",
  "MUCOM: Socket error",
  "MUCOM: Connection timeout",
  "MUCOM: Send error",
  "MUCOM: Send timeout",
  "MUCOM: Receive error",
  "MUCOM: Receive timeout",
  "MUCOM: Reply larger than expected",
  "MUCOM: Connection not found",
  "MUCOM: Invalid message type",
  "MUCOM: Generic failure ",
  "MUCOM: Reply does not match request",
  "MUCOM: GSS Invalid principal name",
  "MUCOM: Kerberos Failure",
  "MUCOM: Server side Failure",
};

/****************************************************************************
    S T A T I C   F U N C T I O N   D E C L A R A T I O N S
****************************************************************************/
static int
mucom_req (
  int           sock,
  char *        request,
  int           reqlen,
  int *         tries
);

static int
mucom_rep (
  int           sock,
  char *        reply,
  int *         replen,
  int *         tries
);

static char *
strcap (
  char *	source
);

static int
xmit(
  char *	request,
  int		reqlen,
  char *	reply,
  int *		replen
);

static int
context_setup(
  Context *	ctx,
  char *	host,
  char *	service,
  KerbInfo *kerberos_info,
  char *        streaming
);

static void
context_shutdown(
  Context *	ctx
);

static int 
mucom_marshall_req(int msg_type, char *seal_msg, int seal_len, 
				 char *sec_tok, int sec_tok_len, char *bundled_msg,
				 int *bundled_msg_len);

static int 
mucom_unmarshall_rep(char *reply, int replen, int *msg_type, 
				   	 char *out_msg, int *out_len);

static int 
mucom_convertval2str(int val, char *str, int size);

static void
context_host_free (Context *ctx);

/****************************************************************************
     F U N C T I O N   D E F I N I T I O N S  S T A R T  H E R E
*****************************************************************************/

/*  Setup a new connection - and make it the current connection.
    This routine should be used when there is only one connection.

	kerberos_info -- if NULL kerberos is disabled
					 otherwise uses kerberos security
    IMPLICIT OUTPUTS:
      context	- ptr to the current context.
*/
mucom_setup(
  char *	host,
  char *	service,
  int		timer, KerbInfo *kerberos_info)
{
  int		ret_val;

  mucom_setup_timeout (timer);
  DPRINTF("before context_setup()"); 
  ret_val = context_setup(&contexts[0], host, service, kerberos_info, "N"); 
  contexts[0].name[0] = '\0';
  context = &contexts[0];			/* set current connection */

  return (ret_val);
}

/*  Make a TCP connection to a remote port, send the request and 
    receive a reply.

    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
int
mucom_send(
  char *	request,		/* request buffer */
  int		reqlen,			/* request length */
  char *	reply,			/* reply buffer */
  int *		replen)			/* reply buffer size in;
					   reply length out */
{
  int		rc;			/* return code */

  if (!context->ready) {
    if (!context->status) context->status = E_mucom_not_setup;
    return context->status;
  }

  /*  Attempt the transmission.
  */
  rc = xmit(request, reqlen, reply, replen);
  /* printf( "return from xmit=%d\n",rc); */
  return context->status = rc;
}

/* Return information about current connection.

    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
char *
mucom_audit_info(
  char *	host,			/* hostname */
  char *	ipaddr,			/* IP address */
  int *		port,			/* port number */
  int *		errorno,		/* last error encountered */
  char *	errtext)		/* error text */
{
  unsigned char *addr;

  addr = (unsigned char *) &((struct in_addr *) context->host.h_addr)->s_addr;
  strncpy(host, context->host.h_name, 512);
  sprintf(ipaddr, "%u.%u.%u.%u", addr[0], addr[1], addr[2], addr[3]);
  *port = context->server_addr.sin_port;
  if (*port == 0) *port = atoi(context->service_name);
  *errorno = context->context_errno;
  /* initialize err_text */
  errtext[0] = '\0';
  if (context->status >= EB_WAPI && context->status < E_mucom_last) {
    strcpy (errtext, err_msg[context->status - EB_WAPI]);
  } else *errtext = '\0';		/* no error text */
  strcat (errtext, context->errortext);/* append the error text if any */
  return (0);
}

/* Return information about current connection.

    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
char *
mucom_audit_info_v2 (
  char *	host,			/* hostname */
  char *	ipaddr,			/* IP address */
  int *		port,			/* port number */
  int *		errorno,		/* last error encountered */
  char *	errtext,		/* error text */
  char *	connection)		/* connection name */
{
  mucom_audit_info (host, ipaddr, port, errorno, errtext);

  /* Error text is now used for additional supplementary information
   * and NOT for the standard error message for this mucom status code.
   */
  if ( strlen(context->errortext) != 0 ) {
    strcpy (errtext, context->errortext);
  } else {
    strcpy (errtext, "");
  }
  strcpy (connection, context->name);

  return (0);
}

/*  Setup the global (common to all connections) timeout.
*/
void
mucom_setup_timeout(
  int		timer
)
{
  if (timer <= 0) timer = 5;
  global.timer = timer;

  return;
}

/******************************************************************************
 S T A T I C   F U N C T I O N   D E F I N I T I O N S   S T A R T   H E R E
******************************************************************************/


/*  Setup the context for a new connection.
*/
static int
context_setup(
  Context *	ctx,
  char *	host,
  char *	service,
  KerbInfo *kerberos_info,
  char *	streaming	/* "Y" or "N" */
)
{
  static int	first_time=1; /* used to avoid kerberos setup for every call */
  int		i,ret_val;
  struct hostent * host_ptr;
  struct servent * service_ptr;

  DPRINTF("1"); 

  if (ctx->ready == True) { /* not the first time */
    DPRINTF("c"); 
    context_shutdown(ctx);
    DPRINTF("c"); 

  }

  DPRINTF("+"); 

  ctx->used = True;

  ctx->host_name = strcap(host);

  DPRINTF("+"); 

  ctx->service_name = strcap(service);
  if ( (host_ptr = gethostbyname(host)) == NULL ) {
    return ctx->status = E_mucom_no_host;
  }

  DPRINTF("2"); 

  /* Copy the 'struct hostent' into malloc'd memory.
   */
  ctx->host.h_name = (char *) malloc (strlen(host_ptr->h_name) + 1);
  strcpy (ctx->host.h_name, host_ptr->h_name);
  /* empty for loop to culculate number of h_aliases */
  for ( i = 0; host_ptr->h_aliases[i] != NULL; i++ ); 
  ctx->host.h_aliases = (char **) malloc ((i + 1) * sizeof(char *));
  for ( i = 0; host_ptr->h_aliases[i] != NULL; i++ ) {
    ctx->host.h_aliases[i] = (char *) malloc (strlen(host_ptr->h_aliases[i]) + 1);
    strcpy (ctx->host.h_aliases[i], host_ptr->h_aliases[i]);
	DPRINTF(".");
  }
  DPRINTF("3"); 

  ctx->host.h_aliases[i] = NULL;
  ctx->host.h_addrtype = host_ptr->h_addrtype;
  ctx->host.h_length = host_ptr->h_length;
  for ( i = 0; host_ptr->h_addr_list[i] != NULL; i++ ); /* empty for loop */
  ctx->host.h_addr_list = (char **) malloc ((i + 1) * sizeof(char *));
  for ( i = 0; host_ptr->h_addr_list[i] != NULL; i++ ) {
    ctx->host.h_addr_list[i] = (char *) malloc (host_ptr->h_length);
    memcpy (ctx->host.h_addr_list[i],
            host_ptr->h_addr_list[i],
            host_ptr->h_length);
  }
  ctx->host.h_addr_list[i] = NULL;
  DPRINTF("1"); 
  /*  Check to see if supplied service is a port number or  
      a service name. 
  if (service[0] >= '0' && service[0] <= '9') {
    ctx->port = atoi(service);
    service_ptr = getservbyport(ctx->port, Protocol);
  } else {
    ctx->port = 0;                    no port num  
    service_ptr = getservbyname(service, Protocol);
  }
  if (service_ptr == NULL) {
    context_host_free (ctx);
    return ctx->status = E_mucom_no_service;
  } */
  /* Copy the 'struct servent' into malloc'd memory 
  ctx->service.s_name = (char *) malloc (strlen(service_ptr->s_name) + 1);
  strcpy (ctx->service.s_name, service_ptr->s_name);
  for ( i = 0; service_ptr->s_aliases[i] != NULL; i++ );     empty for loop 
  ctx->service.s_aliases = (char **) malloc ((i + 1) * sizeof(char *));
  for ( i = 0; service_ptr->s_aliases[i] != NULL; i++ ) {
    ctx->service.s_aliases[i] = (char *) malloc (
                                     strlen(service_ptr->s_aliases[i]) + 1);
    strcpy (ctx->service.s_aliases[i], service_ptr->s_aliases[i]);
  }
  DPRINTF("2"); 
  ctx->service.s_aliases[i] = NULL;
  ctx->service.s_port = service_ptr->s_port;
  ctx->service.s_proto = (char *) malloc (strlen(service_ptr->s_proto) + 1);
  strcpy (ctx->service.s_proto, service_ptr->s_proto); */
  /*  Initialize all the socket values in the buffer.  Clear the memory.*/
  memset((char *) &ctx->server_addr, 0, sizeof(struct sockaddr_in)); 
  ctx->server_addr.sin_family = AF_INET;

  /*  Set the address. */
  ctx->server_addr.sin_addr.s_addr =
    ((struct in_addr *) (ctx->host.h_addr))->s_addr;

  DPRINTF("3"); 
  /*  Set the port.
  */
  /* ctx->server_addr.sin_port = ctx->service.s_port; */
  // 061023 (eym)
  // need to correct the endian-ness of the port 
  // number.  This must be in the network-byte order,
  // not the host byte order.
   ctx->server_addr.sin_port = (uint16_t)htons(atoi(service)); 

  /* Set 'streaming MUs' flag.
  */
  if ( *streaming == 'Y' ) {
    ctx->streaming = True;
  } else {
    ctx->streaming = False;
  }

  DPRINTF("4"); 
  /* Set 'kerberized' flag.
  */
  if ( kerberos_info != NULL){
    ctx->kerberized = True;
	  if (first_time) {
	    muss_setupKerberos(kerberos_info->keytab,kerberos_info->client_principal, 
					     kerberos_info->ccfile, kerberos_info->tgt_lifetime);
      if ( (ret_val = muss_gssObtainTGT()) != 0 ){
		  DPRINTF("before get tgt()"); 
	      muss_gssGetDiagnosticText(ctx->errortext);
 	      return (ctx->status = E_mucom_kerberos_failure);
      } 
	    first_time = 0;
	  }
	  /* copy the kerberos info into static variable for later use*/
	  memcpy(&kerb_info, kerberos_info, sizeof(kerb_info));
  } else {
    ctx->kerberized = False;
  }
  DPRINTF("5"); 
  ctx->ready = True;		/* flag as initialized */
  ctx->sock = 0;
  return ctx->status = E_mucom_OK;
}

/*  Shutdown connection.
*/
static void
context_shutdown(
  Context *	ctx
)
{
  int		i;

  DPRINTF("("); 
  context_host_free (ctx);
  DPRINTF(")"); 

  /*
  for ( i = 0;  ctx->service.s_aliases[i] != NULL; i++ ) {
    DPRINTF("-"); 
    MUCOM_FREE (ctx->service.s_aliases[i]);
  }
  */
  DPRINTF("*");
  MUCOM_FREE (ctx->service_name);
  DPRINTF("*");
  MUCOM_FREE (ctx->service.s_aliases);
  DPRINTF("*");
  MUCOM_FREE (ctx->service.s_name);
  DPRINTF("*");

  MUCOM_FREE (ctx->service.s_proto);
  /* MUCOM_FREE (ctx->service_name);
  MUCOM_FREE (ctx->host_name); */
  DPRINTF("*");

  if (ctx->sock != 0) { /* close streaming socket */
    shutdown (ctx->sock, 2);
    close (ctx->sock);
    ctx->sock = 0;
  }
  DPRINTF("*");
  ctx->ready = False;
  ctx->used = False;
  ctx->name[0] = '\0';

  return;
}

/*  Idle for 1/Ticks_per_second (= 0.05) seconds.
*/
static void
idle()
{
  int		nfds = 0;
  fd_set		readfds ;
  fd_set		writfds ;
  fd_set		exptfds ;
  struct timeval timer;

  timer.tv_sec  = 0;
  timer.tv_usec = 1000000 / Ticks_per_second;
	FD_ZERO(&readfds);
	FD_ZERO(&writfds);
	FD_ZERO(&exptfds);
  select(nfds, &readfds, &writfds, &exptfds, &timer); 
}


/*  Capture a copy of a source string.
*/
static char *
strcap(char *source)
{
  char *	copy;

  copy = (char *)malloc(strlen(source) + 1);
  strcpy(copy, source);
  return copy;
}

/*  Connect a socket to the remote port.
    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
static int
mucom_connect (
  int 		sock,
  int *		tries
)
{
  int			try_again;
  fd_set		writefds;
  struct timeval	timeout;
  int			rc;			/* return code */

  /*  Set socket to nonblock so connection won't hang if server is down.
  */
  if (fcntl(sock, F_SETFL, O_NONBLOCK) != 0) {
    context->context_errno = errno;		 /* save the error code */ 
    return context->status = E_mucom_socket_error;
  }	

  try_again = 1;
  while ( try_again ) {
    errno = 0;
    rc = connect (sock,
                  (struct sockaddr *) &context->server_addr,
                  sizeof(struct sockaddr_in));
    if ( rc == -1 ) {
      if ( errno == EINPROGRESS ) {

        /* Just to be safe - let's set the timeout */
        errno = 0;
        timeout.tv_sec = *tries / Ticks_per_second;
        timeout.tv_usec = (*tries % Ticks_per_second) * 1000000 / Ticks_per_second;
        FD_ZERO (&writefds);
        FD_SET (sock, &writefds);
        /* Wait for event - or timeout */
        rc = select ((int)sock + 1,
                     0,
                     //(fd_set *)&writefds.fds_bits,
		     // in RHEL, use __fds_bits
		     (fd_set *)&writefds.__fds_bits,
                     0,
                     &timeout);
        if ( rc == 1 ) {
          try_again = 0;
          continue;
        }
        if ( rc == 0 ) /* select timed out */ {
          context->context_errno = 0;
          return context->status = E_mucom_connect_timeout;
        }
        /* Assume error is EINTR from a SIGPIPE signal so try again */
        printf ("Select failed: errno = %d\n", errno);

      } else if ( errno == EISCONN ) /* is already connected */ {
        try_again = 0;
        continue;

      } else if ( errno == EINVAL ) {
        context->context_errno = errno;
        return context->status = E_mucom_connect_timeout;
      }

      if ( (*tries)-- <= 0 ) {
        context->context_errno = errno;
        return context->status = E_mucom_connect_timeout;
      }
      idle();

    } else /* succesful connect */ {
      try_again = 0;
      continue;
    }
  }
  return context->status = E_mucom_OK;
}

/*  Create a socket and connect to the remote port.
    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
static int
mucom_socket (
  int *			sock,
  int *			tries
)
{
  int			rc;

  if ((*sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
    context->context_errno = errno;		/* save the error code */
    return context->status = E_mucom_socket_error;
  }
  if ( (rc = mucom_connect (*sock, tries)) != E_mucom_OK ) {
    close (*sock);
    return rc;
  }
  return E_mucom_OK;
}

/*  Send the request.
    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
static int
mucom_req (
  int           sock,
  char *	request,
  int		reqlen,
  int *         tries
)
{
  int		offset;			/* offset within request buffer */
  int		rc;			/* return code */
  int		chunk;			/* size of packet */

  /*  Start sending the request in packets.   */

  printf( "Enter mucom_req %10.10s\n",request);
  for (offset = 0; offset < reqlen; offset += chunk) {
    chunk = reqlen - offset;
    if (chunk > Send_packet_size) chunk = Send_packet_size;

    while ((rc = send(sock, &request[offset], chunk, 0)) != chunk) {
      context->context_errno = errno;
      if (!(rc == -1 && errno == EAGAIN))
      {
        return context->status = E_mucom_send_error;
	}
      if ((*tries)-- <= 0)
        return context->status = E_mucom_send_timeout;
      idle();
    }
  }
  return E_mucom_OK;
}

/*  Recieve the reply.
    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
static int
mucom_rep (
  int		sock,
  char *	reply,
  int *		replen,
  int *         tries
)
{
  int		chunk;			/* size of packet */
  int		len;
  int		rc;			/* return code */
  int		repsz;			/* reply buffer size */
  long		explen;			/* expected read length */
  unsigned long	network_len;		/* message length */
  char		ascii_explen[6];	/* message length */
  MUExtnHdr extn_hdr;

  printf( "enter mucom reply\n");
  /*  replen is a pointer to an argument that  specifies  the  size  of  the
      reply buffer on input and gives the actual  length  of  the  reply  on
      output from mucom_send.
  */
  repsz = *replen;			/* get reply buffer size */
  *replen = 0;
  
  do {
  	/* read MU extention header */
	if ((rc = recv(sock, reply, sizeof(extn_hdr), 0)) == -1){
      context->context_errno = errno;
      if (errno != EAGAIN) {
        return context->status = E_mucom_recv_error;
      }
      if ((*tries)-- <= 0) {
        return context->status = E_mucom_recv_timeout;
      }
      idle();
    }
  }while(rc == -1);
  memcpy(&extn_hdr, reply, sizeof(extn_hdr));

  /* find the total message length */
  memcpy(ascii_explen, extn_hdr.tot_msg_len, sizeof(extn_hdr.tot_msg_len));
  ascii_explen[sizeof(extn_hdr.tot_msg_len)] = '\0';

  /* now start reading the rest of the message */ 
  /*  We read it in  4KB  chunks  to  avoid  a  timeout
      problem with remnants less than 128 bytes.  (jkl knows the details.)
  */
  len = sizeof(extn_hdr);
  explen = atol(ascii_explen);
  do {
    chunk = explen - len;
    if (chunk > Recv_packet_size) chunk = Recv_packet_size;
    while ( (rc = recv(sock, reply+len, chunk, 0)) == -1 ) {
      context->context_errno = errno;
      if (errno != EAGAIN) {
        return context->status = E_mucom_recv_error;
      }
      if ((*tries)-- <= 0) {
        return context->status = E_mucom_recv_timeout;
      }
      idle();
    }
    len += rc;
    /*  If buffer is now full and  EOF  has  not  been  received,  we  quit.
	(Hence, the reply buffer should be at least 1 byte greater than  the
	maximum message length expected.)
    */
    if (len >= repsz) return context->status = E_mucom_recv_overflow;

  } while ( ! ( (rc == 0) || ((explen != 0) && (len >= explen)) ) );
  *replen = len;

  if (len > explen) {	/* extraneous data */
    printf("mucom::mucom_rep() expected %d bytes, found %d so far...",explen,len);
    return context->status = E_mucom_recv_overflow;
  }
  if (rc == 0) {	/* EOF before expected length read */
    context->context_errno = 0;
    return context->status = E_mucom_recv_error;
  }

  /*  If any previous reply was longer than the current one, the tail of
      the reply buffer will still contain remnants of other replies.
      Append a null character to this reply so anyone using "print" to 
      debug won't see extraneous information of no relevance.  Done in this
      manner for efficiency, but perhaps should use the following memset:

      memset((char *) &reply[len], 0, (repsz - len));
  */
  reply[len] = '\0';
  return E_mucom_OK;
}

/*  Make a TCP connection to a remote port, send the request and 
    receive a reply.
    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
static int
xmit(
  char *	request,
  int		reqlen,
  char *	reply,
  int *		replen)
{
  time_t	now;			/* time now (in elapsed secs) */
  int		rc;			/* return code */
  int		tries;
  int		sock;
  time_t	start;                  /* start time (in elapsed secs) */
  MUSS_VoidPtr muss_ctx; /* kerberos context */
  int		buff_len=MU_MSGLEN*2, mu_data_len=MU_MSGLEN;
  int		seal_len, sec_token_len, msg_type;
  char	    buff[MU_MSGLEN*2], seal_msg[MU_MSGLEN*2], sec_token[MU_MSGLEN];
  char 		mu_data[MU_MSGLEN];
	int i;

  /*  Trap SIGPIPE signal that arises when the WEBS side of
      the socket is broken before the wapi finishes.  Without this trap,
      the SIGPIPE signal terminates the encore application.

      [kmk] could this not be done once in mucom_init?
  */
  signal(SIGPIPE, SIG_IGN);

  /* Clear error information for current context.
   */
  context->errortext[0] = '\0';
  context->context_errno = 0;
  context->status = E_mucom_OK;

  /*  Establish the time we started the communication cycle.
  */
  start = time(NULL);
  tries = global.timer * Ticks_per_second;

  if (context->sock == 0) {		/* no streaming socket open */
    /*  Try to connect the socket until successful or we have used up all our
        timer trying.
    */
    if ( (rc = mucom_socket (&sock, &tries)) != E_mucom_OK ) {
      return rc;
    }
  } else {
    sock = context->sock;		/* streaming socket */
  }

  /*  Recalculate time left.
  */
  now = time(NULL);
  tries = (start + global.timer - now) * Ticks_per_second;

  if ( ! context->kerberized ) {
	  /* format the msg */
		if ( PKIFlag == 1 ) {
	    mucom_marshall_req(PKI,NULL,0,(char *)pbkey,pbkey_len,buff,&buff_len);
			printf("PKI: mucom_marshall_req bufflen=%d\n",buff_len);
		} else {
			if ( DESFlag == 1 ) {
			  seal_len=sizeof(seal_msg);
			  B_DESEncrypt(request,reqlen,seal_msg,&seal_len, DESKey );
        dump_in_HEX(seal_msg, seal_len, 10);
		    mucom_marshall_req(DES, seal_msg, seal_len, sec_token,
				                   sec_token_len, buff, &buff_len);
			} else {
	      mucom_marshall_req(CLR, request, reqlen, NULL, 0, buff, &buff_len);
			}
		}
    /*  Try to send on the socket.  */
    if ( (rc = mucom_req (sock, buff, buff_len, &tries)) != E_mucom_OK ) {
      close(sock);
      /* Attempt to send on streaming socket failed - could be because
         listener timed out and closed connection. Try again! */
      if (context->sock != 0) {
         context->sock = 0;
         if ( (rc = mucom_socket (&sock, &tries)) != E_mucom_OK ) {
           return rc;
         }
         if ((rc = mucom_req (sock, buff, buff_len, &tries)) != E_mucom_OK) {
            close(sock);
            return rc;
         }
       } else {
         return rc;
       }
     }
  } else { /* context->kerberized */ 
    /* Seal the message */
		if ( DESFlag == 1 ) {
			  seal_len=sizeof(seal_msg);
			  B_DESEncrypt(request,reqlen,seal_msg,&seal_len, DESKey );
		    mucom_marshall_req(DES, seal_msg, seal_len, NULL,
				                   0, buff, &buff_len);
		} else {
	    	printf("muss_gssSeal msg\n");
	      if(muss_gssSeal(request, reqlen, kerb_info.server_principal, seal_msg, 
		    		&seal_len, sec_token, &sec_token_len, &muss_ctx) != 0){
    	    muss_gssGetDiagnosticText(context->errortext);
	 		    muss_gssCleanUp(&muss_ctx);
					printf("muss_gssSeal failed\n");
			    return (E_mucom_kerberos_failure); 
		    }
				printf("tokenlen=%d\n",sec_token_len);
		    buff_len = sizeof(buff);
		    /* Format the kerberos message to be sent to the host */
		    if ((rc = mucom_marshall_req(KRB, seal_msg, seal_len, sec_token,
			    	sec_token_len, buff, &buff_len))!=E_mucom_OK) {
			    muss_gssCleanUp(&muss_ctx);
			    return rc;
	    	}
		}
  
    /*  Calculate time left.  */
    now = time(NULL);
    tries = (start + global.timer - now ) * Ticks_per_second;
    /* send the kerberized buffer + security token */
		printf("mucom_req msg\n");
    if ( (rc = mucom_req (sock, buff, buff_len, &tries)) != E_mucom_OK ) {
      close(sock);
      /* Attempt to send on streaming socket failed - could be because
         listener timed out and closed connection. Try again!
      */
      if (context->sock != 0) {
        context->sock = 0;
        if ( (rc = mucom_socket (&sock, &tries)) != E_mucom_OK ) {
			muss_gssCleanUp(&muss_ctx);
            return rc;
		}
        if ( (rc = mucom_req (sock, buff, buff_len, &tries)) != E_mucom_OK ) {
        	close(sock);
		    muss_gssCleanUp(&muss_ctx);
            return rc;
        }
      } else {
		    muss_gssCleanUp(&muss_ctx);
        return rc;
      }
    }
  }

  if (!context->streaming) {
    /*  If not using streaming socket, then shutdown the socket to
     *  ensure an EOF at the listener.
     */
    if (shutdown(sock, 1) != 0) context->context_errno = errno;
  }

  /*  Calculate time left.
  */
  now = time(NULL);
  tries = (start + global.timer - now) * Ticks_per_second;
  /* get the reply from the peer */
	printf("get the reply\n");
  rc = mucom_rep (sock, reply, replen, &tries);
  if (context->streaming) {
    if (rc != E_mucom_OK) {	/* shutdown streaming socket on error only */
      shutdown(sock, 2);
      close(sock);
      context->sock = 0;
    } else {
      context->sock = sock;	/* remember streaming socket */
    }
  } else {			/* always shutdown non-streaming socket */
    shutdown(sock, 2);
    close(sock);
  }
  /* return the error code from mucom_rep() */
  if ( rc != E_mucom_OK) {
	printf("mucom_rep() not ok\n");
	WriteFile("DESFail.tmp",buff,10);
	return rc;
	}

  /* process the reply */
  /* get the message type(clear or kerberos) */
  if ((rc = mucom_unmarshall_rep((char *) reply, *replen, &msg_type, buff, 
				 &buff_len)) != E_mucom_OK) {
    return rc;
  }
  switch (msg_type ) {
  case KRB:  /* if kerberos message */
    if (context->kerberized) {
      if (muss_gssUnseal(buff, buff_len, mu_data, &mu_data_len, &muss_ctx)
	  != 0) {
    	muss_gssGetDiagnosticText(context->errortext);
	muss_gssCleanUp(&muss_ctx);
	return (E_mucom_kerberos_failure); 
      }	
      muss_gssCleanUp(&muss_ctx);
      memcpy(reply, mu_data, mu_data_len);
      *replen = mu_data_len;
    }
    break;
  case PKI: /* invalid msg type */
    printf("PKI privateKeyDecrypt()%d\n",buff_len);
    mu_data_len = 800;
    WriteFile("DES.enc",buff,buff_len);
    PrivateKeyDecrypt(buff,buff_len-1,mu_data,&mu_data_len,pvkey,pvkey_len);
    WriteFile("DES.key",mu_data,mu_data_len);
    memcpy(DESKey,mu_data, mu_data_len);      /* save the DESKey */
    memcpy(reply, mu_data, mu_data_len);
    *replen = mu_data_len;
    break;
  case DES:  /* if kerberos message */
    mu_data_len=3000;
    B_DESDecrypt(buff, buff_len, mu_data,&mu_data_len, DESKey);
    memcpy(reply, mu_data, mu_data_len);
    *replen = mu_data_len;
    break;
  case CLR: /* clear msg */
    memcpy(reply, buff, buff_len);
    *replen = buff_len; 
    break;
  default : 
    return (E_mucom_invalid_msg_type); 
  }
  
  rc = E_mucom_OK;
  return rc;
}


static int mucom_marshall_req(int msg_type, char *seal_msg, int seal_len, 
					 char *sec_tok, int sec_tok_len, char *bundled_msg,
					 int *bundled_msg_len)
{
	int i;
	MUExtnHdr extn_hdr;

	/* initialize the MU buffer */
	memset(bundled_msg, ' ', *bundled_msg_len);
	/** start filling up the MU Extention header **/
	/* Initialize the hdr buffer */
	memset(&extn_hdr, ' ', MUExtnSz);

	/* message type: Kerberos or Clear */
	switch (msg_type) {
  case KRB:
		memcpy(extn_hdr.msg_type, "KRB ", 4);
    break;
	case CLR:
		memcpy(extn_hdr.msg_type, "CLR ", 4);
    break;
	case PKI:
		memcpy(extn_hdr.msg_type, "PKI ", 4);
    break;
	case DES:
		memcpy(extn_hdr.msg_type, "DES ", 4);
    break;
  }

	/* store total message length as string ex: 256 as "00256" */
	mucom_convertval2str(MUExtnSz+seal_len+sec_tok_len, 
							extn_hdr.tot_msg_len,sizeof(extn_hdr.tot_msg_len));
	/* store token message length as string ex: 256 as "00256" */
	mucom_convertval2str(sec_tok_len, extn_hdr.tok_err_len,
								sizeof(extn_hdr.tok_err_len));
	if (msg_type == KRB || msg_type == DES )
	{
		/* Kerberos MVS prinicpal prefix (Client applId+regionid) -- TBD */
		memcpy(extn_hdr.krb_prn_name, kerb_info.server_principal, 
										strlen(kerb_info.server_principal));
		/* filler area(64 chars) for future expansion */
		memset(extn_hdr.filler, ' ', sizeof(extn_hdr.filler));
	}
	/* now copy the MU extention hdr into bundled message buffer */
	memcpy(bundled_msg, &extn_hdr, MUExtnSz);
	/* security token */
	if (sec_tok_len != 0)
		memcpy(bundled_msg+MUExtnSz, sec_tok, sec_tok_len);
	/* sealed MU message */
	memcpy(bundled_msg+MUExtnSz+sec_tok_len, seal_msg, seal_len);
	*bundled_msg_len = MUExtnSz+seal_len+sec_tok_len;

	return (E_mucom_OK);
}


static int mucom_unmarshall_rep(char *reply, int replen, int *msg_type, 
									char *out_msg, int *out_len)
{
	char str[256], err_str[512];
	int i=0,tot_msg_len=0, err_len=0, sec_ret_cd;
	MUExtnHdr extn_hdr;
	MUExtnErr extn_err;
	MussDiagnostic muss_diag;

	/* Initialize the MU extn header buffer */
	printf( "Enter mucom_unmarshall_rep\n"); 
	memset(&extn_hdr, ' ', MUExtnSz);
	/* copy the header part of the reply into MU extn header buffer */
	memcpy(&extn_hdr, reply, MUExtnSz);
	/* get message type */
	if (!strncmp(extn_hdr.msg_type, "KRB", 3) )
		*msg_type = KRB;
	else if	(!strncmp(extn_hdr.msg_type, "CLR", 3) )
		*msg_type = CLR;
	else if	(!strncmp(extn_hdr.msg_type, "PKI", 3) )
		*msg_type = PKI;
	else if	(!strncmp(extn_hdr.msg_type, "DES", 3) )
		*msg_type = DES;
	else
		*msg_type = -1;

	/* get total message length */
	memcpy(str, extn_hdr.tot_msg_len, sizeof(extn_hdr.tot_msg_len));
	str[sizeof(extn_hdr.tot_msg_len)] = '\0';
	tot_msg_len = atoi(str);;

	/*get error message length */
	memcpy(str, extn_hdr.tok_err_len, sizeof(extn_hdr.tok_err_len));
	str[sizeof(extn_hdr.tok_err_len)] = '\0';
	err_len = atoi(str);
	if (err_len == 0) {  /* no error returned in the reply */
		/* calculate the actual mu_data length */
		*out_len = tot_msg_len - (err_len+MUExtnSz);
		memcpy(out_msg, reply+MUExtnSz+err_len, *out_len);
	} else { /* error */
		/*get type of error returned */
		memcpy(&extn_err, reply+MUExtnSz, err_len);
		/* retrieve erro type */
		memcpy(str, extn_err.err_type, sizeof(extn_err.err_type));
		str[sizeof(extn_err.err_type)] = '\0';
		sec_ret_cd =  atoi(str);
		/* retreive error text */
		memcpy(str, extn_err.err_txt, sizeof(extn_err.err_txt));
		str[sizeof(extn_err.err_txt)] = '\0';
		if (sizeof(extn_err.err_txt) > MU_ERRLEN){
			strncpy(context->errortext, extn_err.err_txt, MU_ERRLEN-1);
			context->errortext[MU_ERRLEN] = '\0';
		} else {
			strncpy(context->errortext, extn_err.err_txt, 
											sizeof(extn_err.err_txt) -1);
			context->errortext[sizeof(extn_err.err_txt)] = '\0';
		}
		if (sec_ret_cd == 1) { /* kerberos related error */
			/* fill the MUSS diagnostic */
			memcpy(str, extn_err.krb_maj_cd, sizeof(extn_err.krb_maj_cd));
			str[sizeof(extn_err.krb_maj_cd)] = '\0';
			muss_diag.major = atoi(str);
			memcpy(str, extn_err.krb_min_cd, sizeof(extn_err.krb_min_cd));
			str[sizeof(extn_err.krb_min_cd)] = '\0';
			muss_diag.minor = atoi(str);
			memcpy(muss_diag.error_text, extn_err.err_txt,
											sizeof(extn_err.err_txt)-1);
			muss_diag.error_text[sizeof(extn_err.err_txt)] = '\0';
			muss_gssNotifyFailure(&muss_diag);
			return (E_mucom_server_failure);
		}
		else /* other errors */
			return (E_mucom_server_failure);	
	}
	return E_mucom_OK;
}

static int mucom_convertval2str(int val, char *str, int size)
{
	int rem,cnt,i, num_zeros;

	memset(str, '0', size);
	for (i=size-1; i>=0; i--)
	{
		rem = val % 10;
		str[i] = rem+'0';
		val = val/10;
		/* if (val == 0) break; */
	}
}

/*  Free memory used to store host info
 */
static void
context_host_free (
  Context *	ctx
)
{
  int		i;

  DPRINTF("xxx "); 
  /*
  for ( i = 0; ctx->host.h_aliases[i] != NULL; i++ ) {
    DPRINTF("SSS "); 
    MUCOM_FREE(ctx->host.h_aliases[i]);
  }
  */
  DPRINTF("xxx "); 
  MUCOM_FREE (ctx->host.h_aliases);
  MUCOM_FREE (ctx->host.h_name);
  
  DPRINTF("xxx "); 

  for ( i = 0; ctx->host.h_addr_list[i] != NULL; i++ ) {
    MUCOM_FREE (ctx->host.h_addr_list[i]);
    DPRINTF("sss "); 
  }
  MUCOM_FREE (ctx->host.h_addr_list);
  DPRINTF("xxx "); 

  return;
}


int dump_in_HEX(char *buf, int buf_len, int chars_per_line)
{
	int i=0, len;

    len = 0;	
	printf("\nDUMP STARTS HERE\n"); 
	while (len < buf_len)
	{
		for (i=len; i < buf_len && i < len+chars_per_line; i++) 
			printf( "%2X ", buf[i]);
        printf( "\n");
		len += chars_per_line;
    }
	printf( "DUMP ENDS HERE\n"); 
}


/****************************************************************************
    E N D   O F   C O D E   T H A T   I S   I N   U S E 
****************************************************************************/


/******************************************************************************
	 F U N C T I O N S   N O T   I N   U S E 
******************************************************************************/

#if 0
/*  Set 'streaming' flag.

    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
int
mucom_set_stream(
  char *	flag
)
{
  if ( *flag == 'Y' ) {
    context->streaming = True;
  } else {
    context->streaming = False;
  }
  return (0);
}

/*  Shutdown all connections.
*/
int
mucom_shutdown(
  void
)
{
  int		i;

  for (i = 0; i < Max_contexts; i++) {
    if (contexts[i].ready == True) {
      context_shutdown(&contexts[i]);
    }
  }
  return E_mucom_OK;
}

/*  Set the current connection.
    The named connection must previously have been setup in a call
    to mucom_setup_connect().

    IMPLICIT OUTPUTS:
      context	- ptr to the (new) current context.
*/
int
mucom_set_connect (
  char *	name
)
{
  int		i;

  for (i = 0; i < Max_contexts; i++) {
    if ((contexts[i].used == True) && (strcmp(contexts[i].name, name) == 0)) {
      context = &contexts[i];		/* Set current connection */
      return E_mucom_OK;		/* FOUND */
    }
  }
  context = &null_context;
  return E_mucom_connect_not_found;	/* NOT FOUND */
}

/*  Setup a new connection.
    This routine should be used when there is more than one connection.
 */
int
mucom_setup_connect (
  char *	name,
  char *	host,
  char *	service,
  char *	principal,
  char *	streaming
)
{
  int		i;
  int		ret_val;

  /* Check for existing connection - will replace it if found */
  for (i = 0; i < Max_contexts; i++) {
    if ((contexts[i].used == True) && (strcmp(contexts[i].name, name) == 0)) {
      break;
    }
  }
  if (i == Max_contexts) {
    /* Search for empty slot - assume there is one! */
    for (i = 0; i < Max_contexts; i++) {
      if (contexts[i].used != True) {
        break;
      }
    }
    assert (i != Max_contexts);
  }

  ret_val = context_setup (&contexts[i], host, service, principal, streaming);
  strcpy (contexts[i].name, name);

  return ret_val;
}

/* Setup the GSS configuration
 */
int
mucom_setup_kerberos (
  char *        keytab,
  char *        principal,
  char *        cache,
  char *	tgt_path,
  char *	tgt_lifetime,	/* hours */
  char *        errortext
)
{
  int           i;
  int		ret_val;

  /* Credentials Cache file */
  sprintf (global.ccfile_env, "KRB5CCNAME=FILE:%s", cache);
  ret_val = putenv(global.ccfile_env);

  /* Service Key Table (keytab) file */
  sprintf (global.keytab, "FILE:%s", keytab);
  sprintf (global.keytab_env, "KRB5TKNAME=%s", global.keytab);
  ret_val = putenv(global.keytab_env);

  /* Method server principal */
  i = strlen(principal) + 1;
  if ( i > MUCOM_MAX_FQDN || i == 1 ) {
     return E_mucom_invalid_principal;
  }
  strcpy (global.server_fqdn, principal);

  /* Ticket Granting Ticket lifetime - in hours */
  if ( tgt_lifetime == NULL || strlen(tgt_lifetime) == 0 ) {
    strcpy (global.tgt_lifetime, MUCOM_TGT_LIFETIME);
  } else {
    strcpy (global.tgt_lifetime, tgt_lifetime);
  }

  /* Path of 'kinit' program */
  if ( tgt_path == NULL || strlen(tgt_path) == 0 ) {
    strcpy (global.tgt_path, MUCOM_TGT_PATH);
  } else {
    strcpy (global.tgt_path, tgt_path);
  }

  sprintf (global.tgt_program, "%s -k -t %s -l %s %s",
           global.tgt_path,
           global.keytab,
           global.tgt_lifetime,
           global.server_fqdn);
  if ( (ret_val = gssObtainTGT(errortext)) != 0 ) {
    return E_mucom_fail_obtain_tgt;
  } 
  return E_mucom_OK;
}

/*  Mucom_xmit is a jacket to mucom_send.  It conforms to the Glue  "escape"
    call signature.  The jacket is necessary in order to transform the  args
    into the signature employed  by  mucom_send  (which  is  a  little  more
    expressive in that the size of the reply buffer can be passed).

    IMPLICIT INPUTS:
      context	- ptr to the current context.
*/
int
mucom_xmit(
  char *	message,		/* unnecessary here */
  int		req_len,		/* request length */
  char *	request,		/* request message */
  char *	reply)			/* reply buffer */
{
  int		rc;			/* return code */
  int		rep_len;		/* reply size/length */
  char		response_id[9];		/* response id */

  /*  [kmk] Fake the reply buffer size -- actually, we don't know how big it
      is.  If it is bigger than 32KB, an E_mucom_recv_overflow error will be
      returned if the  reply  exceeds  32KB.   However,  if  the  buffer  is
      smaller, an overwrite is possible.  This should be fixed.
  */
  rep_len = MU_MSGLEN;

  /* Ensure reply buffer can never be mistaken for a successful completion!!
     Null the reply buffer.
     Header is 174 bytes, Comr is 25 bytes
     WFMUHDR-STATUS-CODE is in bytes 9 to 10.
     WFMUCOMR-RETURN-CODE is in bytes 198 to 199.
  */
  memset (reply, (int)' ', MU_MSGLEN);
  memcpy (&reply[8], "99", 2);
  memcpy (&reply[197], "99", 2);

  /* Null the kerberos working buffer. 
   */
  if ( context->kerberized ) {
    gssBegin ();
  }

  /* Set the WFMUHDR-RESPONSE-ID in the request to a random number to
     identify this request.
     WFMUHDR-RESPONSE-ID is in bytes 72 to 79.
  */
  if ( tran_tag_id == 0 ) {
    /* Initialise to random starting number */
    srand48 (time(NULL));
    tran_tag_id = (unsigned long)(drand48() * 0xffffffff);
  }
  if ( tran_tag_id == (unsigned long)0xffffffff ) {
    tran_tag_id = 0x00000001;
  } else {
    tran_tag_id++;
  }
  sprintf (response_id, "%.8x", tran_tag_id);
  memcpy (&request[71], response_id, 8);

  /* Clear error information for current context.
   */
  context->errortext[0] = '\0';
  context->context_errno = 0;
  context->status = E_mucom_OK;

  rc = mucom_send(request, req_len, reply, &rep_len);

  /* Check that WFMUHDR-RESPONSE-ID for request and reply match 
  */
  if ( rc == E_mucom_OK ) {
    if ( memcmp(&request[71], &reply[71], 8) ) {
      rc = context->status = E_mucom_mismatch;
      context->context_errno = 0;
    }
  }

  return rc;
}
#endif

/******************************************************************************
			  S T A T I C  F U N C T I O N S  N O T  I N  U S E
******************************************************************************/

#if 0


#endif  

