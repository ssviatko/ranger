#include <ms2kdc.h>

extern int debug;

//
// if the principal does not exist, create one.
// if the principal already exists, do nothing and return OK.
//
ms2_sts ms2addPrincipal(ms2_context *ms2context,
			char* prnName)
{
  ms2_sts status;
  status.major = 0;
  status.minor = 0;
  
  int retval;

  krb5_principal kprinc;
  kadm5_principal_ent_rec tmpprinc;

  krb5_parse_name(ms2context->context,
		  prnName,
		  &kprinc);
  switch((retval = kadm5_get_principal(ms2context->handle,
				       kprinc,
				       &tmpprinc,
				       KADM5_PRINCIPAL_NORMAL_MASK))) {
  case 0:
    // already exists - do nothing.
    if (debug) {
      printf("ms2kdc::ms2addPrincipal() principal %s already exists, skipping...\n",
	     prnName);
    }
    break;
  case KADM5_UNK_PRINC:
    {
      if (debug) {
	printf("ms2kdc::ms2addPrincipal() creating principal %s...\n",prnName);
      }
      // copy code from kadmin.c::kadmin_addprinc()
      krb5_parse_name(ms2context->context,
		      prnName,
		      &(tmpprinc.principal));

      //
      // create a single enctype for this principal.  We will also use
      // a temporary password, since it will be immediately overwritten
      // by the call to ms2modifyPrincipal().
      //
      krb5_key_salt_tuple *ks_tuple;
      int n_ks_tuple = 0;
      ks_tuple = NULL;

      char enctype[24];
      strncpy(enctype,"des-cbc-md5:normal",24);
      krb5_string_to_keysalts(enctype,", \t",":.-", 0, &ks_tuple, &n_ks_tuple);

      time_t t0 = time(NULL);
      char password[16];
      snprintf(password,16,"%d",(int)t0);

      long mask = KADM5_PRINCIPAL;

      if ((retval = kadm5_create_principal_3(ms2context->handle,
					     &tmpprinc,
					     mask,
					     n_ks_tuple,
					     ks_tuple,
					     password))) {
	status.major = -1;
	status.minor = retval;
      }

    }
    break;
  default:
    // something else.  Bad.
    printf("ms2kdc::ms2addPrincipal() got retval=%d\n",retval);
    status.major = -1;
    status.minor = retval;
    break;
  }

  krb5_free_principal(ms2context->context,kprinc);
  return(status);
}


// 
// 
// 
ms2_sts ms2connectWithPwd(ms2_context *ms2context,
			  const ms2_principal* adminPrn,
			  char* password)
{
  ms2_sts status;
  status.major = 0;
  status.minor = 0;

  int retval;
  printf("Authenticating as principal %s with password.\n",adminPrn->name);

#if 0
  if (ms2context->def_realm) {
    free(ms2context->def_realm);
  }
  ms2context->def_realm = (char *)malloc(64 * sizeof(char));
#endif
  ms2context->def_realm[0] = '\0';
  
  // set context.
  if ((retval = kadm5_init_krb5_context(&(ms2context->context)))) {
    com_err("kadm5_init_krb5_context", retval, "while retrieving context");
    status.major = -1;
    status.minor = retval;
  }

  // set default realm.
  if ((retval = krb5_get_default_realm(ms2context->context, 
				       &ms2context->def_realm))) {
    com_err("krb5_get_default_realm", retval, "while retrieving default realm");
    status.major = -1;
    status.minor = retval;
  }

  char* svcname = NULL;

  kadm5_config_params params;
  memset((char *) &params, 0, sizeof(params));
  params.realm = ms2context->def_realm;

  char **db_args = NULL;

  retval = kadm5_init_with_password(adminPrn->name, password,
				    svcname,
				    &params,
				    KADM5_STRUCT_VERSION,
				    KADM5_API_VERSION_2,
				    db_args,
				    &(ms2context->handle));

  if (retval) {
    // some sort of error occurred.
    com_err("kadm5_wf_init_conn", retval, "while authenticating with password");
    status.major = -1;
    status.minor = retval;
  }

  return(status);
}


// 
// disconnect and free the context.
// 
ms2_sts ms2disconnect(ms2_context* ms2context)
{
  if (ms2context != NULL) {

#if 0
    free(ms2context->def_realm);
#endif
    ms2context->def_realm[0] = '\0';

    kadm5_destroy(ms2context->handle);
    ms2context->handle = NULL;
  
    free(ms2context->context);
    ms2context->context = NULL;

  }

  ms2_sts status;
  status.major = 0;
  status.minor = 0;
  return(status);
}


void ms2freePrincipalContents(ms2_principal* principal)
{
  if (principal != NULL) {
    free(principal->name);
    principal->name = NULL;
    free(principal->realmname);
    principal->realmname = NULL;
  }
  return;
}


ms2_sts ms2getPrincipalKeys(ms2_context *ms2context,
			    char* prnName,
			    krb5_keyblock *pkeyblock,
			    unsigned int *pkvno)
{
  int retval;
  ms2_sts status;
  status.major = 0;
  status.minor = 0;

  //
  // get the key
  //
  krb5_principal kprinc;
  kadm5_principal_ent_rec tmpprinc;

  krb5_parse_name(ms2context->context,
		  prnName,
		  &kprinc);

  retval = kadm5_get_principal_key(ms2context->handle,
				   kprinc,
				   &tmpprinc,
				   KADM5_PRINCIPAL_NORMAL_MASK | KADM5_KEY_DATA);
  
  if (retval != 0) {
    status.major = -1;
    status.minor = retval;
    goto ms2getPrincipalKeys_done;
  }
  
  //
  //
  //
  if (tmpprinc.n_key_data == 0) {
    // no key data?
    status.major = -1;
    status.minor = KRB5KDC_ERR_NULL_KEY;
  } else {
    // we only expect one key for the principal, so copy the first
    // key to the keyblock.  Ignore the salt.
    krb5_key_data *key_data = &tmpprinc.key_data[0];

    pkeyblock->magic = KV5M_KEYBLOCK;
    pkeyblock->enctype = key_data->key_data_type[0];
    pkeyblock->length = key_data->key_data_length[0];
    if (pkeyblock->contents) {
      free(pkeyblock->contents);
    }
    pkeyblock->contents = (krb5_octet *)malloc(pkeyblock->length * sizeof(krb5_octet));
    memcpy(pkeyblock->contents,key_data->key_data_contents[0],pkeyblock->length);
    *pkvno = key_data->key_data_kvno;
  }

  //
  // clean up memory occupied by tmpprinc here.
  //
  krb5_free_principal(ms2context->context,kprinc);

  if (debug) {
    printf("ms2kdc::ms2getPrincipalKeys() key is enctype=0x%x, data=",pkeyblock->enctype);
    int i;
    for (i=0; i<pkeyblock->length; i++) {
      // what is the key?
      printf("%02x",(unsigned char)pkeyblock->contents[i]);
      if (i%4==3) {
	printf(" ");
      }
    }
    printf("\n");
  }

  ms2getPrincipalKeys_done:

  return(status);
}

int ms2mayAddPrincipal(ms2_context *ms2context,
		       const ms2_principal* principal)
{
  // stubbed
  return(1);
}

int ms2mayGetPrincipalKeys(ms2_context *ms2context,
			   const ms2_principal* principal)
{
  // stubbed
  return(1);
}

int ms2mayModifyPrincipal(ms2_context *ms2context,
			  const ms2_principal* principal)
{
  // stubbed
  return(1);
}


ms2_sts ms2modifyPrincipal(ms2_context *ms2context,  
			   char* prnName,
			   krb5_keyblock *pdkeyblock)
{
  ms2_sts status;
  status.major = 0;
  status.minor = 0;

  if (debug) {
    int i;
    printf("ms2kdc::ms2modifyPrincipal() key is ");
    for (i=0; i<pdkeyblock->length; i++) {
      printf("%02x",(unsigned char)pdkeyblock->contents[i]);
      if (i%4==3) {
	printf(" ");
      }
    }
    printf("\n");
  }

  //
  // if the current key version modulo 256 is 255, then we
  // then we need double-write it to the database.  Cybersafe 
  // handles a kvno value of 0 in the keytab (a single byte) 
  // as a special case, so we need to avoid having a key version
  // as an exact multiple of 256.  Note that the keys at kvno=256
  // and kvno=257 are identical; the former is never used because
  // it's immediately made obsolete by the second update.
  //
  // A coordinated change is also implemented in the function
  // process_principal() in kgen.c.
  //
  int performDoubleWrite = 0;

  krb5_keyblock currentKeyblock;
  krb5_keyblock* pCurrentKeyblock = &currentKeyblock;
  memset(pCurrentKeyblock,0x00,sizeof(krb5_keyblock));
  int currentKvno;
  ms2getPrincipalKeys(ms2context,prnName,pCurrentKeyblock,&currentKvno);
  memset(pCurrentKeyblock,0x00,sizeof(krb5_keyblock));
  
  if (currentKvno % 256 == 255) {
    performDoubleWrite = 1;
  }

  //
  // grab a krb_principal for this principal and set the key.
  //
  krb5_principal kprinc;

  int retval;
  if ((retval = krb5_parse_name(ms2context->context,
				prnName,
				&kprinc))) {
    status.major = -1;
    status.minor = retval;
  }

  // add error checking here
  if ((retval = kadm5_setkey_principal(ms2context->handle,
				       kprinc,
				       pdkeyblock,
				       1))) {
    status.major = -1;
    status.minor = retval;
  }

  if (performDoubleWrite) {
    // repeat the update to the database.
    if ((retval = kadm5_setkey_principal(ms2context->handle,
					 kprinc,
					 pdkeyblock,
					 1))) {
      status.major = -1;
      status.minor = retval;
    }
  }

  krb5_free_principal(ms2context->context,
		      kprinc);


  return(status);

}

char* ms2strError(const ms2_sts* status)
{
  char* errormsg = (char *)malloc(128 * sizeof(char));
  sprintf(errormsg,"Error: major %ld, minor %ld",status->major,status->minor);
  return(errormsg);
}


/**
 * we expect the arg "principal" to point to a valid, initialized object
 * when this function is called.  If it's not, we'll allocate it here.
 */
ms2_sts ms2stringToPrincipal(const char* name,
			     const char* realm,
			     ms2_principal* principal)
{
  ms2_sts status;
  status.major = 0;
  status.minor = 0;

  if (principal == NULL) {
    if ((principal = (ms2_principal*) malloc (sizeof(ms2_principal))) == NULL) {
      // out of memory
      status.major = 9999;
      return(status);
    }
    principal->name = NULL;
    principal->realmname = NULL;
  }

  // check if the principal->realm.name is already defined.  If so, then
  // we'll have to free and malloc some fresh memory.
  // don't forget to null-terminate the strings.

  if (principal->realmname != NULL) {
    free(principal->realmname);
  }
      
  if ((principal->realmname = (char *) malloc (strlen(realm)+1)) == NULL) {
    // out of memory
    status.major = 9999;
    return(status);
  }
  strncpy(principal->realmname,realm,strlen(realm));
  principal->realmname[strlen(realm)] = '\0';


  if (principal->name != NULL) {
    free(principal->name);
  }

  if ((principal->name = (char *) malloc (strlen(name)+1)) == NULL) {
    // out of memory
    status.major = 9999;
    return(status);
  }
  strncpy(principal->name,name,strlen(name));
  principal->name[strlen(name)] = '\0';

  return(status);
}



