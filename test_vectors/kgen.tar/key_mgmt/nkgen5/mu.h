/**************************************************************
 *
 *  MODULE NAME:
 *
 *      @(#) mu.h
 *
 *  MODULE REVISION:
 *
 *      Version: 1.0
 *      Date: 03/10/95
 *
 *  FACILITY:
 *
 *      Wells Fargo Bank
 *         
 *
 *  ABSTRACT:
 *            define the mu record structures
 *
 *************************************************************/
/*
*
* CHANGE HISTORY:
*
* Date:        Author:     Description:
* -----        -------     ------------
* 04/30/96     G.Andrews   Initial 
*
*/

#define MAXSIZE  32768

typedef struct {
	char	rqst_id[8];
	char	status_code[2];
	char	mu_count_x[3];
	char	rqst_date[6];
	char	rqst_time[6];
	char	resp_date[6];
	char	resp_time[6];
	char	user_delimiter;
	char	client_appl_id[2];
	char	logon_id[8];
	char	luname_workstation_id[8];
	char	originator_au[4];
	char	conv_id_token[4];
	char	sync_level;
	char	issue_rqst_flag;
	char	message_length[5];
	char	response_id[8];
	char	query_time_limit[3];
	char	filler[18];
	char	security_info[74];
} muhdr;

typedef struct {
	char	rqst_id[2];
	char	rqst_type[3];
	char	rqst_sub_type[3];
	char	mu_type;
	char	msg_unit_nbr[3];
	char	decision_flag;
	char	filler[10];
	char	return_code[2];
} mucomr;


typedef struct {
        char   murq[MAXSIZE - sizeof(muhdr) - sizeof(mucomr)];
}mureq;

typedef struct {
	muhdr	header;
	mucomr	comr;
	mureq	rq;
} mu_request;

typedef struct {
        char   murs[MAXSIZE - sizeof(muhdr) - sizeof(mucomr)];
}mursp;

typedef struct {
	muhdr	header;
	mucomr	comr;
	mursp	rs;
} mu_response;

