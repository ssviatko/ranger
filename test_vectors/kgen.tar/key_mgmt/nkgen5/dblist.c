/*******************************************************************************
Copyright (c) 1996 by
Wells Fargo bank, San Francisco, California.
All rights reserved.

This software or any other copies thereof may not be provided or otherwise made 
available to any other person. No title to and ownership of the software is here
by transferred.

The information in this software is subject to change without notice and should
not be construed as a committment by Wells Fargo Bank.
	
Wells assumes no responsibility for the use or reliability of it's software.

Program :		Key distribution schedule file management module
Module  :		dblist.c
Version :		2.0
Author 	:		Sucharitha Chapparam.
Date    :		09/25/97

Changes History :
		08/15/1999      rchang       add PoweBroker support 
    09/25/97        chappas      created the file
    02/03/98        rchang       added keytab owner and group fields
*******************************************************************************/	
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "kgen.h"

extern int	debug;

static FILE    *Principalfp;
static FILE    *hostfp;

static int open_principal_db();
static int close_principal_db();
static int get_principal_info();

static int get_host_info();
static int open_hosts_db();
static int close_hosts_db();
static int get_hosts_db();

extern FILE *logfile;
extern int  ClearText;

int read_principal_DB(llPRINCIPAL **head_of_list, char *principal_db) {
  int         principal_num, ret_stat;
  llPRINCIPAL *new, *prev; 

	fprintf(logfile, "%s: Reading principal database ...\n", kgenlogt()); 
	if (open_principal_db(principal_db) != 0)
		return(1);

  principal_num = 0;
	*head_of_list = ( llPRINCIPAL *) malloc( sizeof( llPRINCIPAL ));
	new = *head_of_list;
	new->p2next = NULL;
	while (1) {
		principal_num++;
		/* get the principal  info */
		ret_stat = get_principal_info( new );
		if (ret_stat == -1) break; /* end of principal database */
		if (ret_stat != 0) { 
      /* error getting info  */
			fprintf(logfile, "ERROR: error getting principal (%d) info\n", 
												principal_num);
      /* add debug information into log file when fail 08/15/1999 */
			if ( * new->action==' ' || * new->action=='\n') * new->action='\0';
		  fprintf(logfile, "=>%c;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;\n", 
		    new->principal_type,new->realm_name,new->admin_principal_name,
			  new->principal_name, new->host_name, new->port_str, 
			  new->ktfile_path, new->ktfile_name, new->ktfile_owner,
			  new->ktfile_group, new->last_modified, 
			  new->next_modification, new->modify_freq, new->action );
      /* add debug information into log file when fail 08/15/1999 */
    }
    if ( new->principal_type == 'S' )  
       if ( read_hosts_db( new, new->host_name ) != 0 ) {
				 fprintf( logfile, "Error reading host file: %s\n",new->host_name );
				 exit( 1);
	  }
		prev = new;
		new->p2next = ( llPRINCIPAL * ) malloc( sizeof( llPRINCIPAL ));
		new = new->p2next; 
		new->p2next = NULL;
	}
	prev->p2next = NULL;
	free(new);
	if (close_principal_db() != 0)
		return(1);
	fprintf(logfile, "Finished reading principal database...\n");
	return(0);
}

int dump_principal_DB(llPRINCIPAL *head_of_list, char *dump_file_name ) {

  	llPRINCIPAL		*l_ptr;
  	FILE 			*dfp;

	fprintf(logfile, "%s: dumping the principal database to a file...\n",
										kgenlogt());
	if ((dfp = fopen( dump_file_name, "w" )) == NULL)
	{
		fprintf(logfile, "ERROR: error opening principal database file \n");
		return 1;
	}
	l_ptr = head_of_list;
	while( l_ptr != NULL )
	{
		if (l_ptr->principal_type == '#') /* comment line */
		  fprintf( dfp, "%s", l_ptr->comment_str);
		else {
			if (*l_ptr->action==' ' || *l_ptr->action=='\n') * l_ptr->action='\0';
		  if (l_ptr->principal_type == 'U' ||
					l_ptr->principal_type == 'M' || l_ptr->principal_type == 'S' ) {
		    fprintf( dfp, "%c;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;\n", 
		      l_ptr->principal_type,l_ptr->realm_name,l_ptr->admin_principal_name,
			    l_ptr->principal_name, l_ptr->host_name, l_ptr->port_str, 
		    	l_ptr->ktfile_path, l_ptr->ktfile_name, l_ptr->ktfile_owner,
		    	l_ptr->ktfile_group, l_ptr->last_modified, 
		    	l_ptr->next_modification, l_ptr->modify_freq, l_ptr->action );
		    if ( l_ptr->p3next != NULL && l_ptr->principal_type == 'S' ) {
			  	 dump_hosts_DB( l_ptr->p3next , l_ptr->host_name );
		    }
		  }
		}
		l_ptr = l_ptr->p2next;
	}
	fclose( dfp );
	return( 0 );
}

int free_principal_DB( llPRINCIPAL *head_of_list )
{
  	llPRINCIPAL	*p2next;

	if (debug) fprintf(logfile, "%s: Cleaning up the memory...\n", kgenlogt());
	while( head_of_list != NULL )
	{
		p2next = head_of_list->p2next;
    if ( head_of_list->comment_str != NULL )
       free ( head_of_list->comment_str );
	  if ( head_of_list->p3next != NULL &&  head_of_list->principal_type == 'S' )
			free_hosts_DB ( head_of_list->p3next ); 
	  /*			
	  printf("after hosts\n");
	  fflush(stdout);
		*/
		free( head_of_list );
		head_of_list = p2next;
		/*
	  printf("free head_of_list +%s+\n",head_of_list->host_name );
		*/
	}
	if (debug) printf("return from free_principal_DB\n");
	fflush(stdout);
	return( 0 );
}

static int open_principal_db(char *principal_db)
{
	if ((Principalfp = fopen(principal_db, "rw")) == NULL)
	{
		fprintf(logfile, "ERROR: error opening principal database file %s\n", 
																principal_db);
		return 1;
	}
	return 0;
}


static int close_principal_db()
{
	if (fclose(Principalfp) != 0)
	{
		fprintf(logfile, "error closing principal database file\n");
		return 1;
	}
	return 0;
}


static int get_principal_info(llPRINCIPAL *p_entry) {
	char line[sizeof(llPRINCIPAL)], *ptr;
	int i; 
	
	fgets(line, sizeof(line), Principalfp);
	if (feof(Principalfp)) return -1; /* End of file */
	if (line[0] == '#')
	{
		p_entry->principal_type = '#';
    p_entry->comment_str = ( char *) malloc( strlen(line)+2 );
		strcpy(p_entry->comment_str, line);
		return 0;
	}
  p_entry->principal_type2 = line[1];

  /* read one field at a time */

  ptr = strtok(line, ";");                     /* get principal type */
	if (ptr != NULL)
    p_entry->principal_type = ptr[0];
	else
    goto error;
 	if (!get_field( p_entry->realm_name )) return 1;
  if (!get_field(p_entry->admin_principal_name)) return 2;
  if (!get_field(p_entry->principal_name)) return 3;
  if (!get_field(p_entry->host_name)) return 4;
  if (!get_field(p_entry->port_str)) return 5;
  if (!get_field(p_entry->ktfile_path)) return 6;
  if (!get_field(p_entry->ktfile_name)) return 7;
  if (!get_field(p_entry->ktfile_owner)) return 8;
  if (!get_field(p_entry->ktfile_group)) return 9;
  if (!get_field(p_entry->last_modified)) return 10;
  if (!get_field(p_entry->next_modification)) return 11;
  if (!get_field(p_entry->modify_freq)) return 12;
  if (!get_field(p_entry->action)) return 13;
	if (*p_entry->action==' ' || *p_entry->action=='\n') * p_entry->action='\0';
	printf("---- Read action = %s\n",p_entry->action);
	p_entry->p3next = NULL;    										/* initialization */
	
	return 0;

error:
	fprintf(logfile, "Principal information is incomplete\n");
	return 1;
}

int get_field ( char * field ) {

char * ptr;

  ptr = strtok(NULL, ";");
  if (ptr != NULL) {
    strcpy(field, ptr);
    return 1;
	} else {
    return 0;
  }
}

/******* PowerBroker Support Starts here (8/15/1999) *******/

int read_hosts_db(llPRINCIPAL * pb_list, char *hosts_db) {
  int         hosts_num, ret_stat;
  HOSTNAMES *new, *prev; 

	fprintf(logfile, "%s: Reading hosts database ...\n", kgenlogt()); 
	if (open_hosts_db(hosts_db) != 0)
		return(1);
  hosts_num = 0;
	pb_list->p3next = ( HOSTNAMES *) malloc( sizeof( HOSTNAMES ));
	new = pb_list->p3next;
	new->p2next = NULL;
	while (1) {
		hosts_num++;
		ret_stat = get_host_info( new, pb_list); /* get the hosts  info */
		if (ret_stat == -1) break; /* end of hosts database */
		if (ret_stat != 0) { 
      /* error getting info  */
			fprintf(logfile, "ERROR: error getting hosts (%d) info\n", 
												hosts_num);
      /* add debug information into log file when fail 08/15/1999 */
		  fprintf(logfile, "=>%c;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;%s;\n", 
		    new->host_type,new->realm_name,new->admin_principal_name,
			  new->principal_name, new->host_name, new->port_str, 
			  new->ktfile_path, new->ktfile_name, new->ktfile_owner,
			  new->ktfile_group, new->last_modified, 
			  new->next_modification, new->modify_freq );
      /* add debug information into log file when fail 08/15/1999 */
			break;
    }
		prev = new;
		new->p2next = ( HOSTNAMES * ) malloc( sizeof( HOSTNAMES ));
		new = new->p2next; 
		new->p2next = NULL;
	}
	prev->p2next = NULL;
	free(new);
	if (close_hosts_db() != 0)
		return(1);
	fprintf(logfile, "Finished reading hosts database(%d)...\n",hosts_num);
	return(0);
}

int dump_hosts_DB(HOSTNAMES *head_of_list, char *dump_file_name ) {

 	HOSTNAMES		*l_ptr;
 	FILE 	   		*dfp;

	fprintf(logfile, "%s: dumping the hosts database to a file...\n",
										kgenlogt());
	if ((dfp = fopen( dump_file_name, "w" )) == NULL)
	{
		fprintf(logfile, "ERROR: error opening hosts database file \n");
		return 1;
	}
	l_ptr = head_of_list;
	while( l_ptr != NULL )
	{
		if (l_ptr->host_type == '#') {
			/* comment line */
		  fprintf( dfp, "%s", l_ptr->comment_str);
		} else {
		  fprintf( dfp, "%s;%s;%s;%s;%s;%s;%s;\n", 
				l_ptr->host_name, l_ptr->admin_principal_name, l_ptr->principal_name,
				l_ptr->port_str, 
			  l_ptr->last_modified, l_ptr->next_modification, l_ptr->modify_freq );
		}

	 	l_ptr = l_ptr->p2next;
	}
	fclose( dfp );
	return( 0 );
}

int free_hosts_DB( HOSTNAMES *head_of_list )
{
 	HOSTNAMES	* p2next, * node;

	fprintf(logfile, "%s: Cleaning up the hosts memory...\n", kgenlogt());
	node = head_of_list;
	while( node != NULL ) {
    if ( node->comment_str != NULL )
       free ( node->comment_str );
		/*
		printf( "Free host node:%s,adm principal:%s.\n",node->host_name,node->admin_principal_name);
		fflush(stdout);
		*/
		p2next = node->p2next;
		free( node );
		node = p2next;
	}
	printf( "return free host node\n"); 
  fflush(stdout);
	return( 0 );
}

static int open_hosts_db(char *host_db )
{
	if ((hostfp = fopen(host_db, "rw")) == NULL)
	{
		fprintf(logfile, "ERROR: opening hosts database file %s\n", host_db);
		return 1;
	}
	return 0;
}

static int close_hosts_db() {
	if (fclose(hostfp) != 0)
	{
		fprintf(logfile, "ERROR: closing hosts database file\n");
		return 1;
	}
	return 0;
}

static int get_host_info(HOSTNAMES * p_entry,llPRINCIPAL * q_entry ){
	char line[256], *ptr;
	int i;

	fgets(line,255, hostfp);
	if (feof(hostfp)) return -1; /* End of file */
	if (line[0] == '#')
	{
		p_entry->host_type = '#';
    p_entry->comment_str = ( char *) malloc( strlen(line)+2 );
		strcpy(p_entry->comment_str, line);
		p_entry->p2next=NULL;
		return 0;
	} else {
    p_entry->comment_str=NULL;
  }

  /* read one field at a time */

  p_entry->host_type = q_entry->principal_type;
  p_entry->realm_name = q_entry->realm_name;
  p_entry->ktfile_path = q_entry->ktfile_path;
  p_entry->ktfile_name = q_entry->ktfile_name;
  p_entry->ktfile_owner = q_entry->ktfile_owner;
  p_entry->ktfile_owner = q_entry->ktfile_owner;
  p_entry->ktfile_group = q_entry->ktfile_group;
	p_entry->p2next=NULL;

  /* printf( "REALM=>%s\n",q_entry->realm_name ); */

  ptr = strtok(line, ";");                     /* get principal type */
	if (ptr != NULL)
    strcpy(p_entry->host_name, ptr);
	else
    return 1;

  if (!get_field(p_entry->admin_principal_name)) return 2;
  if (!get_field(p_entry->principal_name)) return 3;
  if (!get_field(p_entry->port_str)) return 4;
  if (!get_field(p_entry->last_modified)) return 5;
  if (!get_field(p_entry->next_modification)) return 6;
  if (!get_field(p_entry->modify_freq)) return 7;

	return 0;

error:
	return 1;
}
/******* PowerBroker Support ends here (8/15/1999) *******/
