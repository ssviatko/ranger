#! /usr/contrib/bin/perl
# Author robert Chang
# date created: Fri Aug 27 15:42:14 PDT 1999
# Function: This program read the host list gotten from pongo2, 
#           modify the admin principal by reading the pbdb.dat 
#           and generate a new "host_list" file. If entry exists 
#           in the current "host_list" file, the entry will be used 
#           first, otherwise a new entry with date filled with "00"
#           will be created.
# Usage: perl host_upd.pl input_tmp_file output_file
{
open (dbptr, "pbdb.dat" ) 
   || die "Can't open pbdb.dat. Program aborts";
open (listptr, "hosts" ) 
   || die "Can't open hosts file. Program aborts";
if ( -z "list.tmp" || ! -e "list.tmp" ) {
  die "File: list.tmp does not exist or is null size. Program die"
}
open (tmpptr, "list.tmp" ) || die "can't open ".$ARGV[1].", program aborts";
open (outptr, ">"."list" );


#############################################
# Build up table of admin principal
#############################################
while (<dbptr>) {
   ($host,$adm )=split(/,/,$_);
   $admtbl { $host } = $adm;
}

#############################################
# Build up table from existing hosts file 
#############################################
while (<listptr>) {
   ($host,$adm,$principal,$port,$lastupd,$nextupd,$freq )=split(/;/,$_);
   $hosttable { $host } = $_;
   # print $host,"\n" ;
}

#############################################
# Now generate the new table for pbkgen
#############################################

$lastupd="00/00/1900,00:00:00";
$nextupd="00/00/1900,00:00:00";
$freq="90:00:00;\n";
while (<tmpptr>) {
    chop;
    ($host,$port)=split(/,/,$_);
    if ( $hosttable{$host} ne "" ) {
       $line = $hosttable{$host},"\n";
    }  else {
       if ( $admtbl{$host} ne "" ) {
         $admin = $admtbl{$host};
       } else {
         $admin = "pbinit";
       }
       $line=join(";",$host,$admin,pbadmin,$port,$lastupd,$nextupd,$freq);
    }
    print outptr $line;
}

close(dbptr);
close(tmpptr);
close(listptr);
close(outptr);
}
