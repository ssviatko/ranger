/*

    Copyright (c) 1995 by
    Wells Fargo Bank, San Francisco, California.
    All rights reserved.

    This software or any  other  copies  thereof  may  not  be  provided  or
    otherwise made available to any other person.  No title to and ownership
    of the software is hereby transferred.

    The information in this software is subject to change without notice and
    should not be construed as a commitment by Wells Fargo Bank.

    Wells assumes no responsibility  for  the  use  or  reliability  of  its
    software.


    Program:		MU communications.
    Module:		mucom.h -- interface definitions.
    Version:		inc/mucom.h, mucom, mucom_2.0, D970512a 1.9 05/12/97
    Author:		Keith M. Knowles.
    Date:		95/07/26


    Changes:

    97/05/12 adf	Add kerberos support.
    97/03/25 adf	New version mucom_audit_info_v2().
    97/01/31 adf	Add new prototypes.
    96/12/16 adf	Add mucom_shutdown and mucom_set_stream.
    95/10/20 kmk	Change wapi_send to mucom_xmit.
    95/08/16 kmk	Change audit_info to return error text.
    95/08/03 kmk	Declare a wapi_send jacket for upward compatibility.
    95/07/26 kmk	Rewrite from WAPI (Jim Esparza, HP).


    Notes:



    Description:

    Interface functional prototypes for mucom.  Also  defines  mucom  status
    codes (via mucomerr.h).

    Mucom is a package to implement TCP communications  with  a  remote  TCP
    listener.  A communication cycle is a simple sequence of: connect to the
    remote listener's port, send a request message, receive a reply message.
    The connection is dropped at the end of this sequence.

    Mucom has one main entry point, mucom_send, to  handle  a  request/reply
    transaction.  Two other entries are  implemented:  mucom_audit_info  and
    mucom_setup.

    Mucom_setup is used to establish the remote host and  port  and  to  set
    the timeout value to use for  each  complete  transaction.   Mucom_setup
    must be called before mucom_send.

    Mucom_audit is used to provide audit information to the method event log
    after an error has occurred.

*/

#ifndef	_mucom_h
#define	_mucom_h

#ifdef __cplusplus
extern "C" {
#endif

#include "mucomerr.h"

/* Size of mucom request/reply buffer */
#define MU_MSGLEN	32768

/* Size of error text buffer.
 * NOTE: same as ACAS_MAX_STRING_LENGTH for glue max string size.
 */
#define MU_ERRLEN	512

/* maximum length of a fully qualified domain name for a principal */
#define MUCOM_MAX_FQDN          256

/* maximum length of a path name */
#define MUCOM_MAX_PATH          512

/* default 'client acquire' program - to obtain TGT for method server */
#define MUCOM_TGT_PATH		"kinit"

/* default requested lifetime of TGT in hours */
#define MUCOM_TGT_LIFETIME	"24"

#define	Send_packet_size	2048
#define	Recv_packet_size	4096
#define Protocol                "tcp"
#define	Ticks_per_second	20	/* determines idle frequency */

#define KRB					1
#define CLR					2
#define PKI					3
#define DES					4

typedef enum { False = 0, True } Boolean;


/* kerberos info structure */
typedef struct _KerbInfo {
  /* service key table (keytab) file */
  char                  keytab[MUCOM_MAX_PATH];

  /* fully qualified domain name for client principal */
  char                  client_principal[MUCOM_MAX_FQDN];

  /* fully qualified domain name for server principal */
  char                  server_principal[MUCOM_MAX_FQDN];

  /* credentials cache file for this method server (for putenv) */
  char			ccfile[MUCOM_MAX_PATH];

  /* requested lifetime of TGT (ticket granting ticket) in hours */
  char 			tgt_lifetime[4];

} KerbInfo;

/* MU extention header format */
typedef struct _MUExtnHdr {
	char  msg_type[4];		/* message type-- clear(CLR ) or Kerberos(KRB ) */
	char  tot_msg_len[5];	/* total message length */
	char  tok_err_len[5];	/* token(request) or error(response) msg length */
	char  krb_prn_name[64];	/* MVS principal name
							   (ex: host/SFWK@WELLSFARGO.COM) */
	char  filler[64];		/* for future use */
} MUExtnHdr;

#define MUExtnSz  sizeof(MUExtnHdr)

/* Error format */
typedef struct _MUExtnErr {
	char  err_type[4];		/* error type-- 0001(Kerberos Error )or 
											0002(transport error)or 
											0003 (miscellanoeus error) */
	char  krb_maj_cd[8];	/* Kerberos Major code */
	char  krb_min_cd[8];	/* Kerberos Minor code */
	char  err_txt[256];		/* error text */
	char  filler[128];		/* for future use */
} MUExtnErr;

#define MUErrSz  sizeof(MUExtnErr)
/*  Setup establishes the host and port of the remote TCP listener. */
int
mucom_setup(
  char *	host,
  char *	service,
  int		timer, KerbInfo *);

/*  Send connects to the remote listener, transmits a message and waits  for
    a reply.  A request buffer and length is passed in, along with  a  reply
    buffer and a pointer to an integer that passes the reply buffer size  in
    to mucom_send and is updated by mucom_send to give the actual length  of
    the message received.
*/
int
mucom_send(
  char *	request,		/* request buffer */
  int		reqlen,			/* request length */
  char *	reply,			/* reply buffer */
  int *		replen);		/* reply buffer size in;
					   reply length out */

/*  Audit_info returns information that the caller can provide to the method
    event log after a mucom error has occurred.   The  host,  IP,  and  port
    number identify the remote host.  The errno is the Unix errno associated
    with some of the mucom error conditions (see mucomerr.h).
*/
extern char *
mucom_audit_info(
  char *	host,			/* hostname */
  char *	ipaddr,			/* IP address */
  int *		port,			/* port number */
  int *		errorno,		/* last error encountered */
  char *	errtext);		/* error text */

extern char *
mucom_audit_info_v2(
  char *	host,			/* hostname */
  char *	ipaddr,			/* IP address */
  int *		port,			/* port number */
  int *		errorno,		/* last error encountered */
  char *	errtext,		/* error text */
  char *	connection);		/* connection name */

/*  Mucom_xmit is a jacket to mucom_send.  It conforms to the Glue  "escape"
    call signature.  The jacket is necessary in order to transform the  args
    into the signature employed  by  mucom_send  (which  is  a  little  more
    expressive in that the size of the reply buffer can be passed).
*/
extern int
mucom_xmit(
  char *	message,		/* unnecessary here */
  int		req_len,		/* request length */
  char *	request,		/* request message */
  char *	reply);			/* reply buffer */


/* Mucom_set_stream sets a flag to configure mucom to use a single socket
   for all subsequent communication with the mainframe ie. it no longer
   uses a separate socket for every request.
*/
extern int
mucom_set_stream(
  char *	flag 			/* "Y" or "N" */
);

/* Mucom_shutdown MUST be called for servers which called mucom_set_stream().
   It ensures that the streaming socket is shutdown.
*/
extern int
mucom_shutdown(
  void
);

/*  Set the current connection.
*/
int
mucom_set_connect (
  char *        name
);

/*  Setup global timeout.
*/
void
mucom_setup_timeout (
  int		timer
);

/*  Setup a new connection.
*/
int
mucom_setup_connect (
  char *        name,
  char *        host,
  char *        service,
  char *	principal,
  char *	streaming);

/* Setup kerberos.
*/
int
mucom_setup_kerberos (
  char *	keytab,
  char *	principal,
  char *	cache,
  char *        tgt_path,
  char *        tgt_lifetime,   /* hours */
  char *	errortext
);

#ifdef __cplusplus
}
#endif

#endif
