/*******************************************************************************
Copyright (c) 1996 by
Wells Fargo bank, San Francisco, California.
All rights reserved.

This software or any other copies thereof may not be provided or otherwise made 
available to any other person. No title to and ownership of the software is here
by transferred.

The information in this software is subject to change without notice and should
not be construed as a committment by Wells Fargo Bank.
  
Wells assumes no responsibility for the use or reliability of it's software.

Program :    Key generation and distribution module
Module  :    kgen.c
Version :    2.0
Author   :    Sucharitha Chapparam.
Date    :    09/23/97

Changes History :
  08/15/1999         rchang          Powerbroker support
  06/04/1998         wujinn          Y2K changes
   01/30/1998         rchang         added MVS key management
  09/23/1997         chappas        created the file

*******************************************************************************/  
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <gssapi/gssapi.h>

#include "mucom.h"
#include "mu.h"
#include "common.h"
#include "kgen.h"
#include <ms2kdc.h>

#include <krb5.h>
#include <sys/time.h>

#define NEWDES3KEY           1
#define NEWDESKEY            2
#define REPEATKEY            3
#define OLDKEY               4
#define NEWDESGROUPKEY       5
#define NEWDES3GROUPKEY      6
#define ENDGROUPKEY          7
#define CRACKLE "*%#"

#define KRB5_KT_VNO_1   0x0501 /* krb v5, keytab version 1 (DCE compatible */
#define KRB5_KT_VNO   0x0502 /* krb v5, keytab version 2 (standard) */
#define KRB5_KT_DEFAULT_VNO KRB5_KT_VNO
#define DEFAULT_KEY_VERSION_NUMBER 1
#define MAX_PRINCIPALS_DEFAULT 20
#define DISCONNECT_KADMIN  disconnect_KADMIN(&theContext );\
                        ms2freePrincipalContents(&theChangingPrincipal);\
                        ms2freePrincipalContents(&theAdminPrincipal) 

#define FREE_KADMIN     ms2freePrincipalContents(&theChangingPrincipal);\
                        ms2freePrincipalContents(&theAdminPrincipal)



extern char *get_pwd(void *, const ms2_principal *);

FILE           *logfile=NULL; 
int           ClearText=0;
int           PKIFlag=0;
int           DESFlag=0;

static struct env     cur_env;
static char       logfile_name[MAX_FILE_PATH];
static char        * password = NULL;
//static char        * keytab = NULL;
//static unsigned char   buffer[KEYTAB_LEN];
//static unsigned int   bufferLen = 0;
//static time_t       NextModTmVal;
static int         MaxPrincipals, processed_principals_cnt=0;
static int        PBNEWKEY;
int gkeytype      =0;
int gerrstatus      =0;

extern char *get_pwd(void *, const ms2_principal *);
time_t convertdttm2tmval();
char *kgenlogt();
void hex2str( char * , int , char * ); 
void my_func(FILE * ,  char *, char ); 
void my_func2( FILE * ,  char * , int ) ;
int check_MU_response(mu_response * mu_resp, char * h, char * p );
char ascii_convert( char ) ;
void read_admin_principal(struct admin *thisAdmin, char * realm);
int write_key_val_to_save( char * principal, unsigned char * key_info, int keylen );
int read_key_val_from_save( char * principal, unsigned char * key_info, int * keylen ) ;

int process_principal(llPRINCIPAL *p_entry);
void disconnect_KADMIN(ms2_context *theContext);
int change_principal_key(char *principal_name,
                         char *realm_name,
                         unsigned char *principalKey,
                         unsigned int keyLength,
                         ms2_context * theContext,
                         ms2_principal * theChangingPrincipal);

int check_if_KADMIN_alive(char *, char *, ms2_context *, ms2_principal *, ms2_principal *);
void display_key(char * s, unsigned char * key, int key_len ) ;
void endianCopy(void* dest, void* src, size_t n);
int check(int rc, char *oper);

//
// prototypes from dblist.c
//
int dump_principal_DB(llPRINCIPAL *head_of_list, char *dump_file_name);
int read_principal_DB(llPRINCIPAL **head_of_list, char *principal_db);
int free_principal_DB(llPRINCIPAL *head_of_list);

//
// prototypes from pkistuffs.c
//
int gen_new_DES_key(unsigned char *key_info);
int gen_new_DES3_key(unsigned char *key_info);
int ReadFile (char *filename,
	      unsigned char *output,
	      unsigned int *outputLen,
	      unsigned int maxOutputLen);



char target;
int debug;

unsigned char pbkey[95] ;
unsigned char pvkey[350];
int pbkey_len=sizeof(pbkey);
int pvkey_len=sizeof(pvkey);
const char* snap = "muss";

/* checks whether or not given principal needs keytab refresh */
int needs_updation(llPRINCIPAL *p_entry)
{
  char     dt_tm_str[32];
  time_t    nxt_tmval, cur_tmval;
  
  strcpy(dt_tm_str, p_entry->next_modification);
  if ((nxt_tmval = convertdttm2tmval(dt_tm_str)) == -1)
    return 0;
  cur_tmval = time(&cur_tmval);

  /*check if next modification date < current date */
  if (nxt_tmval < cur_tmval)
    return 1;
  return 0;
}

/* updates next modification and last modification fields in the principal
   entry */
int update_principal_info(llPRINCIPAL *p_entry)
{
  
  char freq_str[32], *ptr;
  int i, tk_lst[3];
  struct tm *nxt_tm, *cur_tm;
  time_t nxt_tmval,freq_tmval, cur_tmval;

  strcpy(freq_str, p_entry->modify_freq);
  /* process freq_str */
  for (i=0; i<3; i++)
  {
    if (i == 0) ptr = strtok(freq_str, ":");
    else ptr = strtok(NULL, ":");
      if (ptr == NULL)
    {
      fprintf(logfile, "ERROR: frequency format(DD:HH:MM) is wrong\n");
      return 1;
    }
    tk_lst[i] = atoi(ptr);
  }
  
  freq_tmval =  (tk_lst[0]*24*3600) + (tk_lst[1]*3600) + (tk_lst[2]*60);
  /* calculate last_modified date as current date */
  time(&cur_tmval);
  cur_tm = localtime(&cur_tmval);

  /*** Y2K changes start here  ****/
  /* 
   * commenting this line -->
   * strftime(p_entry->last_modified, sizeof(p_entry->last_modified),
   *              "%x,%X", cur_tm);  
   * <-- comment ends here 
   */
  /* Y2K new code starts here */
  strftime(p_entry->last_modified, sizeof(p_entry->last_modified),
              "%m/%d/%Y,%X", cur_tm);
  /* Y2K new code ends here */
  /**** Y2K changes end here ****/

  /* calculate next_modification as last_modified+freq_time */
  nxt_tmval = cur_tmval + freq_tmval;
  nxt_tm = localtime(&nxt_tmval);
  /**** Y2K changes start here ****/
  /* commenting this line-->
   * strftime(p_entry->next_modification,
   *      sizeof(p_entry->next_modification), "%x,%X", nxt_tm); 
   */
  strftime(p_entry->next_modification, sizeof(p_entry->next_modification),
        "%m/%d/%Y,%X", nxt_tm);
  /**** Y2K changes end here ****/

  return 0;
}

int distribute_keytabs(llPRINCIPAL *pdb_list) {
  llPRINCIPAL *db_ptr;
  int      principal_num=0, ret_stat=0;
  db_ptr = pdb_list;


  printf(" start processing principals from schedule file\n");
  while (db_ptr != NULL) {
    if (processed_principals_cnt >= MaxPrincipals) {
      return -1;  
    }
    if ( ret_stat == 5 ) {
      return -1;
    }
    /* ignore principals of type other than Unix or Mvs */
    target = db_ptr->principal_type;
    if (db_ptr->principal_type != 'U' &&
        db_ptr->principal_type != 'M' &&
        db_ptr->principal_type != 'S') {
        /* not UNIX, nor MVS, nor SPECIAL(PB) */
        /* skip the entry */
        goto endwhile;;
    }
    principal_num++;
    fprintf(logfile, "\n%s: Processing principal %s...\n", kgenlogt(),db_ptr->principal_name);
    /* process the principal  */
    printf("\ncalling process_principal() on (#%d) %s.\n",principal_num,db_ptr->principal_name);
    ret_stat = process_principal(db_ptr);
    printf("processing principal (%d) rc=%d.\n", principal_num,ret_stat);
    if (ret_stat == 1) /* no processing is required for this principal*/
      goto endwhile;
    if (ret_stat == -1) /* error */ {
      printf("ERROR: distribute_keytabs() error processing principal (%d) info\n", principal_num);
      fprintf(logfile, "ERROR: distribute_keytabs() error processing principal (%d) info\n", principal_num);
      goto endwhile;
    } 
    fprintf(logfile, "%s: Finished processing principal %s\n", kgenlogt(),db_ptr->principal_name);
    /* update principal info */
    printf("%s: Updating principal information for %s\n",
                    kgenlogt(),db_ptr->principal_name);
    fprintf(logfile, "%s: Updating principal information for %s\n",
                    kgenlogt(),db_ptr->principal_name);
    if (update_principal_info(db_ptr) != 0) {
      fprintf(logfile, "ERROR: error updating principal (%d) info\n", 
                              principal_num);
      goto endwhile;
    } 
    /* dump back the principal database */
    printf( "Update scheduel file %s.\n",cur_env.principal_db);
    if (dump_principal_DB(pdb_list, cur_env.principal_db) != 0)
    {
      fprintf(logfile,"ERROR:error dumping principal DB (%d)\n",principal_num);
      return 1;
    }  
    processed_principals_cnt++;
  endwhile:    
    db_ptr = db_ptr->p2next;
    /* printf ( "end while loop of linklist \n"); */
  }
  if (debug) printf( "Leaving the while loop of princiapl link list\n");
  return 0;
}

//
// the llist_node->action only stores 10 characters.  We can't
// safely identify any character strings beyond that size.
//
//
int get_KeyType( char * action ) {

 if ( !strncmp( action,"NewDES3GroupKey",10) ||
      !strncmp( action,"NEWDES3GROUPKEY",10) ||
      !strncmp( action,"newdes3groupkey",10) 
    ) {
      return NEWDES3GROUPKEY;
    }
 if ( ! strncmp( action,"newdesgroupkey",10) || 
      ! strncmp( action,"NewDESGroupKey",10) || 
      ! strncmp( action,"NEWGROUPDESKEY",10) 
    ) {
      return NEWDESGROUPKEY;
    }
 if ( !strncmp( action, "Repeat",6) ||
      !strncmp( action, "repeat",6) || 
      !strncmp( action, "REPEAT",6) 
    ) {
      return REPEATKEY;
    }
 if ( !strncmp( action, "EndGroupKey",10) ||
      !strncmp( action, "endgroupkey",10) || 
      !strncmp( action, "ENDGROUPKEY",10) 
    ) {
      return ENDGROUPKEY;
    }
 if ( !strncmp( action,"newdes3",7) || 
      !strncmp( action,"NEWDES3",7) 
    ) { 
    return NEWDES3KEY;
    }
 if ( action == NULL || 
      ! strncmp( action,"new",3) || 
      ! strncmp( action,"NEW",3)
    ) {
      return NEWDESKEY;
    }
 return OLDKEY;
}


int write_key_val_to_save( char * principal, unsigned char * key_info, int keylen ) {
FILE * fpt;
char saveName[200];
static unsigned char tmp_keytab_contents[1024];
int n, prnlen ;
char * ptr;

  n=0;
  display_key("key_info - in write_key", key_info, keylen);  /* read back */
  prnlen=strlen(principal);
  if ( keylen < 0 || prnlen < 0 || keylen + prnlen > 1023 ) return ( -1 );
  ptr=tmp_keytab_contents;
  sprintf(saveName, "%s/%s.krb", cur_env.exe_path,cur_env.principal_db);
  printf("Write key val to save : %s\n",saveName );
  *ptr++=keylen;
  memcpy(ptr,key_info, keylen );
  memcpy(ptr+keylen,principal,prnlen);
  if ( ( fpt = fopen(saveName,"wb") ) != NULL ) {
    display_key("write_values",tmp_keytab_contents,prnlen+12);
    if ( (n = fwrite(tmp_keytab_contents, 1024, sizeof(char), fpt)) < 1 ) {
      printf("Error writing when saving group key.(%s).\n",saveName);
    }
    fclose(fpt);
  } else {
    printf("Error opening saved key : %s\n",saveName);
  }
  return n;
}


int read_key_val_from_save( char * principal, unsigned char * key_info, int * keylen ) {
FILE * fpt;
char saveName[200];
static unsigned char tmp_keytab_contents[1024];
int n;
char * ptr;

  n=0;
  * keylen=0;
  sprintf(saveName, "%s/%s.krb", cur_env.exe_path,cur_env.principal_db);
  if ( ( fpt = fopen(saveName,"rb") ) != NULL ) {
    if ( (n = fread(tmp_keytab_contents, 1024, sizeof(char), fpt)) < 1 ) {
      printf("Error reading saved group key..\n");
    } else {
      display_key("read_val", tmp_keytab_contents,*tmp_keytab_contents+10);  /* read back */
      * keylen = * tmp_keytab_contents;  /* get key length */
      printf( "keylen=%d in read_val.\n",*keylen );
      ptr = tmp_keytab_contents+*keylen+1; /* move point to principal name */
      if ( !strncmp(ptr,principal,*keylen) ) {
        memcpy(key_info, tmp_keytab_contents+1,*keylen );
        display_key("key_info - in read_key ", key_info,* keylen);  /* read back */
      } else {
        printf( "Saved key's principal name mis-match %s %s\n",principal,ptr);
      }
    }
    fclose(fpt);
  } else {
    printf("Error opening saved key : %s\n",saveName);
  }
  return n;
}

int unlink_key_save( void ) {
char saveName[200];

  sprintf(saveName, "%s/%s.krb", cur_env.exe_path,cur_env.principal_db);
  unlink(saveName);
  return(1);
}

int needs_newkey( HOSTNAMES * p_entry ) {
  char     dt_tm_str[32];
  time_t  nxt_tmval, cur_tmval;

  if ( p_entry->host_type == '#' ) return 0;
  if ( strcmp(p_entry->port_str,"-1") == 0 ) return 0;
  strcpy(dt_tm_str, p_entry->next_modification);
  if ((nxt_tmval = convertdttm2tmval(dt_tm_str)) == -1)
    return 0;
  cur_tmval = time(&cur_tmval);

  /*check if next modification date < current date */
  if (nxt_tmval < cur_tmval)
    return 1;
  return 0;
}

/* sets up MUCOM with Kerberos and sends the keytab update MU to the peer */
int send_krb_mu(llPRINCIPAL *p_entry, char *mu_str,int mu_str_len,char *mu_resp)
{
  int   outlen=MAXSIZE;
  KerbInfo kerb_info;

  fprintf(logfile, "%s: Setup MUCOM HostName=%s, Port=%s, updateing:%s\n",
          kgenlogt(),p_entry->host_name,p_entry->port_str, 
          p_entry->principal_name);
  
  /* kerberos info structure */
  strcpy(kerb_info.keytab, cur_env.kt_filename);

  /* fully qualified domain name for client principal */
  strcpy(kerb_info.client_principal, cur_env.krb5_principal_name);
  strcat(kerb_info.client_principal, "@");
  strcat(kerb_info.client_principal, p_entry->realm_name);

  /* fully qualified domain name for server principal */
  strcpy(kerb_info.server_principal, p_entry->admin_principal_name);
  strcat(kerb_info.server_principal, "@");
  strcat(kerb_info.server_principal, p_entry->realm_name);

  /* credentials cache file for this method server (for putenv) */
  strcpy(kerb_info.ccfile, cur_env.krb5_ccname);

  /* requested lifetime of TGT (ticket granting ticket) in hours */
  strcpy(kerb_info.tgt_lifetime, "24h");


  fprintf( logfile, "mucom_setup:\n");
  fprintf( logfile,"Host:%s\nPort:%s\nClient:%s\nServer:%s\n",
           p_entry->host_name, p_entry->port_str, 
           kerb_info.client_principal, kerb_info.server_principal);
  if ( p_entry->principal_type2 == 'C' ) {
     ClearText = 1;
     printf( "ClearText\n");
     if (check(mucom_setup(p_entry->host_name, p_entry->port_str, 300, 
                NULL), "setup") != 0) 
      return 1;
  } else {
     ClearText = 0;
     printf("before mucom_setup\n"); fflush(stdout);
     if (check(mucom_setup(p_entry->host_name, p_entry->port_str, 300, 
                &kerb_info), "setup") != 0) 
      return 1;
  }
  printf("after mucom_setup\n"); fflush(stdout);

  fprintf(logfile, "MU request: \n");
  my_func(logfile,  mu_str , 'c' ); 
  fprintf(logfile, "%s: Sending request\n", kgenlogt());
  if (check(mucom_send(mu_str, mu_str_len, mu_resp, &outlen),"send") != 0){
    /* try sending again */
    printf("===================trying mucom_send again =================\n");
    fprintf(logfile, "trying mucom_send again \n");
    outlen = MAXSIZE;
    if (check(mucom_send(mu_str, mu_str_len, mu_resp, &outlen),"send") 
                                    != 0)
    printf("===================2nd try failed =================\n");
      return 3;
  }
  my_func(logfile,  mu_resp , 'c' ); 
  return 0;
}

/* this function converts value into a string of our_str_len length 
   ex: val=64, out_str_len=4 -> str = "0064" */

int convertval2str(int val, char *str, int out_str_len)
{
  int rem,i;

  memset(str, '0', out_str_len);
  for (i=out_str_len-1; i>=0; i--)
  {
    rem = val % 10;
    str[i] = rem+'0';
    val = val/10;
    if (val == 0) break;
  }
  return(-1);
}

int getkeylen( unsigned char * key_info ) {

    if ( key_info[DESKEYLEN] == 0 ) {
      /* printf("keylen=%d\n",DESKEYLEN); */
      return (DESKEYLEN);
    }
    else {
      /* printf("keylen=%d\n",DESKEYLEN*3); */
      return ( DESKEYLEN * 3);
    }
}

/************************************************
 *            *
 *  get_keytab_contents():
 *
 *  Input key_info/
 *  Input principal info
 * 
 *  Return keytab_contents, and keytab_sz
 *
 *            *
 ***********************************************/

int 
get_keytab_contents (char *principal_info, unsigned char *key_info, 
		     unsigned char *keytab_contents, int *keytab_sz, int kvno)
{
  krb5_keytab_entry theKeytabEntry;
  krb5_principal p;
  krb5_int32 recordLength = 0;
  krb5_int16 keytabVersionNumber =  KRB5_KT_DEFAULT_VNO;
  krb5_int16 data_int16;
  char principal_fqdn[64];
  int component,kt_sz=0;

  struct timeval timeNow;
  struct timezone tz;

  int len, i, index;

  p = (krb5_principal)malloc(sizeof(krb5_principal_data));
  if (p == NULL)
    {
      fprintf(logfile, "\nget_keytab_contents: could not allocate memory\n");
      return -1;
    }
  strcpy(principal_fqdn,principal_info);  /* fullqulified domain name */
  /***
   ***
   *** Parse FQDN to principal and realm names.  The last '@' in the FQDN is the 
   *** delimiter between principal and realm names.
   ***
   ***/
  index = strlen(principal_fqdn) - 1;
  for (i = index; i >=0; i--)
    {
      if (principal_fqdn[i] == '@')
	{
	  p->realm.length = index - i;
	  break;
	}
    }

  if (p->realm.length == 0)
    {
      fprintf(logfile,"\nget_keytab_contents:FQDN is malformed - No realm\n");
      fprintf(logfile,"\nget_keytab_contents:%s\n",principal_info);
      return -1;
    }

  if (i <= 0)
    {
      fprintf(logfile, "\nget_keytab_contents: FQDN is malformed - No principal\n");
      return -1;
    }

  /***
   ***
   *** copy realm data
   ***
   ***/
  
  p->realm.data = malloc(p->realm.length);
  memcpy(p->realm.data,principal_fqdn+i+1,  p->realm.length);

  /***
   ***
   *** Now parse principal name.  Principal names can be of the form "principal/instance" or just "principal"
   ***
   ***/
  index = i - 1;
  p->length = 1;  /* assuem one field on the principal name */

  for (i = index; i >=0; i--)
    {
      if (principal_fqdn[i] == '/')
	{
	  p->length = 2; /* two fields principal name ie has a / in the principal name field */
	  break;
	}
    }
  
  
  p->data = (krb5_data *)malloc(p->length * sizeof(krb5_data));
  if (p->data == NULL)
    {
      fprintf(logfile, "\nget_keytab_contents: could not allocate memory\n");
      return -1;
    }

  
  if ( i < 0 ) i = index + 1;
  
  for (len = 0 , component = 0; len < p->length; len++)
    {
      (p->data+len)->length = i;
      (p->data+len)->data = malloc(i);
      if ((p->data+len)->data == NULL)
	{
	  fprintf(logfile, "\nget_keytab_contents: could not allocate memory\n");
	  return -1;
	}
      memcpy((p->data+len)->data, principal_fqdn + component,i);
      component = i+1;
      i = index - i;
    }
    
  /* key version */
  
  /* the key block */
  theKeytabEntry.vno = kvno;
  if ( getkeylen(key_info) == 24 ) {
    //theKeytabEntry.vno = DEFAULT_KEY_VERSION_NUMBER + 1;
    theKeytabEntry.key.enctype = ENCTYPE_DES3_CBC_MD5;
  } else {
    // theKeytabEntry.vno = DEFAULT_KEY_VERSION_NUMBER;
    theKeytabEntry.key.enctype = ENCTYPE_DES_CBC_MD5;
  }
  theKeytabEntry.key.length = getkeylen(key_info);
  theKeytabEntry.key.contents = (unsigned char *)malloc(getkeylen(key_info));
  if (theKeytabEntry.key.contents == NULL)
    {
      fprintf(logfile, "\nget_keytab_contents: could not allocate memory\n");
      return -1;
    }
  
  memcpy(theKeytabEntry.key.contents, key_info, getkeylen(key_info));
  

  /***
   ***
   *** time stamp
   ***
   ***/ 
  gettimeofday (&timeNow, &tz);
  
  theKeytabEntry.timestamp = timeNow.tv_sec;
  
  /* the principal type */
  p->type = KRB5_NT_SRV_HST;
  
  /* compute record length */
  recordLength = sizeof(krb5_int16) + /* number of principal entries */
    sizeof(krb5_int16) + /* size of length of realm */
    p->realm.length    +
    sizeof(krb5_int16)* p->length +
    sizeof(krb5_int32)*2 + /* principal type and timestamp */
    sizeof(p->type) + 
    sizeof(krb5_kvno) +
    ((-1 * sizeof(theKeytabEntry.vno)) + sizeof(krb5_octet)) + // kvno is a single byte
    ((-1 * sizeof(theKeytabEntry.key.enctype)) + sizeof(krb5_int16)) + // enctype is a signed-16
    getkeylen(key_info);
  
  for (i = 0; i < p->length; i++)
    {
      recordLength = recordLength + (p->data+i)->length;
    }
    
  endianCopy(keytab_contents, &keytabVersionNumber, sizeof(krb5_int16));      
  kt_sz += sizeof(krb5_int16);
  endianCopy(keytab_contents+kt_sz,&recordLength,sizeof(krb5_int32));      
  kt_sz += sizeof(krb5_int32);
  data_int16 = p->length;
  endianCopy(keytab_contents+kt_sz, &data_int16, sizeof(krb5_int16));      
  kt_sz += sizeof(krb5_int16);
  data_int16 = p->realm.length;
  endianCopy(keytab_contents+kt_sz, &data_int16, sizeof(krb5_int16));      
  kt_sz += sizeof(krb5_int16);
  memcpy(keytab_contents+kt_sz, p->realm.data, p->realm.length);      
  kt_sz += p->realm.length;
  for (i = 0; i< p->length; i++)
    {
      data_int16 = (p->data+i)->length;
      endianCopy(keytab_contents+kt_sz,&data_int16,sizeof(krb5_int16));
      kt_sz += sizeof(krb5_int16);
      memcpy(keytab_contents+kt_sz,(p->data+i)->data,data_int16);
      kt_sz += data_int16;
    }
  endianCopy(keytab_contents+kt_sz,&(p->type),sizeof(p->type));
  kt_sz += sizeof(p->type);
  endianCopy(keytab_contents+kt_sz,&(theKeytabEntry.timestamp),
	     sizeof(theKeytabEntry.timestamp));
  kt_sz += sizeof(theKeytabEntry.timestamp);


  // in MIT, key version number is stored in the keytab as a single byte.
  krb5_octet keyVersionNumber = (krb5_octet)theKeytabEntry.vno;
  endianCopy(keytab_contents+kt_sz,&(keyVersionNumber),sizeof(krb5_octet));
  kt_sz += sizeof(krb5_octet);
  //memcpy(keytab_contents+kt_sz,&(theKeytabEntry.vno),sizeof(krb5_kvno));
  //kt_sz += sizeof(krb5_kvno);

  // in MIT, enctype is stored in the keytab as a signed-16
  data_int16 = theKeytabEntry.key.enctype;
  endianCopy(keytab_contents+kt_sz,&data_int16,sizeof(data_int16));
  kt_sz += sizeof(data_int16);
  //memcpy(keytab_contents+kt_sz,&(theKeytabEntry.key.keytype),
  //sizeof(theKeytabEntry.key.keytype));
  //kt_sz += sizeof(theKeytabEntry.key.keytype);

  data_int16 = theKeytabEntry.key.length;
  endianCopy(keytab_contents+kt_sz, &data_int16,sizeof(data_int16));
  kt_sz += sizeof(data_int16);
  memcpy(keytab_contents+kt_sz,theKeytabEntry.key.contents,
	 theKeytabEntry.key.length);
  kt_sz += theKeytabEntry.key.length;
  *keytab_sz = kt_sz;
  /* clean up the memory */
  if (theKeytabEntry.key.contents != NULL) 
    free(theKeytabEntry.key.contents);
  for (len = 0 ; len < p->length; len++)
    free((p->data+len)->data);
  free(p->data);
  free(p->realm.data);
  free(p);
  return 0;
}


/**
 * running Linux on an x86 architecture means that data is written
 * as little-endian, not big-endian.  We only support 16-bit and 32-bit
 * variables in this function.
 *
 * Character strings don't have to be handled by this function
 * because they are already defined as an array of individual
 * bytes.
 */
void endianCopy(void* dest, void* src, size_t n)
{
  // depending on the size of the copy, reverse the endian-ness
  // of certain items.
  char* csrc = src;

  unsigned char srcBuffer[4];
  unsigned char *pSrcBuffer = srcBuffer;

  switch(n) {
  case 2:
    // on a two-byte copy, reverse the bytes.  The pattern AB becomes BA.
    srcBuffer[0] = csrc[1];
    srcBuffer[1] = csrc[0];
    memcpy(dest, pSrcBuffer, n);
    break;

  case 4:
    // on a four-byte copy, reverse the whole set.  The pattern ABCD becomes DCBA.
    srcBuffer[0] = csrc[3];
    srcBuffer[1] = csrc[2];
    srcBuffer[2] = csrc[1];
    srcBuffer[3] = csrc[0];
    memcpy(dest, pSrcBuffer, n);
    break;

  default:
    memcpy(dest, src, n);
    break;
  }
}




int read_key ( FILE * logfile, unsigned char * buf,int * keylen, char * ktfile_name  ) {
char str[256];
FILE * tmpfp;

  sprintf(str, "../k/%s", ktfile_name);
  fprintf( logfile, "Reading keytab file %s\n",str );
  if ((tmpfp = fopen(str, "rb")) == NULL)
  {
    fprintf(logfile, "\n ERROR: Opening saved key file: %s\n", str);
    return 0;
  }
  if ( (*keylen=fread(buf, sizeof(char), 500, tmpfp)) < 1)
  {
    fprintf(logfile, "\n ERROR: Reading key file: %s\n", str);
    return 0;
  }
  printf("reading key %d\n",* keylen );
  fclose(tmpfp);
  return 1;
}


/* converts keytab file to MVS format and then to ascii text */
int get_MVS_keytab(char *keytab_contents, int keytab_sz, 
        char *MVS_keytab_contents, int MVS_keytab_sz)
{
  //
  // The MVS keytab is exactly 1024 bytes in length and (in
  // practice) contains a single key.  It is generated from
  // normal MIT-produced keytab with the following changes:
  //   - the first 6 bytes (keytab version and keytab size)
  //     are excluded.
  //   - the rest of the MIT keytab is copied byte-for-byte.
  //   - the file is padded with 0x00's until a size of
  //     1024 is reached.
  //
  fprintf(logfile, "\n%sConverting keytab to MVS format\n",kgenlogt());
  char tmp_MVS_keytab_contents[KEYTAB_LEN];

#ifdef USE_KTXLATE
  //
  // this body of code should be used if we intend to use
  // the ktxlate.hp executable
  //
  FILE *tmpfp;
  char str[100];
  int  n;

  /* write the keytab contents to a temporary file */
  sprintf(str, "%s/tmp.krb", cur_env.exe_path);
  if ((tmpfp = fopen(str, "wb")) == NULL)
  {
    fprintf(logfile, "\n ERROR: error creating temporary file: %s\n",
                                str);
    return 1;
  }
  if (fwrite(keytab_contents, keytab_sz, 1, tmpfp) < 1)
  {
    fprintf(logfile, "\n ERROR: error writing to temporary file: %s\n",
                                str);
    return 1;
  }
  fclose(tmpfp);
  /* call ktxlate to xlate the keytab file to MVS format */
  sprintf(str, "%s/ktxlate.hp FILE:%s/tmp.krb XFILE:%s/tmp.mvs > /dev/null",
            cur_env.exe_path, cur_env.exe_path, cur_env.exe_path);
  if (system(str) != 0)
  {
    fprintf(logfile, "\n ERROR: error invoking ktxlate\n");
    return 1;
  }
  /* read the MVS format of keytab file from the temporary file */
  sprintf(str, "%s/tmp.mvs", cur_env.exe_path);
  if ((tmpfp = fopen(str, "rb")) == NULL)
  {
    fprintf(logfile, "\n ERROR: error opening temporary file: %s\n",
                                "./tmp.mvs");
    return 1;
  }
  if ( (n = fread(tmp_MVS_keytab_contents, 1024, sizeof(char), tmpfp)) < 1)
  {
    fprintf(logfile, "\n ERROR: error reading %s\n", "./tmp.mvs");
    return 1;
  }
  fclose(tmpfp);
  /* fprintf(stderr,"%d bytes read from tmp.mvs\n",n); */
  /* remove the temporary files */
  sprintf(str, "%s/tmp.krb", cur_env.exe_path);
  remove( str );     
  sprintf(str, "%s/tmp.mvs", cur_env.exe_path);
  remove( str );

#else

  if (keytab_sz <= 6) {
    // bad keytab
  } else {
    //
    // initialize tmp_MVS_keytab_contents to all 0x00's.
    //
    char* pTmp_MVS_keytab_contents = &tmp_MVS_keytab_contents[0];
    memset(pTmp_MVS_keytab_contents,0x00,KEYTAB_LEN);
    //
    // copy the keytab contents, offset by 6 bytes.
    //
    memcpy(pTmp_MVS_keytab_contents,
	   (char *)keytab_contents + 6 * sizeof(char),
	   keytab_sz-6);
  }

#endif 

  /* convert ascii hex to text string    */
  /* example: 0x23 --> 0x32 0x33         */
  /* my_func( stderr, tmp_MVS_keytab_contents, 'x' ); */
  hex2str(tmp_MVS_keytab_contents, KEYTAB_LEN, MVS_keytab_contents); 
  return (0);
}

/* formats the keytab update MU as per standards */
int format_mu(llPRINCIPAL *p_entry, unsigned char *key_info,int key_len,
              char *mu_req, int *mu_req_sz, int kvno) {
  int     mu_data_sz, keytab_sz;
  char     len_str[5], timebuf[10];
  unsigned char  keytab_contents[KEYTAB_LEN];
  char    principal_info[256];
  time_t     timevar;
  char      MVS_keytab_contents[MVS_KEYTAB_LEN+1];
  struct tm   ltm;
  int         principal_len, realm_len;

  /* get the keytab file contents */
  strcpy(principal_info, p_entry->principal_name);
  strcat(principal_info, "@");
  strcat(principal_info, p_entry->realm_name);
  mu_data_sz = strlen(p_entry->principal_name) + strlen(p_entry->realm_name)+
         + 1; 
  principal_info[mu_data_sz] = '\0';
  get_keytab_contents(principal_info, key_info, keytab_contents, &keytab_sz,kvno);

  memset(mu_req, ' ', MAXSIZE);  
  /* mu header */
  if (p_entry->principal_type == 'U')  {
    memcpy(mu_req, "DKK99999", 8);
  } else {
    /* rc 09/12/1999 memcpy(mu_req, "DKK99999", 8); */
    memcpy(mu_req, p_entry->ktfile_owner, 8); 
  }
  memcpy(mu_req+8, "00", 2);
  memcpy(mu_req+10, "001", 3);
  /* request date and time */
    time(&timevar);
    ltm = *localtime(&timevar);
    sprintf(timebuf, "%02d%02d%02d", ltm.tm_mon+1, ltm.tm_mday, ltm.tm_year);
    strncpy(mu_req+13, timebuf, 6 );
    sprintf(timebuf, "%02d%02d%02d", ltm.tm_hour, ltm.tm_min, ltm.tm_sec );
    strncpy(mu_req+19, timebuf, 6 );
  memcpy(mu_req+25, "000000", 6);
  memcpy(mu_req+31, "000000", 6);
  memcpy(mu_req+37, "^", 1);
  if (p_entry->principal_type == 'U')  {
    memcpy(mu_req+38, "DK", 2);
    memcpy(mu_req+40, "DKMUSS  ", 8);
  } else {
    /* rc 09/12/1999 memcpy(mu_req+38, "DK", 2); */
    memcpy(mu_req+38, p_entry->ktfile_path, 2);
    /* rc 09/12/1999 memcpy(mu_req+40, "DKMUSS  ", 8); */
    /* logon id change                                */
    memcpy(mu_req+40, p_entry->ktfile_name, 8);
  }
  memcpy(mu_req+48, "        ", 8);
  memcpy(mu_req+56, "1046", 4);
  memcpy(mu_req+60, "    ", 4);
  memcpy(mu_req+64, "0", 1);
  memcpy(mu_req+65, "0", 1);
  memcpy(mu_req+79, "000", 3);
  /* create security stuffs */
  if (p_entry->principal_type == 'M')  {
    memcpy(mu_req+100, "00", 2); 
    /* rc 09/12/99 memcpy(mu_req+118, "DKMUSS  ", 8); */
    /* logon id change                                */
    memcpy(mu_req+118, p_entry->ktfile_name,8);
  }

  /* comr */
  if (p_entry->principal_type == 'U')  {
    memcpy(mu_req+174, "DKKEYUPD", 8);
  } else {
    /* rc 09/12/99 memcpy(mu_req+174, "DKKEYUPD", 8); */
    /* which function to take care of the MU */
    /* update/delete etc                     */
    memcpy(mu_req+174, p_entry->ktfile_group, 8); 
  }
  memcpy(mu_req+182, "0", 1);
  memcpy(mu_req+183, "001", 3);
  
  /* copy actual mu data */
  if (p_entry->principal_type == 'U')           /* if unix plat form */
  {
    /* principal name */
    memcpy(mu_req+199, p_entry->principal_name, 
                strlen(p_entry->principal_name));
    memcpy(mu_req+199+strlen(p_entry->principal_name), "@", 1);  
    /* realm_name */
    memcpy(mu_req+200+strlen(p_entry->principal_name), p_entry->realm_name, 
                    strlen(p_entry->realm_name));
        /* keytab file name */
    memcpy(mu_req+263, p_entry->ktfile_name, strlen(p_entry->ktfile_name));
    /* keytab file path */
    memcpy(mu_req+295, p_entry->ktfile_path,strlen(p_entry->ktfile_path));
    /* convert keytab size to str */
    /* rc 12/23/97 ---- modification starts here */
    memcpy(mu_req+327, p_entry->ktfile_owner,strlen(p_entry->ktfile_owner));
    memcpy(mu_req+359, p_entry->ktfile_group,strlen(p_entry->ktfile_group));
    /* rc 12/23/97 ---- modification ends here */
    convertval2str(keytab_sz, len_str,4);
    memcpy(mu_req+455, len_str, 4);
    memcpy(mu_req+459, keytab_contents, keytab_sz);
    memcpy(mu_req+459+keytab_sz, "^", 1);
    memcpy(mu_req+459+keytab_sz+1, "\0", 1); 
    *mu_req_sz = 459+keytab_sz+1;
    /* convert message_length to str msg_len = muhdr+comr+data */
    convertval2str(459+keytab_sz+1, len_str, 5);
    memcpy(mu_req+66, len_str, 5); 
  }
  else if (p_entry->principal_type == 'M')
    {
      /* principal name */
      principal_len = strlen( p_entry->principal_name);
      realm_len = strlen( p_entry->realm_name );
      memcpy(mu_req+199, p_entry->principal_name,principal_len); 
      memcpy(mu_req+199+principal_len,"@",1);
      memcpy(mu_req+199+principal_len+1,p_entry->realm_name,realm_len);
      /* keytab file name */
      memcpy(mu_req+263, p_entry->ktfile_name, strlen(p_entry->ktfile_name));

      /* keytab file path */
      memcpy(mu_req+295, p_entry->ktfile_path,strlen(p_entry->ktfile_path));

      /* Robert Chang to add action code here Thu May 13 13:49:31 PDT 2004 */
      if ( ! strncmp( p_entry->action,"del-d",5) || ! strncmp(p_entry->action,"DEL-D",5) ) {
	memcpy(mu_req+327, "D",1);
      }
      if ( ! strncmp( p_entry->action,"del-s",5) || ! strncmp(p_entry->action,"DEL-S",5) ) {
	memcpy(mu_req+327, "S",1);
      }

      /* convert message_length to str msg_len = muhdr+comr+data */
      convertval2str(MVS_KEYTAB_LEN, len_str, 4);
      memcpy(mu_req+455, len_str, 4);
      if (get_MVS_keytab(keytab_contents, keytab_sz, 
			 MVS_keytab_contents, KEYTAB_LEN) != 0)
	{
	  fprintf(logfile,"\nERROR:error converting keytab to MVS format\n");
	  return 1;
	}

      memcpy(mu_req+459, MVS_keytab_contents, MVS_KEYTAB_LEN);
      memcpy(mu_req+459+MVS_KEYTAB_LEN, "^", 1);
      memcpy(mu_req+459+MVS_KEYTAB_LEN+1, "\0", 1); 
      *mu_req_sz = 459+MVS_KEYTAB_LEN+1;
      /* convert message_length to str msg_len = muhdr+comr+data */
      convertval2str(459+MVS_KEYTAB_LEN+1, len_str, 5);
      memcpy(mu_req+66, len_str, 5); 
    }

  return 0;
}


/* display DES key */
void display_key( char * hstring, unsigned char * key, int key_len ) {
int i;
  printf("%s ",hstring );
  for ( i=0; i < key_len; i++ ) {
    if ( isprint(*(key+i) ) )
      printf("[%x,%c]", * (key+i), *(key+i) );
    else 
      printf("[%x,^]", *(key+i) );
  }
  printf("\n");
}

/**
 *  This function will extract the key from the KDC
 *  for the given principal.
 */
int get_key_val_from_kdc_internal(ms2_context * theContext,
				  char* prnName,
				  unsigned char *principalKey,
				  unsigned int * keyLength,
				  int* pkvno,
				  int showErrorMessages)
{
  int rc;

  rc = 1;
  do {   

    //
    // retrieve the principalKey and length for the given principal.  Note
    // that we don't get the encryption type, so it must be derived from
    // the latter.
    //
    krb5_keyblock keyblock;
    krb5_keyblock* pkeyblock = &keyblock;
    memset(pkeyblock,0x00,sizeof(krb5_keyblock));

    ms2_sts status;
    status = ms2getPrincipalKeys(theContext,
				 prnName,
				 pkeyblock,
				 pkvno);

    if (status.major !=0) {
      *keyLength = 0;
      if (showErrorMessages) {
	printf("ERROR: get_key_val_from_kdc() major code is %ld minor code is %ld \n", 
	       status.major, status.minor);
	printf("ERROR TEXT: %s\n", ms2strError(&status));
	fprintf(logfile, "\n ERROR:get_key_val_from_kdc()  major code is %ld minor code is %ld \n",
		status.major, status.minor);
	fprintf(logfile, "\n ERROR TEXT: %s\n", ms2strError(&status));
      }
      rc = status.minor;

    } else {

      memcpy(principalKey,pkeyblock->contents,pkeyblock->length);
      *keyLength = pkeyblock->length;
      rc = 0;
    }

    free(pkeyblock->contents);
  } while (0);
  return rc;
}

/**
 *  This function will extract the key from the KDC
 *  for the given principal.  If an error occurs, the
 *  code will be returned, but no output will be logged.
 */
int get_key_val_from_kdc_silent(ms2_context * theContext,
				char* prnName,
				unsigned char *principalKey,
				unsigned int * keyLength,
				int* pkvno)
{
  return(get_key_val_from_kdc_internal(theContext,prnName,
				       principalKey,keyLength,pkvno,0));
}


/**
 *  This function will extract the key from the KDC
 *  for the given principal.
 */
int get_key_val_from_kdc(ms2_context * theContext,
			 char* prnName,
			 unsigned char *principalKey,
			 unsigned int * keyLength,
			 int* pkvno)
{
  return(get_key_val_from_kdc_internal(theContext,prnName,
				       principalKey,keyLength,pkvno,1));
}



/*
 * build_logname - constructs a name base on the path,
 *                 logname, port number, and date
 *
 */
int build_logname ()
{
   time_t seconds;
   struct tm *timeptr;
   char *logfile_path;

   time (&seconds);                 /* get time in seconds */
   timeptr = localtime(&seconds);   /* convert to date format */

   logfile_path = getenv("LOGFILE_PATH");
   if (logfile_path == NULL)
   {
     printf("%s is not set in the environment\n", "LOGFILE_PATH");
     return 1;
   }
   sprintf (logfile_name, "%s/%s.%d%2.2d%2.2d.log", logfile_path, LOGNAME,
                                            /* Y2K changes */
                                            (timeptr->tm_year)+1900,
                                            timeptr->tm_mon +1,
                                            timeptr->tm_mday);
   return 0;
}

/* checks for errors in MUCOM */
int check(int rc, char *oper)
{
  int    errno;
  char    errtext[500];
  char    host[500];
  char    ipaddr[500];
  int    port;

  if (rc != E_mucom_OK) {
    mucom_audit_info(host, ipaddr, &port, &errno, errtext);
    printf(" mucom_%s: rc %d, %s, %s, %d text %s!\n", oper, rc, host, ipaddr, port, errtext);
    fprintf(logfile, " mucom_%s: rc %d, %s, %s, %d text %s!\n", oper, rc, host, ipaddr, port, errtext);
    return 1;
  }
  return 0;
}

int sendpublic_key(llPRINCIPAL *p_entry ,char *mu_resp) {
  int   outlen=MAXSIZE;

  fprintf(logfile, "%s: Setup PKI HostName=%s, Port=%s, updateing:%s\n",
          kgenlogt(),p_entry->host_name,p_entry->port_str, 
          p_entry->principal_name);
  printf( "In Send Public Key mucom_setup\n");
  if (check(mucom_setup(p_entry->host_name,p_entry->port_str,300,NULL),"setup") != 0) 
      return 1;

  fprintf(stdout, "%s: Sending request\n", kgenlogt());
  if (check(mucom_send(NULL, 0, mu_resp, &outlen),"send") != 0){
    /* try sending again */
    fprintf(stdout, "trying mucom_send again \n");
    outlen = MAXSIZE;
    if (check(mucom_send(NULL, 0, mu_resp, &outlen),"send") != 0)
      return 3;
  }
  printf("leave sendpublic_key\n");  
  return 0;
}

/* change for PowerBroker 08/15/1999 */
int save_key ( FILE * logfile, unsigned char * buf,int keylen,char * ktfile_name ) {
char str[256];
FILE * tmpfp;

  sprintf(str, "../k/%s", ktfile_name);
  fprintf( logfile, "saving keytab file %s\n",str );
  if ((tmpfp = fopen(str, "wb")) == NULL)
  {
    fprintf(logfile, "\n ERROR: error creating temporary file: %s\n", str);
    return 0;
  }
  if (fwrite(buf, keylen, 1, tmpfp) < 1)
  {
    fprintf(logfile, "\n ERROR: error writing to file: %s\n", str);
    return 0;
  }
  fclose(tmpfp);
  return 1;
}

/* formats the keytab update MU as per standards */
int format_pb_mu(HOSTNAMES *p_entry, unsigned char *key_info, char *mu_req,
		 int *mu_req_sz, int kvno) {
  int     mu_data_sz, keytab_sz;
  char     len_str[5], timebuf[10];
  unsigned char keytab_contents[KEYTAB_LEN];
  char     principal_info[256];
  time_t     timevar;
  struct tm   ltm;

  /* get the keytab file contents */
  if ( PBNEWKEY == 1 ) {
    strcpy(principal_info, p_entry->principal_name);
    strcat(principal_info, "@");
    strcat(principal_info, p_entry->realm_name);
    mu_data_sz = strlen(p_entry->principal_name) + strlen(p_entry->realm_name)+
         + 1; 
    principal_info[mu_data_sz] = '\0';
    get_keytab_contents(principal_info, key_info, keytab_contents, &keytab_sz,kvno);
    if ( ! save_key(logfile, keytab_contents, keytab_sz , p_entry->ktfile_name ) ) {
       printf( "Error Saving pbkey \n");
       return 1;
    }
  } else {
    if ( ! read_key(logfile, key_info, &keytab_sz , (char *) p_entry->ktfile_name ) ) {
       printf( "Error reading saved pbkey \n");
       printf( "Error Saving pbkey \n");
       return 1;
    }
  }

  memset(mu_req, ' ', MAXSIZE);  
  /* mu header */
  memcpy(mu_req, "DKK99999", 8);
  memcpy(mu_req+8, "00", 2);
  memcpy(mu_req+10, "001", 3);
  /* request date and time */
  time(&timevar);
  ltm = *localtime(&timevar);
  sprintf(timebuf, "%02d%02d%02d", ltm.tm_mon+1, ltm.tm_mday, ltm.tm_year);
  strncpy(mu_req+13, timebuf, 6 );
  sprintf(timebuf, "%02d%02d%02d", ltm.tm_hour, ltm.tm_min, ltm.tm_sec );
  strncpy(mu_req+19, timebuf, 6 );
  memcpy(mu_req+25, "000000", 6);
  memcpy(mu_req+31, "000000", 6);
  memcpy(mu_req+37, "^", 1);
  memcpy(mu_req+38, "DK", 2);
  memcpy(mu_req+40, "DKMUSS  ", 8);
  memcpy(mu_req+48, "        ", 8);
  memcpy(mu_req+56, "1046", 4);
  memcpy(mu_req+60, "    ", 4);
  memcpy(mu_req+64, "0", 1);
  memcpy(mu_req+65, "0", 1);
  memcpy(mu_req+79, "000", 3);
  /* create security stuffs */
  /* No need for PowerBroker 08/16/1999 */
  /*
  if (p_entry->principal_type == 'M')  {
    memcpy(mu_req+100, "00", 2); 
    memcpy(mu_req+118, "DKMUSS  ", 8); 
  }
  */
  /* end of PowerBroker Change 08/16/1999 */
  /* comr */
  memcpy(mu_req+174, "DKKEYUPD", 8);
  memcpy(mu_req+182, "0", 1);
  memcpy(mu_req+183, "001", 3);
  
  /* copy actual mu data */
  /* principal name */
  memcpy(mu_req+199, p_entry->principal_name, 
                strlen(p_entry->principal_name));
  memcpy(mu_req+199+strlen(p_entry->principal_name), "@", 1);  
  /* realm_name */
  memcpy(mu_req+200+strlen(p_entry->principal_name), p_entry->realm_name, 
                    strlen(p_entry->realm_name));
  /* keytab file name */
  memcpy(mu_req+263, p_entry->ktfile_name, strlen(p_entry->ktfile_name));
  /* keytab file path */
  memcpy(mu_req+295, p_entry->ktfile_path,strlen(p_entry->ktfile_path));
  /* convert keytab size to str */
  /* rc 12/23/97 ---- modification starts here */
  memcpy(mu_req+327, p_entry->ktfile_owner,strlen(p_entry->ktfile_owner));
  memcpy(mu_req+359, p_entry->ktfile_group,strlen(p_entry->ktfile_group));
  /* rc 12/23/97 ---- modification ends here */
  convertval2str(keytab_sz, len_str,4);
  memcpy(mu_req+455, len_str, 4);
  memcpy(mu_req+459, keytab_contents, keytab_sz);
  memcpy(mu_req+459+keytab_sz, "^", 1);
  memcpy(mu_req+459+keytab_sz+1, "\0", 1); 
  *mu_req_sz = 459+keytab_sz+1;
  /* convert message_length to str msg_len = muhdr+comr+data */
  convertval2str(459+keytab_sz+1, len_str, 5);
  memcpy(mu_req+66, len_str, 5); 

  return 0;
}

int send_pb_krb_mu(HOSTNAMES *p_entry, char *mu_str,int mu_str_len,char *mu_resp)
{
  int   outlen=MAXSIZE;
  KerbInfo kerb_info;

  fprintf(logfile, "%s: Setup MUCOM HostName=%s, Port=%s, updateing:%s\n",
          kgenlogt(),p_entry->host_name,p_entry->port_str, 
      p_entry->principal_name);

  /* kerberos info structure */
  strcpy(kerb_info.keytab, cur_env.kt_filename);

  /* fully qualified domain name for client principal */
  strcpy(kerb_info.client_principal, cur_env.krb5_principal_name);
  strcat(kerb_info.client_principal, "@");
  strcat(kerb_info.client_principal, p_entry->realm_name);

  /* fully qualified domain name for server principal */
  strcpy(kerb_info.server_principal, p_entry->admin_principal_name);
  strcat(kerb_info.server_principal, "@");
  strcat(kerb_info.server_principal, p_entry->realm_name);

  /* credentials cache file for this method server (for putenv) */
  strcpy(kerb_info.ccfile, cur_env.krb5_ccname);

  /* requested lifetime of TGT (ticket granting ticket) in hours */
  strcpy(kerb_info.tgt_lifetime, "24h");

  fprintf( logfile, "mucom_setup:\n");
  fprintf( logfile,"Host:%s\nPort:%s\nClient:%s\nServer:%s\n",
            p_entry->host_name, p_entry->port_str, 
            kerb_info.client_principal, kerb_info.server_principal);
  if ( ClearText == 1 ) {
     printf( "ClearText\n");
     if (check(mucom_setup(p_entry->host_name, p_entry->port_str, 300, 
                NULL), "setup") != 0) 
     return 1;
  } else {
     if (check(mucom_setup(p_entry->host_name, p_entry->port_str, 300, 
                &kerb_info), "setup") != 0) 
      return 1;
  }

  fprintf(logfile, "MU request: \n");
  my_func(logfile,  mu_str , 'c' ); 
  fprintf(logfile, "%s: Sending request\n", kgenlogt());
  if (check(mucom_send(mu_str, mu_str_len, mu_resp, &outlen),"send") != 0){
    /* try sending again */
    printf("======trying mucom_send again============================= \n");
    fprintf(logfile, "trying mucom_send again \n");
    outlen = MAXSIZE;
    if (check(mucom_send(mu_str, mu_str_len, mu_resp, &outlen),"send") 
                                    != 0)
      return 3;
    }
  
  /*  my_func(logfile,  mu_resp , 'c' );  */
  return 0;
}

int update_host_info(HOSTNAMES *p_entry) {
  
  char freq_str[32], *ptr;
  int i, tk_lst[3];
  struct tm *nxt_tm, *cur_tm;
  time_t nxt_tmval,freq_tmval, cur_tmval;

  strcpy(freq_str, p_entry->modify_freq);
  /* process freq_str */
  for (i=0; i<3; i++)
  {
    if (i == 0) ptr = strtok(freq_str, ":");
    else ptr = strtok(NULL, ":");
      if (ptr == NULL)
    {
      fprintf(logfile, "ERROR: frequency format(DD:HH:MM) is wrong\n");
      return 1;
    }
    tk_lst[i] = atoi(ptr);
  }
  
  freq_tmval =  (tk_lst[0]*24*3600) + (tk_lst[1]*3600) + (tk_lst[2]*60);
  /* calculate last_modified date as current date */
  time(&cur_tmval);
  cur_tm = localtime(&cur_tmval);

  /*** Y2K changes start here  ****/
  /* commenting this line -->
  strftime(p_entry->last_modified, sizeof(p_entry->last_modified),
                  "%x,%X", cur_tm);  <-- comment ends here */
  /* Y2K new code starts here */
  strftime(p_entry->last_modified, sizeof(p_entry->last_modified),
              "%m/%d/%Y,%X", cur_tm);
  /* Y2K new code ends here */
  /**** Y2K changes end here ****/

  /* calculate next_modification as last_modified+freq_time */
  nxt_tmval = cur_tmval + freq_tmval;
  nxt_tm = localtime(&nxt_tmval);
  /**** Y2K changes start here ****/
  /* commenting this line-->
  strftime(p_entry->next_modification,
        sizeof(p_entry->next_modification), "%x,%X", nxt_tm); */
  strftime(p_entry->next_modification, sizeof(p_entry->next_modification),
        "%m/%d/%Y,%X", nxt_tm);
  /**** Y2K changes end here ****/

  return 0;
}

int need_to_update_kdc_db( int key_type ) {
  
  printf( "gkeytype == %d\n",key_type);
  switch ( key_type ) {
  case NEWDES3KEY :
  case NEWDESKEY :
  case ENDGROUPKEY :
    return(1);
    break;
  case OLDKEY :
  case REPEATKEY :
  case NEWDESGROUPKEY :
  case NEWDES3GROUPKEY :
    return(0); 
    break;
  default:
    return(1);
  }
}

/* processes the given principal */
int process_principal(llPRINCIPAL *p_entry) 
{
  // not sure this is ever used
  ms2_context   theContext;

  ms2_principal theChangingPrincipal;
  ms2_principal  theAdminPrincipal;
  char      mu_req[MAXSIZE];
  mu_response   mu_resp;
  unsigned char   key_info[DESKEYLEN*4];
  int key_len;
  int         mu_req_sz=0, i, n ;
  char        *ptr;
  int         rc ;
  int kvno;

  PBNEWKEY=0;        /* initializing */


  memset(&theContext,0x00,sizeof(ms2_context));
  memset(&theChangingPrincipal,0x00,sizeof(ms2_principal));
  memset(&theAdminPrincipal,0x00,sizeof(ms2_principal));

  for(i=0;i<DESKEYLEN*4;i++) {
    key_info[i]=0;
  }
  gerrstatus = 0;

  if (needs_updation(p_entry)) {
    /* check if KADMIN daemon is alive and working properly */

    printf("Check ktadmin_alive.\n");
    if (check_if_KADMIN_alive( p_entry->principal_name, p_entry->realm_name,
                               &theContext, & theChangingPrincipal, 
                               & theAdminPrincipal) != 0) {
      printf("ERROR: Unable to connect to KADMIND daemon %s \n",p_entry->realm_name);
      fprintf(logfile, "ERROR: Unable to connect to KADMIND daemon\n");
      /* DISCONNECT_KADMIN; */
      printf("Return from process_prinbipal() with error...\n");
      gerrstatus = 1;
      return -1; 
    }

    printf("Pkiflag=%c\n",p_entry->principal_type2);
    if ( p_entry->principal_type2 == 'I' ) {
      PKIFlag=1;
      DESFlag=0;
      if ( sendpublic_key(p_entry,(char *) mu_resp.header.rqst_id) != 0 ) {
        printf("after sendpublic_key status 1\n");
        return(1);
      }
      {
	int i;
	printf("DES key is ");
	for (i=0; i<8; i++) {
	  printf("%02x",(unsigned char)mu_resp.header.rqst_id[i]);
	}
	printf("\n");
      }

      PKIFlag=0;
      DESFlag=1;
      printf("after sendpublic_key status 0\n");

    } else {
      DESFlag =0;
      PKIFlag =0;
    }


    {
      // in all cases, try to retrieve the kvno from the 
      // database first.  If the principal does not exist, 
      // this call will fail.
      int rcKvno = get_key_val_from_kdc_silent(&theContext,
					       p_entry->principal_name, 
					       key_info, 
					       &key_len,
					       &kvno); 
      if (rcKvno != 0) {
	// no kvno.  Principal does not exist?
	// for now, set to 1 since a newly-created principal
	// will start with kvno=1.  This will be incremented
	// to 2 when we generate the keytab.
	kvno = 1;
      }

      if (kvno % 256 == 255) {
	// if the current key version is just shy of a 
	// multiple of 256, then the next increment will
	// cause problems (CyberSafe has a special handler
	// for a kvno value of 0 in the keytab; MIT does
	// not treat it specially).  Increment the kvno
	// an extra time here, so the resulting value will
	// have nonzero modulo-256 value.
	//
	// note that the handling around the call to 
	// ms2ModifyPrincipal() is also specially modified
	// to accomodate this change, since the kvno is
	// not passed from this code to the database.
	//
	kvno++;
      }

    }

    switch ( ( gkeytype =get_KeyType(p_entry->action) ) ) {
    case NEWDES3KEY:
      fprintf(logfile, "%s: Run RSA to generat a Triple DES key. (%s) \n", 
	      kgenlogt(), p_entry->action);
      rc = gen_new_DES3_key(key_info); 
      printf("%s: Run RSA to generat a Triple DES key. (%s) [%x] \n", 
	     kgenlogt(), p_entry->action, (int)key_info);
      kvno++;
      break;
    case NEWDESKEY: 
      fprintf(logfile, "%s: Run RSA to generat a DES key. (%s) \n", 
	      kgenlogt(), p_entry->action);
      rc = gen_new_DES_key(key_info); 
      //
      // we need to place a 0x00 at key_info[DESKEYLEN]
      // so getkeylen() can identify this as single-DES.
      //
      key_info[DESKEYLEN]=0x00;
      printf( "%s: Run RSA to generat a DES key. (%s) [%x] \n", kgenlogt(), p_entry->action,*key_info);
      kvno++;
      break;
    case NEWDESGROUPKEY: 
      fprintf(logfile, "%s: Run RSA to generat a DES group key. (%s) \n", 
	      kgenlogt(), p_entry->action);
      rc = gen_new_DES_key(key_info); 
      //
      // we don't need to explicitly set
      // key_info[DESKEYLEN] as 0x00 - why?
      //
      printf( "%s: Run RSA to generat a DES group key. (%s) [%x]\n", kgenlogt(), p_entry->action,*key_info);
      write_key_val_to_save(p_entry->principal_name,key_info,getkeylen(key_info));
      kvno++;
      break;
    case NEWDES3GROUPKEY: 
      fprintf(logfile, "%s: Run RSA to generat a Triple DES group key. (%s) \n", 
	      kgenlogt(), p_entry->action);
      printf("%s: Run RSA to generat a Triple DES key. (%s) \n",
	     kgenlogt(), p_entry->action);
      rc = gen_new_DES3_key(key_info); 
      write_key_val_to_save(p_entry->principal_name,key_info,getkeylen(key_info));
      kvno++;
      break;
    case REPEATKEY: 
      fprintf(logfile, "%s: Load repeat key from previous. (%s) \n", 
	      kgenlogt(), p_entry->action);
      n = read_key_val_from_save( p_entry->principal_name, key_info, &key_len);
      if (n <1 ) {
	printf("ERROR: error reading group key (repeat)\n");
	return -1;
      }
      // the kvno on a REPEAT still needs to be incremented from
      // the principal's retrieval.  Note that we enter this function
      // with a new principal - we do not iterate over this switch
      // statement for each principal in the list.
      kvno++;
      break;
    case ENDGROUPKEY: 
      fprintf(logfile, "%s: Load repeat key from previous. (%s) \n", 
	      kgenlogt(), p_entry->action);
      n = read_key_val_from_save( p_entry->principal_name, key_info, &key_len);
      if (n <1 ) {
	printf("ERROR: error reading group key(endgroupkey)\n");
	return -1;
      }
      // the kvno on an ENDGROUPKEY needs to be incremented for the
      // same reason as described in REPEAT.
      kvno++;
      /* unlink_key_save(); */
      break;
    default:
      fprintf(logfile, "%s: Get the old key from database. (%s) \n", 
	      kgenlogt(), p_entry->action);
      rc = get_key_val_from_kdc(&theContext,
				p_entry->principal_name, 
				key_info, 
				&key_len,
				&kvno); 
      break;
    }
    display_key("key_info:",(unsigned char *) key_info, getkeylen(key_info) ); 
    fprintf(stdout,"Key Info: keylen=%d\n" , getkeylen(key_info) ); 
    if ( rc != 0 ) {
      printf("ERROR: error performing key operations for keytype=%d\n",gkeytype);
      fprintf(logfile, "ERROR: error performing key operations for keytype=%d\n",gkeytype);
      /* robert chang 2/25/98 disconnect_KADMIN( &theContext ); */
      gerrstatus = 1;
      DISCONNECT_KADMIN;
      return -1;
    }
#ifdef SUPPORT_POWERBROKER
    /************************************/
    /* added for PowerBroker 08/15/1999 */ 
    /************************************/ 
    if ( p_entry->principal_type == 'S' ) {
      /* 
      **  if ( ! save_key(logfile, key_info , DESKEYLEN, p_entry->ktfile_name ) ) { 
      **    fprintf(logfile, "ERROR: saving keytab file for %s\n", p_entry->host_name); 
      **    DISCONNECT_KADMIN; 
      **    return -1; 
      **  }
      */
      PBNEWKEY = 1;            /* need a new key */
      printf ("****Start PB NewKey process **** \n");
      hostptr = p_entry->p3next ;
      good_cnt = 0;
      while ( hostptr != NULL ) {
        if ( needs_newkey( hostptr ) ) {
          printf( "%d: format pb mu %s ",good_cnt,hostptr->host_name); 
          if ( format_pb_mu(hostptr, key_info, mu_req, &mu_req_sz, kvno) != 0){
            fprintf(logfile, "ERROR: error formatiing MU\n");
            DISCONNECT_KADMIN;
            return -1; 
          }

          if (send_pb_krb_mu(hostptr,mu_req,mu_req_sz,(char *) &mu_resp) != 0) {
	    fprintf(logfile,"ERROR: error sending kerberized MU\n");
	    printf("ERROR: error sending kerberized MU[[%s]]\n",
		   hostptr->host_name);
	    hostptr = hostptr->p2next;
	    continue;
          }
          i = check_MU_response(&mu_resp,hostptr->host_name,hostptr->port_str);
          if ( i != 0 ) {
	    ptr = (char *) & mu_resp;
	    for (i=0; i < 199 ; i++)
	      fprintf(logfile, "%c", ptr[i]  );
	    fprintf(logfile, "\n");
	    fprintf(stdout,"ERROR: kerberized MU response not 00.\n");
	    printf("Error: MU response not 0, rc=%d\n",i) ;
	    hostptr = hostptr->p2next;
	    continue;
          }
          fprintf(logfile, "OK sending MU to %s\n",hostptr->host_name);
          if (update_host_info(hostptr) != 0) {
            fprintf(logfile, "ERROR: error updating principal (%s) info\n", 
		    p_entry->principal_name);
            printf( "ERROR: error updating principal (%s) info\n", 
		    p_entry->principal_name);
            DISCONNECT_KADMIN;
            return -1;
          }
          if ( dump_hosts_DB(hostptr, p_entry->host_name) != 0 ) {
            fprintf(logfile,"Error: write file:%s,rc=%d\n",p_entry->host_name,i); 
            printf("Error: dump host file:%s,rc=%d\n",p_entry->host_name,i); 
            DISCONNECT_KADMIN;
            return -1;
          }
          fprintf(stdout, "OK dump_hosts_DB %s \n",p_entry->host_name,i);
          good_cnt ++;
          if ( good_cnt > 50 ) {
            if (change_principal_key(p_entry->principal_name, 
                                     p_entry->realm_name, key_info, 
                                     getkeylen(key_info), &theContext,
                                     & theChangingPrincipal ) != 0) {
	      fprintf(logfile, "ERROR: error changing principal key %s\n",
		      p_entry->principal_name);
            }
            FREE_KADMIN;
            return 5; 
          }
        }
        hostptr = hostptr->p2next;
      }
      printf( "**%s,Good_cnt=%d\n",p_entry->principal_name,good_cnt);
      if ( ( good_cnt > 0 )  &&
           change_principal_key(p_entry->principal_name, p_entry->realm_name,
				key_info, getkeylen(key_info), &theContext, & theChangingPrincipal ) != 0) {
        fprintf(logfile, "ERROR: error changing principal key %s\n",
                p_entry->principal_name);
        FREE_KADMIN;
        return -1; 
      }  
      DISCONNECT_KADMIN;
      return 0;  
    }
    /* end for PowerBroker 08/16/1999 */
#endif
    printf( "=====%s: Format the MU request...\n", kgenlogt());
    fprintf(logfile, "%s: Formatting a MU request...\n", kgenlogt());
    if ( format_mu(p_entry, key_info, getkeylen(key_info),mu_req, &mu_req_sz, kvno) != 0) {
      fprintf(logfile, "ERROR: error formatiing MU\n");
      /* robert chang 2/25/98 disconnect_KADMIN( &theContext ); */
      DISCONNECT_KADMIN;
      gerrstatus=1;
      return -1; 
    }
    printf( "=====%s: Sending the MU request...\n", kgenlogt());
    fprintf(logfile, "%s: Sending the MU request...\n", kgenlogt());
    if ((rc=send_krb_mu(p_entry,mu_req,mu_req_sz,(char *) &mu_resp)) != 0) {
      fprintf(logfile,"ERROR: error sending kerberized MU\n");
      printf("ERROR: error sending kerberized MU\n");
      DISCONNECT_KADMIN;  
      gerrstatus=1;
      return -1; 
    }
    /* If no error in MU response, update KDC's database */
    /* first look at the status code in the mu header */
    if (check_MU_response(&mu_resp,p_entry->host_name,p_entry->port_str)!=0) {
      ptr = (char *) & mu_resp;
      for (i=0; i < 199 ; i++)
	fprintf(logfile, "%c", ptr[i]  );
      fprintf(logfile, "\n");
      gerrstatus=1;
      DISCONNECT_KADMIN;
      return -1;
    }
    if ( need_to_update_kdc_db ( gkeytype ) ) {
      printf("++Update kdc db for the principal %s...\n",p_entry->principal_name);
      if (change_principal_key(p_entry->principal_name, p_entry->realm_name,
                               key_info, getkeylen(key_info), &theContext, 
			       & theChangingPrincipal ) != 0) {
        fprintf(logfile, "ERROR: error changing principal key \n");
        gerrstatus=1;
        FREE_KADMIN;
        return -1; 
      }  
    } else {
      printf("--Skip updating kdc db for the principal %s..\n",p_entry->principal_name);
    }
    DISCONNECT_KADMIN;
    fprintf(logfile, "%s: MU response is: \n", kgenlogt());
    ptr = (char *) & mu_resp;
    for (i=0; i < 199 ; i++) fprintf(logfile, "%c", ptr[i]  );
    fprintf(logfile, "\n");
    fprintf(logfile, "%s: Changed the principal key in the KDC database\n",kgenlogt());
  } else {
#ifdef SUPPORT_POWERBROKER
    /* PowerBroker Change starts ************ 08/17/1999 */
    if ( p_entry->principal_type == 'S' ) {
      if ( ! read_key(logfile, key_info ,&key_len, p_entry->ktfile_name ) ) {
	fprintf(logfile, "ERROR: reading keytab file: %s for %s\n",
		p_entry->ktfile_name,p_entry->host_name);
	return -1;
      }
      printf ("****Start PB key out (part needs no key update) **** \n");
      hostptr = p_entry->p3next ;
      good_cnt = 0;
      while ( hostptr != NULL ) {
        if ( needs_newkey( hostptr ) ) {
          printf("(%d): Format PB MU -> [%s] ",good_cnt+1,hostptr->host_name);
          if ( format_pb_mu(hostptr, key_info, mu_req, &mu_req_sz, kvno) != 0){
            fprintf(logfile, "ERROR: error formatiing MU\n");
            return -1; 
          }

          /*  commnet out area starts 08/16/1999 rc *********
	      fprintf(logfile,"==>");
	      for (i=0;i<mu_req_sz; i++ )
	      if ( isprint( mu_req[i] ) )
              fprintf(logfile,"%c",mu_req[i]);
	      else
              fprintf(logfile,"*");
	      fprintf(logfile,"<==\n");
	      **********************************08/16/1999 rc  */

          if (send_pb_krb_mu(hostptr,mu_req,mu_req_sz,(char *) &mu_resp) != 0) {
	    fprintf(logfile,"ERROR: error sending kerberized MU\n");
	    printf("ERROR: error sending Kerberized MU [[%s]].\n",
		   hostptr->host_name);
	    hostptr = hostptr->p2next;
	    continue;
	    /* return -1;  */
          }

          if (check_MU_response(&mu_resp,hostptr->host_name,hostptr->port_str)!=0) {
	    fprintf(logfile,"ERROR: MU response not 00.\n");
	    ptr = (char *) & mu_resp;
	    for (i=0; i < 199 ; i++)
	      fprintf(logfile, "%c", ptr[i]  );
	    fprintf(logfile, "\n");
	    printf("ERROR: MU response not 00[[%s]].\n",hostptr->host_name);
	    hostptr = hostptr->p2next;
	    return -1;
          }
          fprintf(logfile, "OK sending MU rsp=00 [%s].\n",hostptr->host_name );

          if (update_host_info(hostptr) != 0) {
            fprintf(logfile, "ERROR: error updating principal (%s) info\n", 
		    p_entry->principal_name);
            return -1;
          }
          i=dump_hosts_DB(hostptr, p_entry->host_name); 
          printf("Update file %s (rc=%d).\n", p_entry->host_name,i);

          good_cnt ++;
          if ( good_cnt > 50 ) {
	    printf ("****End PB key out (reach 50 key update) **** \n");
	    return 5;
          }
        }
        hostptr = hostptr->p2next;
      }
      printf ("****End PB key out (no key update) **** \n");
      fflush (stdout);
      sleep( 1 );
      return 0;
      /* PoerBroker Changes ends here ***** 08/17/1999 */
    } else {
#endif
      fprintf(logfile, "Principal %s does not need any updation\n", 
	      p_entry->principal_name);
      return 1;
#ifdef SUPPORT_POWERBROKER
    }
#endif
  }  
  /* clear up the principal created while login the kadmin 
     ms2freePrincipalContents(&theChangingPrincipal);
     ms2freePrincipalContents(&theAdminPrincipal);
  */
  return 0;
}

/* converts time string to value
   ex: "01/02/98,HH:MM:SS" to <numer_of_seconds>
*/
time_t convertdttm2tmval(char *dt_tm_str)
{
  char     dt_str[16], tm_str[16], *ptr;
  int     i, tk_lst[3];
  time_t    nxt_tmval;
  struct tm   nxt_tm;

  /* split the next modification time str into time and date strings */
  ptr = strtok(dt_tm_str, ",");
  if (ptr == NULL)
  {
    fprintf(logfile, "ERROR: date not found\n");
    return -1;
  }
  strcpy(dt_str, ptr);
  ptr = strtok(NULL,",");
  if (ptr == NULL)
  {
    fprintf(logfile, "ERROR: time not found\n");
    return -1;
  }
  strcpy(tm_str, ptr);
  /* process dt_str */
  for (i=0; i<3; i++)
  {
    if (i == 0) ptr = strtok(dt_str, "/");
    else ptr = strtok(NULL, "/");
      if (ptr == NULL)
    {
      fprintf(logfile, "ERROR: date format(MM/DD/YY) is wrong\n");
      return -1;
    }
    tk_lst[i] = atoi(ptr);
  }

  /* Y2K changes for century */
  if (tk_lst[2] < 1900) {
      fprintf(logfile, "ERROR: date format(MM/DD/YYYY) is wrong\n");
      return -1;
  }

  nxt_tm.tm_mon = tk_lst[0] - 1;
  nxt_tm.tm_mday = tk_lst[1];
  nxt_tm.tm_year = tk_lst[2] - 1900;    /* Y2K changes */
  
  /* process tm_str */
  for (i=0; i<3; i++)
  {
    if (i == 0) ptr = strtok(tm_str, ":");
    else ptr = strtok(NULL, ":");
      if (ptr == NULL)
    {
      fprintf(logfile, "ERROR: time format(HH:MM:SS) is wrong\n");
      return -1;
    }
    tk_lst[i] = atoi(ptr);
  }
  nxt_tm.tm_hour = tk_lst[0];
  nxt_tm.tm_min = tk_lst[1];
  nxt_tm.tm_sec = tk_lst[2];
  nxt_tm.tm_isdst = -1;

  tzset();
  nxt_tmval = mktime(&nxt_tm);

  return  (nxt_tmval);
}



/* This function changes the keytab file in the KDC database */
int change_principal_key(char *principal_name,
			 char *realm_name, 
			 unsigned char *principalKey, 
			 unsigned int keyLength, 
			 ms2_context * theContext, 
			 ms2_principal * theChangingPrincipal)  // not used?
{
  ms2_sts       status;

  printf("**Update principal DB: %s, %s, %d,\n",principal_name, realm_name, keyLength);

  do {
    krb5_keyblock keyblock;
    keyblock.magic = 0; // not used?

    keyblock.length = keyLength;

    // there are only two flavors of encryption.
    if (keyLength == 8) {
      keyblock.enctype = ENCTYPE_DES_CBC_MD5;  // not used?
    } else {
      // keyLength must be 24.
      keyblock.enctype = ENCTYPE_DES3_CBC_MD5; 
    }

    keyblock.contents = malloc (sizeof(krb5_octet) * keyblock.length);
    memcpy(keyblock.contents,principalKey,keyblock.length);

    // create the principal if it does not exist.  If the principal
    // is already present, this function will do nothing.
    ms2addPrincipal(theContext, principal_name);

    // what if principal DNE?
    // set the principal's key.
    ms2modifyPrincipal(theContext, principal_name, &keyblock);

    status.major = 0;
    status.minor = 0;

    // disconnect?
    if (status.major != 0) {
      fprintf(logfile, "Error Disconnecting KADMIN(ms2disconnect)\n");
      break;
    }

    free(keyblock.contents);
    
  } while (0);
  /* Free the principal structure contents */
  /* robert chang 2/25/98 
  ms2freePrincipalContents(theChangingPrincipal);
  */
  if (status.major != 0)
  {
    fprintf(logfile, "\n ERROR: change_principal_key() major code is %ld minor code is %ld \n",
	    status.major, status.minor);
    fprintf(logfile, "\n ERROR TEXT: %s\n", ms2strError(&status));
    return -1;
  }
  else
    return 0;
}

/* read the admin principal's (chappas/admin) name and password from the 
   file given by env var GPR_KDC_PASSWORD_FILE */
void read_admin_principal(struct admin *thisAdmin, char * realm)
{
  const char* pop="123";
  strcpy(thisAdmin->name, "kgen/admin");
  strcpy(thisAdmin->realm, realm );
  snprintf(thisAdmin->password,128,"%s%s%s",snap,CRACKLE,pop);
}

char *get_pwd(void *client_data, const ms2_principal *principal)
{

  password = (char *)malloc(strlen((char *)client_data) + 1 );
  memcpy(password,  (char *)client_data, strlen((char *)client_data) + 1);
  return (password);
}



/* opens event log file for KGEN module */
int open_log_file()
{
  if (build_logname() != 0)
    return 1;  
  if ((logfile = fopen(logfile_name,  "a")) == NULL)
  {
    printf("ERROR: cannot open log file \n");
      return 1;  
  }
  fprintf(logfile,"-----------------------------------------------------"); 
  fprintf(logfile,"----------------------\n"); 
  fprintf(logfile,"STARTING THE KEYTAB UPDATE PROCESS ON %s\n\n", kgenlogt());
  return 0;
}

/*********************************************************
 * kgenlogt() -- Return current time (string) for logging.
 *
 * Returns: current time of day (string).
 *********************************************************/

char* kgenlogt (void)
{
   time_t ltime;
   static char time_str[35];
   char *ptr;

   time (&ltime);
   /*
   return (ctime(&ltime)); */

   //ctime_r(&ltime, time_str, sizeof(time_str));
   ctime_r(&ltime, time_str);

   ptr = strchr(time_str, '\n');
   if (ptr != NULL) *ptr = '\0';
   return time_str;  
}


/* checks the environment for proper settings */
int check_environ() {
  char *ptr;


  if ((ptr = getenv("PRINCIPALDB")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","PRINCIPALDB");
    return 1;
  } else {
    strcpy(cur_env.principal_db, ptr);
  }
 
  if ((ptr = getenv("KRB5_PRINCIPAL_NAME")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","KRB5_PRINCIPAL_NAME");
    return 1;
  } else {
    strcpy(cur_env.krb5_principal_name, ptr);
  }

  if ((ptr = getenv("KEYTAB_FILENAME")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","KEYTAB_FILENAME");
    return 1;
  } else {
    strcpy(cur_env.kt_filename, ptr);
  }

  if ((ptr = getenv("KINIT_PGM_PATH")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","INIT_PGM_PATH");
    return 1;
  } else {
    strcpy(cur_env.kinit_pgm, ptr);
  }

  //
  // 061130 This is potentially a legacy problem.  In MIT Kerberos,
  // the environment variable KRB5CCNAME is used to define the
  // credentials cache.  In the previous (CSF) implementation, this 
  // was defined as KRB5_CCNAME (note the underscore).  To remove
  // any ambiguity, convert to the MIT-standard environment 
  // variable.  This will cause a change in all scripts used to
  // drive kgen; we will force an environment error here.
  //
  if ((ptr = getenv("KRB5_CCNAME")) != NULL) {
    fprintf(logfile, "KRB5_CCNAME is set in the environment, please use KRB5CCNAME\n"); 
    return 1;
  }

  if ((ptr = getenv("KRB5CCNAME")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","KRB5CCNAME");
    return 1;
  } else { 
    strcpy(cur_env.krb5_ccname, ptr);
  }

  if ((ptr = getenv("EXE_PATH")) == NULL) {
    fprintf(logfile, "%s is not set in the environment\n","EXE_PATH");
    return 1;
  } else {
    strcpy(cur_env.exe_path, ptr);
  }

  return 0;
}


void disconnect_KADMIN(ms2_context *theContext)
{
  ms2_sts       status;
  status = ms2disconnect(theContext);
  /*
    if (status.major != 0)
    fprintf( logfile, "Error Disconnect KADMIN(disconnect_KADMIN)\n" );
  */
  fprintf( logfile, "Disconnect KADMIN\n" );

}

int check_if_KADMIN_alive(char * principal_name, 
			  char * realm_name,
			  ms2_context * theContext, 
			  ms2_principal * theChangingPrincipal,
			  ms2_principal * theAdminPrincipal) 
{
  int             statusid;
  ms2_sts       status;
  struct admin     thisAdmin;

  statusid=0;
  read_admin_principal(&thisAdmin, realm_name);
  do {
    /* Convert principal name to Kerberos internal format */
    status = ms2stringToPrincipal(thisAdmin.name, thisAdmin.realm, 
                            theAdminPrincipal);
    statusid=1;
    if (status.major != 0) break;
    /* Connect to KADMIN with admin passwd */
    printf("connecting as %s..\n",thisAdmin.name);
    status = ms2connectWithPwd(theContext, theAdminPrincipal, thisAdmin.password);
    if (status.major != 0) { 
      printf("Failed to connect kadmind as %s%s..for %s.\n",principal_name,thisAdmin.name,thisAdmin.realm); 
      break; 
    }
    statusid=2;

    printf( "connected kadmin ok for (%s)\n",principal_name);
    fprintf( logfile, "connect kadmin ok for (%s)\n",principal_name);
    status = ms2stringToPrincipal(principal_name, realm_name, theChangingPrincipal);
    statusid=3;
    if ( status.major != 0 ) {
      printf ("fail to conv principal name %s.",principal_name); 
      break; 
    } 

    /* check the right to add principal */
    status.major=ms2mayAddPrincipal(theContext,theChangingPrincipal);
    if ( status.major == 0)
    {
      status.major = 999;
      break;
    }
    statusid=4;
    printf( "have right to add pricipal kadmin ok\n");
    fprintf( logfile, "have right to add pricipal kadmin ok\n");

    /* check the right to make change to principal */
    status.major=ms2mayModifyPrincipal(theContext,theChangingPrincipal);
    if ( status.major == 0)
    {
      status.major = 998;
      break;
    }
    statusid=5;
    fprintf( logfile, "have right to modify pricipal kadmin ok\n");
    printf( "have right to modify pricipal kadmin ok\n");

    status.major = 0;
  }while(0);
  /* clean up memory used by get_pwd() */
  if (password != NULL) { free(password); password = NULL; }
  // if (keytab != NULL) { free(keytab); keytab = NULL; }
  if (status.major != 0) {
    if ( statusid >= 1 ) {
      ms2freePrincipalContents(theAdminPrincipal);
    }
    if ( statusid >= 2 ) {
      disconnect_KADMIN(theContext);
    }
    if ( statusid >= 3 ) {
      ms2freePrincipalContents(theChangingPrincipal);
    }
    printf("ERROR: major code is %ld minor code is %ld \n", 
	   status.major, status.minor);
    printf("ERROR TEXT: %s\n", ms2strError(&status));

    fprintf(logfile, "\n ERROR: major code is %ld minor code is %ld \n",
	   status.major, status.minor);
    fprintf(logfile, "\n ERROR TEXT: %s\n", ms2strError(&status));
    return -1;
  } else {
    return 0;
  }
}


/* Fuction : convert the binary char to text format 
 * Input   : in_buf     - an array of binary characters
 *         : in_buf_len - the length of char 
 * Output  : out_buf    - a text display for the ascii format of in_buf
 * Example : 
 *     in_buff = 0x35 0x4F ......
 *     out_buf = "354F......"
 */
void hex2str( char * in_buf, int in_buf_len , char * out_buf ) { 

int i,j;
char * ptr = in_buf;

  j = 0;
  for ( i = 0; i< in_buf_len ; i++ ) {
    out_buf[j++] = ascii_convert( ( ( * ptr ) & 0xf0 ) >> 4 );
    out_buf[j++] = ascii_convert( ( * ptr ) & 0x0f );
    ptr ++;
  }
}

char ascii_convert( char c ) {
  
  if ( c <= 9 ) return( c + '0' );
  return( 'A' + c - 10 );

}


void my_func( FILE * fpt,  char * string, char flag ) {
int i,len;
char * ptr;

    if ( flag == 'c' ) {
    len = strlen( string );
  } else {
    len = 1024;
  }
  ptr = string;
  for ( i=0;i<len;i++) {
    if ( flag == 'c' )
      fprintf(fpt, "%c", ptr[i] ); 
    else
      fprintf(fpt, "%x ", ptr[i] ); 
    if ( i % 80 == 0 && i != 0 ) fprintf(fpt, "\n");
  }
  fprintf( fpt,"\n");
}

void my_func2( FILE * fpt,  char * string, int len ) {
int i;
char * ptr;

  ptr = string;
  for ( i=0;i<len;i++) {
    fprintf(fpt, "%c", ptr[i] ); 
    if ( i % 80 == 0 && i != 0 ) fprintf(fpt, "\n");
  }
  fprintf( fpt,"\n");
}


int check_MU_response ( mu_response * mu_resp,char * host, char * port   ) { 
char buf[10];

  strncpy(buf, mu_resp->header.status_code, 2);
  buf[2] = '\0';
  if ( atoi(buf) != 0) {
    fprintf(stdout, "ERROR: error invoking appln at server side = %s\n",buf);
    return -1; 
  }
  /*  look at the return code in the mu comr */
  strncpy(buf, mu_resp->comr.return_code, 2);
  buf[2] = '\0';
  printf ("MU response %s host: %s port: %s ",buf,host,port );
  if ( atoi(buf) != 0) {
    if ( atoi(buf) == 2)
      fprintf(stdout, "ERROR: Invalid appln id passed to server = %s\n",buf);
    else
      fprintf(stdout, "ERROR: Refreshing keytab file at server side = %s\n",buf);
    return -1; 
  }
  return( 0 );
}


int 
main(int argc, char ** argv)
{
  int    exit_status = 0,status;
  llPRINCIPAL *pdb_list;


  /* if maximum principals to be processed is specified as an argument,
     take it otherwise, it is set to default value */

  if (argc > 1) MaxPrincipals = atoi(argv[1]);
  else
    MaxPrincipals = MAX_PRINCIPALS_DEFAULT;

  if (argc > 2 ) debug = 1; else debug=0;

  /* open the log file */
  if (open_log_file() != 0)
     exit(1);

  /* check the environment */
  if (check_environ() != 0) goto failure;

  /* read the principal database */
  if (read_principal_DB(&pdb_list, cur_env.principal_db) != 0) {
    fprintf(logfile, "ERROR: error reading principal DB\n"); 
    goto failure;
  }

  if (ReadFile("../k/PublicKey",pbkey,&pbkey_len, MAXPKIKEYLEN)) {
    printf("WARNING: unable to read public key file.\n");
  };
  if (ReadFile("../k/PrivateKey",pvkey,&pvkey_len, MAXPKIKEYLEN)) {
    printf("WARNING: unable to read private key file.\n");
  };
  printf("Private Keylen=%d, Public Keylen=%d\n",pvkey_len,pbkey_len);

  /* start distributing keytab files */
  status = distribute_keytabs(pdb_list);
  /* status:0  - endof loop; 
     status:1  - failure to update schedule.dat file ; 
     status:-1 - need to continue.. 
   */
  if (status > 0)
    fprintf(logfile, "ERROR: error distributing keytabs\n"); 
  else
    if ( gkeytype == ENDGROUPKEY && gerrstatus == 0 ) unlink_key_save(); 

  else if (status == -1) /* there are some more principals to be processed*/
    exit_status = 0;
  else exit_status = 2; /* EOF reached */

  /* clean up the memory */
  if (debug) printf("call free_principal_DB. rt of distribute_keytabs=%d \n",status);
  fflush(stdout);
  if (free_principal_DB(pdb_list) != 0) {
    fprintf(logfile,
      "ERROR: error freeing memory allocated for principal database\n");
    goto failure;
  }
  fprintf(logfile, "\nEND OF THE PROCESS\n"); 
  fprintf(logfile, "----------------------------------------------------"); 
  fprintf(logfile, "-----------------------\n"); 
  fclose(logfile);
  printf("Process completed...\nEvents are logged to file  %s\n",
                    logfile_name);
  return(exit_status);
failure:
  if (logfile != NULL) fclose(logfile);
  printf("Keytab distribution process failed -- look at the log file %s\n",
                    logfile_name);
  return (1);
}

